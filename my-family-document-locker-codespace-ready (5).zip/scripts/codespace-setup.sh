#!/usr/bin/env bash
set -euo pipefail
node --version
npm --version
npm install
npm run typecheck
npm run build
