# My Family Document Locker

A secure, private, offline-first family document locker application built with React, TypeScript, Tailwind CSS, Capacitor Android, Web Crypto API (AES-256-GCM + PBKDF2), Firebase, and Google Drive API.


## GitHub Codespaces (recommended first run)

1. Upload/push this project folder to a GitHub repository.
2. On GitHub, open the repository and choose **Code → Codespaces → Create codespace on main**.
3. The included `.devcontainer/devcontainer.json` installs Node.js 22 and Java 21 and runs `npm install`.
4. In the Codespaces terminal, run:

   ```bash
   npm run typecheck
   npm run build
   npm run dev
   ```

5. Open forwarded port **3000** for the app. The Express server serves the app and API; if you want the Vite dev server instead, run `npm run preview -- --host 0.0.0.0` after building (port 4173).

Create a local `.env` from `.env.example` only when you need server-side Gemini or external OAuth. Do not commit `.env`, service-account keys, signing keys, or real family documents. The Firebase client config is not a server secret, but configure Firebase Auth providers, Firestore rules, Storage rules, and authorized domains in your own Firebase project before using real documents.

### Android APK from Codespaces

The repository includes the Capacitor Android project and Gradle wrapper. A Codespace has Java from the devcontainer, but may not have the Android SDK installed. For the simplest APK build, open this repository in Android Studio on a machine with Android SDK installed, or install/configure Android command-line tools and set `ANDROID_HOME` in the Codespace. Then run:

```bash
npm run android:debug
```

APK output: `android/app/build/outputs/apk/debug/app-debug.apk`. Do not commit generated APKs unless you intentionally want them in the repository.

---

## Build an Android APK

Use Node.js 22 and Android Studio with Android SDK installed. From the project root:

```bash
npm install
npm run lint
npm run build
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is normally created at `android/app/build/outputs/apk/debug/app-debug.apk`.
If Gradle reports a missing SDK, configure `ANDROID_HOME`/`local.properties` in your own environment.
The app uses the Firebase values in `firebase-applet-config.json`; verify that the Firebase project is yours and that Authentication, Firestore, and Storage are configured before storing real family documents.

---

## Google Drive Backup & Restore Setup

This application integrates official Google Drive API support for zero-knowledge, client-side encrypted vault backups (`.mfdbackup`).

### 1. Google Cloud Project Setup
1. Open the [Google Cloud Console](https://console.cloud.google.com/).
2. Select your Google Cloud project (e.g., `gen-lang-client-0225943937`).
3. Ensure billing is enabled if using production quotas.

### 2. Enable Google Drive API
1. Navigate to **APIs & Services** > **Library**.
2. Search for **Google Drive API**.
3. Click **Enable**.

### 3. Configure OAuth Consent Screen
1. Go to **APIs & Services** > **OAuth consent screen**.
2. Select **User Type** (External or Internal).
3. Fill in App Information:
   - App Name: `My Family Document Locker`
   - User support email
   - Developer contact email
4. Add Scopes:
   - Add the minimum required Drive scope:
     `https://www.googleapis.com/auth/drive.file`
   *(Do NOT request full `drive` scope; `drive.file` restricts access only to files created by this application).*
5. Add test users if in "Testing" publishing status.

### 4. Configure OAuth Client
#### Web Application Client
1. Go to **APIs & Services** > **Credentials** > **Create Credentials** > **OAuth client ID**.
2. Select Application Type: **Web application**.
3. Add Authorized JavaScript Origins:
   - Development: `http://localhost:3000`
   - Production / Hosted URL: `https://<YOUR_APP_DOMAIN>`
4. Add Authorized Redirect URIs:
   - Development: `http://localhost:3000`
   - Firebase Auth domain: `https://<YOUR_FIREBASE_PROJECT_ID>.firebaseapp.com/__/auth/handler`

#### Android Client
1. In Credentials, click **Create Credentials** > **OAuth client ID**.
2. Select Application Type: **Android**.
3. Package Name: `com.rptechhub.myfamilydocumentlocker` (the current package ID in `android/app/build.gradle`).
4. SHA-1 Fingerprint: Retrieve via `./gradlew signingReport` in the `android/` directory.

### 5. Android Configuration (Capacitor)
1. Verify Android package name in `capacitor.config.ts`:
   ```ts
   appId: 'com.rptechhub.myfamilydocumentlocker',
   appName: 'My Family Document Locker',
   ```
2. Run Capacitor Android sync:
   ```bash
   npm run build
   npx cap sync android
   ```
3. Open in Android Studio:
   ```bash
   npx cap open android
   ```

### 6. Required Scopes
- `https://www.googleapis.com/auth/drive.file`: Allows the app to create the `My Family Document Locker/Backups` folder and read/write `.mfdbackup` files created by this app.

### 7. Security Architecture
- **Zero Plaintext Cloud Upload**: All documents, family profiles, and notes are encrypted client-side using **AES-256-GCM** with keys derived using **PBKDF2-SHA256 (100,000 iterations)**.
- **In-Memory Token Cache**: Access tokens are kept in memory only and never stored in `localStorage`, `sessionStorage`, or logs.
- **Biometric Hardware Unlock**: Native Android fingerprint and facial recognition via `@aparajita/capacitor-biometric-auth` with fallback to PIN.

### 8. Testing Instructions
1. **Connect Google Drive**:
   - Go to **Settings** > **Cloud Backup • Google Drive**.
   - Click **Connect Google Drive**.
   - Grant permission for Google Drive file management.
   - Status updates to `Google Drive Connected`.
2. **Backup to Google Drive**:
   - Click **Backup Now**.
   - Enter your backup encryption password (minimum 6 characters).
   - Watch the progress steps: Preparing -> Encrypting -> Uploading -> Verifying.
   - Confirm file `MFDL-Backup-YYYY-MM-DD-HH-mm.mfdbackup` is uploaded to `My Family Document Locker/Backups/`.
3. **Restore from Google Drive**:
   - Click **Restore from Google Drive**.
   - Select your backup from the list.
   - Enter your password to decrypt & preview contents.
   - Choose restore mode: **Merge** (safe, non-destructive) or **Replace** (full overwrite with confirmation).
   - Confirm and verify vault data is loaded.
4. **Android Biometric Unlock**:
   - Lock vault or reopen app.
   - Tap fingerprint icon to invoke native Android Biometric prompt.
   - Confirm vault unlocks; or cancel to verify PIN keypad fallback.
