import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Camera as CameraIcon,
  Upload,
  FileText,
  X,
  Sparkles,
  RefreshCw,
  RotateCw,
  Crop as CropIcon,
  AlertCircle,
  CheckCircle2,
  SwitchCamera,
  Check,
  Maximize2
} from 'lucide-react';
import { Capacitor } from '@capacitor/core';
import { Camera as CapCamera, CameraResultType, CameraSource } from '@capacitor/camera';
import { formatFileSize } from '../utils/documentUtils';
import {
  compressImage,
  validateDocumentFile,
  rotateImageDataUrl,
  cropImageDataUrl,
  readFileAsDataUrl,
  ProcessedImage,
  CropRect
} from '../utils/imageUtils';
import { aiRouter } from '../services/aiRouter';

interface ScanModalProps {
  isOpen: boolean;
  initialMode: 'camera' | 'upload' | 'ai-scan';
  onClose: () => void;
  onProceedToVerify: (extractedData: any, fileInfo: any) => void;
}

export const ScanModal: React.FC<ScanModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onProceedToVerify
}) => {
  const [activeTab, setActiveTab] = useState<'camera' | 'upload'>(
    initialMode === 'camera' ? 'camera' : 'upload'
  );
  const [isAiScan, setIsAiScan] = useState<boolean>(initialMode === 'ai-scan');

  // Processed image state
  const [processedImage, setProcessedImage] = useState<ProcessedImage | null>(null);
  const [originalImage, setOriginalImage] = useState<ProcessedImage | null>(null);
  const [fileName, setFileName] = useState<string>('Scanned_Document.jpg');
  const [rotationDegrees, setRotationDegrees] = useState<number>(0);

  // Crop Mode state
  const [isCropMode, setIsCropMode] = useState<boolean>(false);
  const [cropPreset, setCropPreset] = useState<'id-card' | 'document' | 'square' | 'custom'>('id-card');
  const [cropMargins, setCropMargins] = useState<{ top: number; bottom: number; left: number; right: number }>({
    top: 10,
    bottom: 10,
    left: 10,
    right: 10
  });

  // Camera state
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');

  // Progress & Error states
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [processingStage, setProcessingStage] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Stop camera stream cleanly
  const stopCamera = useCallback(() => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
      setCameraStream(null);
    }
  }, [cameraStream]);

  // Start real mobile camera stream (using MediaDevices in Web, or Capacitor on native)
  const startCamera = useCallback(async () => {
    stopCamera();
    setCameraError(null);

    // If native Android/iOS environment via Capacitor
    if (Capacitor.isNativePlatform()) {
      try {
        const photo = await CapCamera.getPhoto({
          quality: 90,
          allowEditing: true,
          resultType: CameraResultType.Base64,
          source: CameraSource.Camera
        });

        if (photo.base64String) {
          const mimeType = photo.format ? `image/${photo.format}` : 'image/jpeg';
          const dataUrl = `data:${mimeType};base64,${photo.base64String}`;
          const compressed = await compressImage(dataUrl, 1600, 0.85);
          setProcessedImage(compressed);
          setOriginalImage(compressed);
          setFileName(`Camera_Scan_${Date.now()}.${photo.format || 'jpg'}`);
          setRotationDegrees(0);
          return;
        }
      } catch (nativeErr: any) {
        console.warn('Capacitor native camera failed or was canceled:', nativeErr);
        // Fall back to Web getUserMedia if available
      }
    }

    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getUserMedia) {
      setCameraError('Camera API is not supported on this browser or platform. Please select a photo from your gallery.');
      return;
    }

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: facingMode },
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        },
        audio: false
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setCameraStream(stream);

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
    } catch (err: any) {
      console.warn('Camera access denied or failed:', err);
      let msg = 'Camera permission denied or camera unavailable.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'Camera permission was denied. Please grant camera access in browser settings or choose a photo from your gallery.';
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        msg = 'No camera hardware found on this device.';
      } else if (err.name === 'NotReadableError') {
        msg = 'Camera is already in use by another application.';
      }
      setCameraError(msg);
    }
  }, [facingMode, stopCamera]);

  // Manage camera lifecycle
  useEffect(() => {
    if (isOpen && activeTab === 'camera' && !processedImage) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, activeTab, processedImage, startCamera, stopCamera]);

  if (!isOpen) return null;

  // Capture current frame from real video stream
  const handleCaptureFrame = async () => {
    if (!videoRef.current) return;
    const video = videoRef.current;

    const width = video.videoWidth || 1280;
    const height = video.videoHeight || 720;

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.9);

    stopCamera();
    setIsProcessing(true);
    setProgressPercent(30);
    setProcessingStage('Optimizing captured photo...');

    try {
      const compressed = await compressImage(dataUrl, 1600, 0.85);
      setProcessedImage(compressed);
      setOriginalImage(compressed);
      setFileName(`Camera_Scan_${Date.now()}.jpg`);
      setRotationDegrees(0);
      setProgressPercent(100);
      setProcessingStage('Photo captured successfully');
    } catch (err: any) {
      setErrorMessage('Failed to process captured image.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Switch camera front/back
  const handleToggleCamera = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Handle gallery/file selection
  const handleFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const validation = validateDocumentFile(file);
    if (!validation.valid) {
      setErrorMessage(validation.error || 'Invalid file format');
      return;
    }

    setErrorMessage(null);
    setIsProcessing(true);
    setProgressPercent(20);
    setProcessingStage('Reading document file...');

    try {
      setFileName(file.name);
      setProgressPercent(50);

      // Handle PDF vs Image
      if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
        const rawDataUrl = await readFileAsDataUrl(file);
        const cleanBase64 = rawDataUrl.replace(/^data:[^;]+;base64,/, '');
        const pdfImg: ProcessedImage = {
          base64Data: cleanBase64,
          dataUrl: rawDataUrl,
          mimeType: 'application/pdf',
          size: file.size,
          width: 0,
          height: 0
        };
        setProcessedImage(pdfImg);
        setOriginalImage(pdfImg);
      } else {
        setProcessingStage('Compressing image for fast OCR...');
        const compressed = await compressImage(file, 1600, 0.85);
        setProcessedImage(compressed);
        setOriginalImage(compressed);
      }

      setRotationDegrees(0);
      setProgressPercent(100);
      setProcessingStage('Document ready');
    } catch (err: any) {
      setErrorMessage(err.message || 'Error processing selected document');
    } finally {
      setIsProcessing(false);
    }
  };

  // Rotate preview image
  const handleRotateImage = async () => {
    if (!processedImage || processedImage.mimeType === 'application/pdf') return;

    const nextDegrees = (rotationDegrees + 90) % 360;
    setRotationDegrees(nextDegrees);

    try {
      const rotatedUrl = await rotateImageDataUrl(processedImage.dataUrl, 90);
      const cleanBase64 = rotatedUrl.replace(/^data:[^;]+;base64,/, '');
      setProcessedImage({
        ...processedImage,
        dataUrl: rotatedUrl,
        base64Data: cleanBase64
      });
    } catch (err) {
      console.warn('Rotation error:', err);
    }
  };

  // Apply crop preset
  const handleApplyCrop = async () => {
    if (!processedImage || processedImage.mimeType === 'application/pdf') return;

    setIsProcessing(true);
    setProcessingStage('Cropping document area...');

    try {
      const cropRect: CropRect = {
        x: cropMargins.left / 100,
        y: cropMargins.top / 100,
        width: Math.max(0.1, (100 - cropMargins.left - cropMargins.right) / 100),
        height: Math.max(0.1, (100 - cropMargins.top - cropMargins.bottom) / 100)
      };

      const cropped = await cropImageDataUrl(processedImage.dataUrl, cropRect, 0.9);
      setProcessedImage(cropped);
      setIsCropMode(false);
    } catch (err: any) {
      setErrorMessage('Failed to crop image. Try adjusting crop boundaries.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Reset to original image before crop/rotation
  const handleResetImage = () => {
    if (originalImage) {
      setProcessedImage(originalImage);
      setRotationDegrees(0);
      setCropMargins({ top: 10, bottom: 10, left: 10, right: 10 });
      setIsCropMode(false);
    }
  };

  // Retake or pick another image
  const handleRetake = () => {
    setProcessedImage(null);
    setOriginalImage(null);
    setErrorMessage(null);
    setRotationDegrees(0);
    setIsCropMode(false);
    if (activeTab === 'camera') {
      startCamera();
    }
  };

  // Set preset margins
  const applyPreset = (preset: 'id-card' | 'document' | 'square' | 'custom') => {
    setCropPreset(preset);
    if (preset === 'id-card') {
      // Wide card aspect ratio
      setCropMargins({ top: 15, bottom: 15, left: 5, right: 5 });
    } else if (preset === 'document') {
      // A4 portrait ratio
      setCropMargins({ top: 5, bottom: 5, left: 12, right: 12 });
    } else if (preset === 'square') {
      // 1:1
      setCropMargins({ top: 12, bottom: 12, left: 12, right: 12 });
    }
  };

  // Start processing using Hybrid AI Router (Offline First)
  const handleProceed = async () => {
    if (!processedImage) return;

    setIsProcessing(true);
    setErrorMessage(null);
    setProgressPercent(20);
    setProcessingStage('Scanning...');

    try {
      setProcessingStage('Reading document...');
      setProgressPercent(50);

      // Create a Blob / File from processedImage data
      const byteCharacters = atob(processedImage.base64Data);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: processedImage.mimeType });
      const file = new File([blob], fileName, { type: processedImage.mimeType });

      setProcessingStage('Extracting details...');
      setProgressPercent(80);

      const extractedData = await aiRouter.scanDocument(file);

      setProgressPercent(100);
      setProcessingStage('Ready for verification');

      setTimeout(() => {
        stopCamera();
        onProceedToVerify(extractedData, {
          name: fileName,
          size: processedImage.size,
          type: processedImage.mimeType.includes('pdf') ? 'pdf' : 'jpg',
          url: processedImage.dataUrl
        });
      }, 300);
    } catch (err: any) {
      setIsProcessing(false);
      setErrorMessage(
        err.message || 'Unable to read this document clearly. Please retake the photo.'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-fadeIn select-none">
      <div className="w-full max-w-sm bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 flex flex-col space-y-4 max-h-[95vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              {isAiScan ? <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" /> : <CameraIcon className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {isAiScan ? '✨ AI Document Scan' : 'Add Document'}
              </h3>
              <p className="text-[10px] text-slate-500">
                Visual OCR · Aadhaar/ID Privacy Compliant
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher: Real Camera vs Gallery Upload (when not viewing captured preview) */}
        {!processedImage && (
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-white/5 rounded-xl text-xs">
            <button
              onClick={() => {
                setActiveTab('camera');
                setCameraError(null);
              }}
              className={`flex-1 py-1.5 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'camera'
                  ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <CameraIcon className="w-3.5 h-3.5" />
              <span>Camera</span>
            </button>
            <button
              onClick={() => {
                stopCamera();
                setActiveTab('upload');
              }}
              className={`flex-1 py-1.5 rounded-lg font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'upload'
                  ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Gallery / File</span>
            </button>
          </div>
        )}

        {/* Main View Area */}
        {processedImage ? (
          /* Captured / Uploaded Image Preview & Tools */
          <div className="space-y-3">
            <div className="relative h-60 rounded-2xl bg-slate-100 dark:bg-slate-800 overflow-hidden border border-slate-200 dark:border-white/10 flex items-center justify-center">
              {processedImage.mimeType === 'application/pdf' ? (
                <div className="flex flex-col items-center justify-center text-red-600 space-y-2 p-4 text-center">
                  <FileText className="w-14 h-14" />
                  <span className="text-xs font-bold font-mono">PDF DOCUMENT READY</span>
                  <span className="text-[11px] text-slate-500 max-w-[200px] truncate">
                    {fileName}
                  </span>
                </div>
              ) : (
                <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
                  <img
                    src={processedImage.dataUrl}
                    alt="Scanned Preview"
                    className="w-full h-full object-contain"
                  />

                  {/* Visual Crop Box Overlay when in Crop Mode */}
                  {isCropMode && (
                    <div
                      className="absolute border-2 border-dashed border-blue-500 bg-blue-500/10 pointer-events-none transition-all duration-150"
                      style={{
                        top: `${cropMargins.top}%`,
                        bottom: `${cropMargins.bottom}%`,
                        left: `${cropMargins.left}%`,
                        right: `${cropMargins.right}%`
                      }}
                    >
                      <div className="absolute top-0 left-0 bg-blue-600 text-white text-[9px] px-1 font-mono">
                        CROP
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Action Overlay: Rotate, Crop, Retake */}
              {!isCropMode && (
                <div className="absolute top-2 right-2 flex items-center gap-1.5 z-10">
                  {processedImage.mimeType !== 'application/pdf' && (
                    <>
                      <button
                        onClick={() => setIsCropMode(true)}
                        className="p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors cursor-pointer"
                        title="Crop document edges"
                      >
                        <CropIcon className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={handleRotateImage}
                        className="p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors cursor-pointer"
                        title="Rotate 90 degrees"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                      </button>
                    </>
                  )}
                  <button
                    onClick={handleRetake}
                    className="p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors cursor-pointer"
                    title="Retake / Select another"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>

            {/* Interactive Crop Controls when isCropMode is true */}
            {isCropMode ? (
              <div className="p-3 bg-slate-50 dark:bg-white/5 rounded-2xl border border-slate-200 dark:border-white/10 space-y-2.5">
                <div className="flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <span className="flex items-center gap-1.5">
                    <CropIcon className="w-3.5 h-3.5 text-blue-500" />
                    <span>Adjust Crop Area</span>
                  </span>
                  <div className="flex gap-1 text-[11px]">
                    <button
                      type="button"
                      onClick={() => applyPreset('id-card')}
                      className={`px-2 py-0.5 rounded-md cursor-pointer ${
                        cropPreset === 'id-card' ? 'bg-blue-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      ID Card
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPreset('document')}
                      className={`px-2 py-0.5 rounded-md cursor-pointer ${
                        cropPreset === 'document' ? 'bg-blue-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      A4 Page
                    </button>
                    <button
                      type="button"
                      onClick={() => applyPreset('square')}
                      className={`px-2 py-0.5 rounded-md cursor-pointer ${
                        cropPreset === 'square' ? 'bg-blue-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      Square
                    </button>
                  </div>
                </div>

                {/* Crop Margin Sliders */}
                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-500">
                  <div>
                    <label className="flex justify-between">Top: {cropMargins.top}%</label>
                    <input
                      type="range"
                      min={0}
                      max={40}
                      value={cropMargins.top}
                      onChange={(e) => {
                        setCropPreset('custom');
                        setCropMargins({ ...cropMargins, top: Number(e.target.value) });
                      }}
                      className="w-full h-1 bg-slate-300 dark:bg-slate-700 rounded-lg cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="flex justify-between">Bottom: {cropMargins.bottom}%</label>
                    <input
                      type="range"
                      min={0}
                      max={40}
                      value={cropMargins.bottom}
                      onChange={(e) => {
                        setCropPreset('custom');
                        setCropMargins({ ...cropMargins, bottom: Number(e.target.value) });
                      }}
                      className="w-full h-1 bg-slate-300 dark:bg-slate-700 rounded-lg cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="flex justify-between">Left: {cropMargins.left}%</label>
                    <input
                      type="range"
                      min={0}
                      max={40}
                      value={cropMargins.left}
                      onChange={(e) => {
                        setCropPreset('custom');
                        setCropMargins({ ...cropMargins, left: Number(e.target.value) });
                      }}
                      className="w-full h-1 bg-slate-300 dark:bg-slate-700 rounded-lg cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="flex justify-between">Right: {cropMargins.right}%</label>
                    <input
                      type="range"
                      min={0}
                      max={40}
                      value={cropMargins.right}
                      onChange={(e) => {
                        setCropPreset('custom');
                        setCropMargins({ ...cropMargins, right: Number(e.target.value) });
                      }}
                      className="w-full h-1 bg-slate-300 dark:bg-slate-700 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setIsCropMode(false)}
                    className="flex-1 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-300 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleResetImage}
                    className="px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-300 cursor-pointer"
                  >
                    Reset
                  </button>
                  <button
                    type="button"
                    onClick={handleApplyCrop}
                    className="flex-1 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white cursor-pointer flex items-center justify-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Apply Crop
                  </button>
                </div>
              </div>
            ) : (
              <>
                {/* Document metadata summary */}
                <div className="flex items-center justify-between text-xs px-2 text-slate-600 dark:text-slate-300">
                  <span className="font-semibold truncate max-w-[200px]">{fileName}</span>
                  <span className="text-slate-400 font-mono">
                    {formatFileSize(processedImage.size)}
                  </span>
                </div>

                {/* AI Scan toggle option */}
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200/70 dark:border-purple-800/40 text-xs">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    <span className="font-semibold text-purple-900 dark:text-purple-200">
                      Auto-extract fields with Gemini AI
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={isAiScan}
                    onChange={(e) => setIsAiScan(e.target.checked)}
                    className="w-4 h-4 text-purple-600 rounded-sm focus:ring-purple-500 cursor-pointer"
                  />
                </div>
              </>
            )}
          </div>
        ) : activeTab === 'camera' ? (
          /* REAL CAMERA LIVE VIEWFINDER */
          <div className="relative h-64 rounded-2xl bg-black overflow-hidden flex flex-col justify-between border border-slate-700 shadow-inner">
            {cameraError ? (
              <div className="flex-1 flex flex-col items-center justify-center p-4 text-center space-y-3">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <AlertCircle className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-xs font-bold text-white">Camera Permission Notice</h4>
                  <p className="text-[11px] text-white/80 leading-relaxed max-w-[260px]">{cameraError}</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    stopCamera();
                    setActiveTab('upload');
                    fileInputRef.current?.click();
                  }}
                  className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 cursor-pointer shadow-md"
                >
                  Choose From Gallery / File
                </button>
              </div>
            ) : (
              <>
                <video
                  ref={videoRef}
                  playsInline
                  autoPlay
                  muted
                  className="absolute inset-0 w-full h-full object-cover"
                />

                {/* Document boundary guide overlay */}
                <div className="absolute inset-3 border-2 border-dashed border-white/70 rounded-xl pointer-events-none flex flex-col justify-between p-2">
                  <div className="flex justify-between items-center text-[10px] text-white font-mono bg-black/50 px-2 py-0.5 rounded-md self-start">
                    <span>LIVE DOCUMENT SCANNER</span>
                  </div>
                  <div className="text-center text-[10px] text-white/90 bg-black/60 py-1 px-2 rounded-md mx-auto">
                    Position ID card or page inside the frame
                  </div>
                </div>

                {/* Camera controls bar */}
                <div className="relative z-10 mt-auto p-3 flex items-center justify-between bg-gradient-to-t from-black/85 via-black/40 to-transparent">
                  <button
                    type="button"
                    onClick={handleToggleCamera}
                    className="p-2.5 rounded-full bg-white/20 hover:bg-white/30 text-white cursor-pointer"
                    title="Switch camera"
                  >
                    <SwitchCamera className="w-5 h-5" />
                  </button>

                  {/* Real Shutter Button */}
                  <button
                    type="button"
                    onClick={handleCaptureFrame}
                    className="w-14 h-14 rounded-full border-4 border-white bg-blue-600 flex items-center justify-center text-white shadow-lg active:scale-90 transition-transform cursor-pointer"
                    title="Capture photo"
                  >
                    <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
                      <CameraIcon className="w-5 h-5 text-blue-600" />
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      stopCamera();
                      setActiveTab('upload');
                    }}
                    className="p-2.5 rounded-full bg-white/20 hover:bg-white/30 text-white cursor-pointer"
                    title="Switch to file upload"
                  >
                    <Upload className="w-4 h-4" />
                  </button>
                </div>
              </>
            )}
          </div>
        ) : (
          /* GALLERY / FILE UPLOAD AREA */
          <div
            onClick={() => fileInputRef.current?.click()}
            className="h-56 rounded-2xl border-2 border-dashed border-slate-300 dark:border-white/15 hover:border-blue-500 bg-slate-50 dark:bg-white/5 flex flex-col items-center justify-center p-4 text-center cursor-pointer transition-colors space-y-2 group"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <Upload className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Tap to Select Document
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                JPG, JPEG, PNG, WEBP, or PDF (up to 25MB)
              </p>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelected}
              accept=".pdf,.jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp,application/pdf"
              className="hidden"
            />
          </div>
        )}

        {/* Error message display */}
        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span className="leading-tight">{errorMessage}</span>
          </div>
        )}

        {/* Processing Progress Bar */}
        {isProcessing && (
          <div className="space-y-1 pt-1">
            <div className="flex justify-between text-[11px] text-slate-500 font-medium">
              <span className="flex items-center gap-1.5 text-blue-600 dark:text-blue-400">
                <Sparkles className="w-3.5 h-3.5 animate-spin" />
                <span>{processingStage || 'Processing...'}</span>
              </span>
              <span className="font-mono">{progressPercent}%</span>
            </div>
            <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-white/10 overflow-hidden">
              <div
                className="h-full bg-blue-600 rounded-full transition-all duration-200 ease-out"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        )}

        {/* Bottom Actions */}
        <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-white/10">
          <button
            type="button"
            onClick={() => {
              stopCamera();
              onClose();
            }}
            className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Cancel
          </button>

          {processedImage && !isCropMode && (
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleProceed}
              className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-40 text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-sm"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm & Proceed</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
