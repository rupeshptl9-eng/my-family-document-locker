import React from 'react';
import { FileUp, FileText, Camera, Sparkles, X } from 'lucide-react';

interface AddBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (action: 'upload' | 'text' | 'camera' | 'ai-scan') => void;
}

export const AddBottomSheet: React.FC<AddBottomSheetProps> = ({
  isOpen,
  onClose,
  onSelectAction
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end animate-fadeIn select-none">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      {/* Sheet Content (Slide Up) */}
      <div className="relative w-full max-w-lg mx-auto bg-white dark:bg-[#1a1b22] rounded-t-[32px] p-6 shadow-2xl border-t border-slate-200 dark:border-white/10 z-10 animate-slideUp">
        {/* Grab Handle */}
        <div className="w-12 h-1.5 rounded-full bg-slate-300 dark:bg-slate-600 mx-auto mb-4" />

        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Add to Locker
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Choose how you want to add documents or secure notes
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Actions Grid */}
        <div className="grid grid-cols-1 gap-2.5 pb-2">
          {/* 1. Add Document */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('upload');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200/60 dark:border-white/5 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <FileUp className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>📄 Add Document</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                Upload PDF, JPG, or PNG from file storage
              </p>
            </div>
          </button>

          {/* 2. Add Text */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('text');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200/60 dark:border-white/5 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <FileText className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>📝 Add Text</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                Save passwords, bank details, emergency notes
              </p>
            </div>
          </button>

          {/* 3. Scan Document */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('camera');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200/60 dark:border-white/5 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-xl bg-cyan-100 dark:bg-cyan-950/80 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Camera className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>📷 Scan Document</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                Capture physical documents with device camera
              </p>
            </div>
          </button>

          {/* 4. Scan with AI */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('ai-scan');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl bg-purple-50/70 hover:bg-purple-100/70 dark:bg-purple-950/30 dark:hover:bg-purple-950/50 border border-purple-200/70 dark:border-purple-800/30 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-purple-500/20">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-purple-900 dark:text-purple-300 flex items-center gap-1.5">
                <span>✨ Scan with AI</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-purple-200 dark:bg-purple-800 text-purple-800 dark:text-purple-200">
                  Smart OCR
                </span>
              </h4>
              <p className="text-xs text-purple-700/80 dark:text-purple-300/70 truncate">
                Auto-extract ID number, expiry dates & verify before saving
              </p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
