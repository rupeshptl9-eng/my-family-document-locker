import React, { useState } from 'react';
import {
  Search,
  X,
  Plus,
  Copy,
  Share2,
  Edit2,
  Trash2,
  Check,
  Tag,
  Lock,
  Star,
  Sparkles,
  FileText,
  Eye
} from 'lucide-react';
import { FamilyMember, TextCategory, TextNote } from '../types';
import { formatDate } from '../utils/documentUtils';

interface TextLockerScreenProps {
  notes: TextNote[];
  familyMembers: FamilyMember[];
  onAddNote: (note: TextNote) => void;
  onUpdateNote: (note: TextNote) => void;
  onDeleteNote: (noteId: string) => void;
  onBackToDocs?: () => void;
}

const CATEGORIES: ('All' | TextCategory)[] = [
  'All',
  'Important notes',
  'Bank information',
  'Insurance details',
  'Emergency information',
  'Personal notes',
  'Account information',
  'Addresses',
  'Reference numbers'
];

export const TextLockerScreen: React.FC<TextLockerScreenProps> = ({
  notes,
  familyMembers,
  onAddNote,
  onUpdateNote,
  onDeleteNote,
  onBackToDocs
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | TextCategory>('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Modal states
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [viewingNote, setViewingNote] = useState<TextNote | null>(null);
  const [editingNote, setEditingNote] = useState<TextNote | null>(null);

  // Editor form state
  const [formTitle, setFormTitle] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formCategory, setFormCategory] = useState<TextCategory>('Important notes');
  const [formFamilyId, setFormFamilyId] = useState<string>(familyMembers[0]?.id || 'self');
  const [formTags, setFormTags] = useState('');
  const [isAnalyzingAI, setIsAnalyzingAI] = useState(false);

  // Filter notes
  const filteredNotes = notes.filter((n) => {
    if (selectedCategory !== 'All' && n.category !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = n.title.toLowerCase().includes(q);
      const matchContent = n.content.toLowerCase().includes(q);
      const matchCat = n.category.toLowerCase().includes(q);
      const matchFamily = n.familyMemberName.toLowerCase().includes(q);
      const matchTag = n.tags.some((t) => t.toLowerCase().includes(q));
      if (!matchTitle && !matchContent && !matchCat && !matchFamily && !matchTag) return false;
    }
    return true;
  });

  const handleCopy = (note: TextNote, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    navigator.clipboard.writeText(`${note.title}\n\n${note.content}`);
    setCopiedId(note.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleShare = async (note: TextNote, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (navigator.share) {
      try {
        await navigator.share({
          title: note.title,
          text: note.content
        });
      } catch {
        // Ignored
      }
    } else {
      handleCopy(note);
    }
  };

  const toggleFavorite = (note: TextNote, e: React.MouseEvent) => {
    e.stopPropagation();
    onUpdateNote({
      ...note,
      isFavorite: !note.isFavorite,
      updatedAt: new Date().toISOString()
    });
  };

  const openCreateModal = () => {
    setEditingNote(null);
    setFormTitle('');
    setFormContent('');
    setFormCategory('Important notes');
    setFormFamilyId(familyMembers[0]?.id || 'self');
    setFormTags('');
    setIsEditorOpen(true);
  };

  const openEditModal = (note: TextNote, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingNote(note);
    setFormTitle(note.title);
    setFormContent(note.content);
    setFormCategory(note.category);
    setFormFamilyId(note.familyMemberId);
    setFormTags(note.tags.join(', '));
    setIsEditorOpen(true);
  };

  const handleAIAnalyze = async () => {
    if (!formContent.trim()) return;
    setIsAnalyzingAI(true);
    try {
      const res = await fetch('/api/ai/analyze-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: formTitle, content: formContent })
      });
      const data = await res.json();
      if (data.suggestedCategory) {
        setFormCategory(data.suggestedCategory);
      }
      if (data.suggestedTags && Array.isArray(data.suggestedTags)) {
        setFormTags(data.suggestedTags.join(', '));
      }
    } catch (e) {
      console.error('AI analyze failed:', e);
    } finally {
      setIsAnalyzingAI(false);
    }
  };

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) return;

    const member =
      familyMembers.find((m) => m.id === formFamilyId) ||
      familyMembers[0] || { id: 'self', name: 'Self' };

    const tagsArray = formTags
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    const now = new Date().toISOString();

    if (editingNote) {
      onUpdateNote({
        ...editingNote,
        title: formTitle.trim(),
        content: formContent.trim(),
        category: formCategory,
        familyMemberId: member.id,
        familyMemberName: member.name,
        tags: tagsArray,
        updatedAt: now
      });
    } else {
      const newNote: TextNote = {
        id: `note_${Date.now()}`,
        title: formTitle.trim(),
        content: formContent.trim(),
        category: formCategory,
        familyMemberId: member.id,
        familyMemberName: member.name,
        tags: tagsArray,
        createdAt: now,
        updatedAt: now
      };
      onAddNote(newNote);
    }

    setIsEditorOpen(false);
  };

  return (
    <div className="flex-1 pb-24 px-4 pt-3 select-none animate-fadeIn space-y-3.5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <span>Text Locker</span>
            <Lock className="w-4 h-4 text-emerald-500" />
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Encrypted personal notes, bank details, credentials & reference numbers
          </p>
        </div>

        <button
          onClick={openCreateModal}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition-all active:scale-95 shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Note</span>
        </button>
      </div>

      {/* Search Input Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search notes, tags, or bank details..."
          className="w-full h-11 pl-10 pr-9 rounded-2xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-400 border border-slate-200/80 dark:border-white/10 hover:border-blue-400'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Notes List */}
      {filteredNotes.length === 0 ? (
        <div className="p-8 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/70 dark:border-white/10 text-center space-y-3 mt-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/70 text-emerald-500 mx-auto flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              No notes in text locker
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
              Save emergency medical contacts, bank account numbers, Wi-Fi keys, or addresses.
            </p>
          </div>
          <button
            onClick={openCreateModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create First Note</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredNotes.map((note) => {
            const isCopied = copiedId === note.id;

            return (
              <div
                key={note.id}
                onClick={() => setViewingNote(note)}
                className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20 transition-all shadow-xs space-y-2.5 cursor-pointer active:scale-[0.99] group"
              >
                {/* Title and Category */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {note.title}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                        {note.category}
                      </span>
                      <span>·</span>
                      <span>{note.familyMemberName}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={(e) => toggleFavorite(note, e)}
                      className={`p-1 rounded-lg transition-colors cursor-pointer ${
                        note.isFavorite ? 'text-amber-500 fill-amber-500' : 'text-slate-300'
                      }`}
                      title="Favorite"
                    >
                      <Star className={`w-4 h-4 ${note.isFavorite ? 'fill-current' : ''}`} />
                    </button>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {formatDate(note.updatedAt)}
                    </span>
                  </div>
                </div>

                {/* Excerpt */}
                <p className="text-xs text-slate-600 dark:text-slate-300 font-mono whitespace-pre-line line-clamp-3 bg-slate-50 dark:bg-white/5 p-2.5 rounded-2xl border border-slate-100 dark:border-white/5">
                  {note.content}
                </p>

                {/* Action Bar */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-white/5">
                  <div className="flex items-center gap-1.5 overflow-hidden">
                    {note.tags.slice(0, 3).map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-400"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setViewingNote(note);
                      }}
                      className="p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="View full note"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={(e) => handleCopy(note, e)}
                      className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                        isCopied
                          ? 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60'
                          : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white'
                      }`}
                      title={isCopied ? 'Copied!' : 'Copy text'}
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>

                    <button
                      onClick={(e) => handleShare(note, e)}
                      className="p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="Share note"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={(e) => openEditModal(note, e)}
                      className="p-1.5 text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white rounded-lg transition-colors cursor-pointer"
                      title="Edit note"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (confirm(`Delete "${note.title}"?`)) {
                          onDeleteNote(note.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                      title="Delete note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* View Note Modal */}
      {viewingNote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn select-none">
          <div className="w-full max-w-md max-h-[85vh] bg-white dark:bg-[#1a1b22] rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-white/10 flex flex-col space-y-4">
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 dark:border-white/10">
              <div>
                <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wide">
                  {viewingNote.category}
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                  {viewingNote.title}
                </h3>
                <p className="text-[11px] text-slate-500">
                  {viewingNote.familyMemberName} · Updated {formatDate(viewingNote.updatedAt)}
                </p>
              </div>
              <button
                onClick={() => setViewingNote(null)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto pr-1">
              <pre className="text-xs text-slate-800 dark:text-slate-200 font-mono whitespace-pre-wrap leading-relaxed select-text bg-slate-50 dark:bg-white/5 p-4 rounded-2xl border border-slate-200/70 dark:border-white/5">
                {viewingNote.content}
              </pre>
            </div>

            {viewingNote.tags.length > 0 && (
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                {viewingNote.tags.map((t) => (
                  <span
                    key={t}
                    className="text-[11px] px-2.5 py-0.5 rounded-lg bg-slate-100 dark:bg-white/10 text-slate-600 dark:text-slate-300"
                  >
                    #{t}
                  </span>
                ))}
              </div>
            )}

            <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-white/10">
              <button
                onClick={() => handleCopy(viewingNote)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedId === viewingNote.id ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                <span>{copiedId === viewingNote.id ? 'Copied' : 'Copy Text'}</span>
              </button>
              <button
                onClick={() => handleShare(viewingNote)}
                className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
              <button
                onClick={() => {
                  const toEdit = viewingNote;
                  setViewingNote(null);
                  openEditModal(toEdit);
                }}
                className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white transition-colors cursor-pointer"
                title="Edit note"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create / Edit Note Modal */}
      {isEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn select-none">
          <div className="w-full max-w-md max-h-[90vh] bg-white dark:bg-[#1a1b22] rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-white/10 flex flex-col space-y-3.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-white/10">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingNote ? 'Edit Secure Note' : 'Create Secure Note'}
              </h3>
              <button
                onClick={() => setIsEditorOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNote} className="flex-1 flex flex-col space-y-3 overflow-y-auto">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Title *
                </label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Health Policy Nominee & Emergency Contacts"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Category *
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as TextCategory)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {CATEGORIES.filter((c) => c !== 'All').map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Family Member
                  </label>
                  <select
                    value={formFamilyId}
                    onChange={(e) => setFormFamilyId(e.target.value)}
                    className="w-full px-2.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {familyMembers.length === 0 ? (
                      <option value="self">Self (Vault Owner)</option>
                    ) : (
                      familyMembers.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} ({m.relationship})
                        </option>
                      ))
                    )}
                  </select>
                </div>
              </div>

              <div className="flex-1 flex flex-col min-h-[140px]">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Content / Secure Text *
                  </label>
                  <button
                    type="button"
                    onClick={handleAIAnalyze}
                    disabled={isAnalyzingAI || !formContent.trim()}
                    className="text-[11px] font-semibold text-purple-600 dark:text-purple-400 hover:underline flex items-center gap-1 disabled:opacity-40 cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>{isAnalyzingAI ? 'Analyzing...' : 'AI Suggest Tags'}</span>
                  </button>
                </div>
                <textarea
                  required
                  rows={6}
                  value={formContent}
                  onChange={(e) => setFormContent(e.target.value)}
                  placeholder="Enter policy details, passwords, account numbers, blood groups..."
                  className="w-full flex-1 px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Tags (comma separated)
                </label>
                <input
                  type="text"
                  value={formTags}
                  onChange={(e) => setFormTags(e.target.value)}
                  placeholder="e.g. emergency, hospital, blood-group"
                  className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-blue-600 text-xs font-semibold text-white hover:bg-blue-700 transition-colors cursor-pointer"
                >
                  Save Note
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
