import React, { useState } from 'react';
import {
  X,
  Download,
  Share2,
  ZoomIn,
  ZoomOut,
  RotateCw,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  Calendar,
  User,
  Shield,
  FileText,
  Building,
  CheckCircle2,
  Star,
  MapPin
} from 'lucide-react';
import { LockerDocument } from '../types';
import { formatDate, formatFileSize, getExpiryStatus, CATEGORY_CONFIG } from '../utils/documentUtils';

interface DocumentViewerModalProps {
  document: LockerDocument | null;
  onClose: () => void;
  onDownload: (doc: LockerDocument) => void;
  onToggleFavorite?: (docId: string) => void;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({
  document,
  onClose,
  onDownload,
  onToggleFavorite
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [rotation, setRotation] = useState<number>(0);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [isNumberRevealed, setIsNumberRevealed] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'metadata'>('preview');

  if (!document) return null;

  const totalPages = document.fileType === 'pdf' ? 2 : 1;
  const { status, label, badgeColor } = getExpiryStatus(document.expiryDate);
  const categoryMeta = CATEGORY_CONFIG[document.category] || CATEGORY_CONFIG.Other;

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(prev + 0.25, 2.5));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(prev - 0.25, 0.5));
  const handleRotate = () => setRotation((prev) => (prev + 90) % 360);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: document.name,
          text: `My Family Locker - ${document.category}: ${document.name}`,
          url: window.location.href
        });
      } catch {
        // Ignored
      }
    } else {
      navigator.clipboard.writeText(`${document.name} (${document.category}) - ${document.maskedNumber}`);
      alert('Document details copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-slate-950/90 backdrop-blur-md animate-fadeIn select-none">
      {/* Top App Bar */}
      <header className="w-full px-4 py-3 bg-slate-900/95 border-b border-white/10 flex items-center justify-between text-white z-10">
        <div className="flex items-center gap-3 min-w-0">
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 transition-colors cursor-pointer text-slate-300"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <div className="min-w-0">
            <h3 className="text-sm font-bold truncate max-w-[180px] sm:max-w-md">
              {document.name}
            </h3>
            <p className="text-[11px] text-slate-400">
              {document.fileName} · {formatFileSize(document.fileSize)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {onToggleFavorite && (
            <button
              onClick={() => onToggleFavorite(document.id)}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                document.isFavorite ? 'text-amber-400 fill-amber-400' : 'text-slate-300 hover:text-white'
              }`}
              title="Favorite"
            >
              <Star className={`w-4 h-4 ${document.isFavorite ? 'fill-current' : ''}`} />
            </button>
          )}
          <button
            onClick={handleShare}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDownload(document)}
            className="p-2 rounded-xl text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Download"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Segmented Control: Viewer vs Details */}
      <div className="px-4 py-2 bg-slate-900/80 flex items-center justify-between border-b border-white/5">
        <div className="flex items-center gap-1 p-1 bg-white/5 rounded-xl text-xs">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
              activeTab === 'preview'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Document
          </button>
          <button
            onClick={() => setActiveTab('metadata')}
            className={`px-3 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
              activeTab === 'metadata'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Details
          </button>
        </div>

        <span className={`text-[10px] font-semibold px-2.5 py-0.5 rounded-full ${badgeColor}`}>
          {label}
        </span>
      </div>

      {/* Main Area */}
      <div className="flex-1 relative overflow-hidden flex flex-col items-center justify-center p-4">
        {activeTab === 'preview' ? (
          <div className="relative w-full h-full flex items-center justify-center overflow-auto">
            <div
              className="transition-transform duration-150 ease-out origin-center flex items-center justify-center max-w-full max-h-full"
              style={{
                transform: `scale(${zoomLevel}) rotate(${rotation}deg)`
              }}
            >
              {document.fileType === 'pdf' ? (
                <div className="relative w-[340px] sm:w-[480px] bg-white rounded-xl shadow-2xl p-6 text-slate-900 border border-slate-300">
                  <div className="border-b border-slate-200 pb-3 mb-4 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center font-bold text-xs">
                        PDF
                      </div>
                      <div>
                        <h4 className="text-xs font-bold">{document.name}</h4>
                        <p className="text-[10px] text-slate-500">
                          {document.issuingAuthority || 'Official Document'}
                        </p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-400">
                      Page {currentPage} of {totalPages}
                    </span>
                  </div>

                  <div className="space-y-4">
                    <div className="h-44 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 relative">
                      <img
                        src={document.fileUrl}
                        alt="Doc preview"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent flex items-end p-3">
                        <div className="text-white text-xs font-medium">
                          {document.category} · {document.familyMemberName}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 pt-2 text-xs">
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Document No:</span>
                        <span className="font-mono font-semibold">
                          {isNumberRevealed ? document.documentNumber : document.maskedNumber}
                        </span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Issued Date:</span>
                        <span>{formatDate(document.issueDate)}</span>
                      </div>
                      <div className="flex justify-between py-1 border-b border-slate-100">
                        <span className="text-slate-500">Expiry Date:</span>
                        <span className="font-semibold text-blue-600">
                          {formatDate(document.expiryDate)}
                        </span>
                      </div>
                      {document.notes && (
                        <p className="text-[11px] text-slate-600 pt-2 leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                          {document.notes}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <img
                  src={document.fileUrl}
                  alt={document.name}
                  className="max-w-full max-h-[70vh] rounded-xl shadow-2xl object-contain border border-white/10"
                />
              )}
            </div>
          </div>
        ) : (
          <div className="w-full max-w-md h-full overflow-y-auto no-scrollbar py-2 space-y-3.5 animate-fadeIn">
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <h4 className="text-xs font-bold text-white">
                  Verified in Encrypted Locker
                </h4>
                <p className="text-[11px] text-emerald-300/80">
                  {document.isAadhaar
                    ? 'Visual OCR extract without UIDAI server queries.'
                    : 'Encrypted and stored in private family vault.'}
                </p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" /> Title
                </span>
                <span className="font-semibold text-white">{document.name}</span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" /> Category
                </span>
                <span className="font-semibold text-white">{document.category}</span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5" /> Family Member
                </span>
                <span className="font-semibold text-white">{document.familyMemberName}</span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-400">Document Number</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-blue-400">
                    {isNumberRevealed ? document.documentNumber : document.maskedNumber}
                  </span>
                  <button
                    onClick={() => setIsNumberRevealed(!isNumberRevealed)}
                    className="p-1 text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    {isNumberRevealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {document.dob && (
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5" /> Date of Birth
                  </span>
                  <span className="text-white">{formatDate(document.dob)}</span>
                </div>
              )}

              {document.gender && (
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-slate-400">Gender</span>
                  <span className="text-white">{document.gender}</span>
                </div>
              )}

              {document.address && (
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5" /> Address
                  </span>
                  <span className="text-white text-right max-w-[200px] truncate">
                    {document.address}
                  </span>
                </div>
              )}

              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" /> Issue Date
                </span>
                <span className="text-white">{formatDate(document.issueDate)}</span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5" /> Expiry Date
                </span>
                <span className="font-semibold text-white">
                  {formatDate(document.expiryDate)}
                </span>
              </div>

              {document.issuingAuthority && (
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-slate-400 flex items-center gap-1.5">
                    <Building className="w-3.5 h-3.5" /> Authority
                  </span>
                  <span className="text-white text-right max-w-[200px] truncate">
                    {document.issuingAuthority}
                  </span>
                </div>
              )}
            </div>

            {document.notes && (
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-1 text-xs">
                <h5 className="font-semibold text-slate-300">Notes & Coverage Details</h5>
                <p className="text-slate-400 leading-relaxed text-[11px]">{document.notes}</p>
              </div>
            )}
          </div>
        )}
      </div>

      {activeTab === 'preview' && (
        <div className="w-full px-6 py-3 bg-slate-900/95 border-t border-white/10 flex items-center justify-between text-white z-10">
          <div className="flex items-center gap-2">
            <button
              onClick={handleZoomOut}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors cursor-pointer text-slate-200"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono w-10 text-center">
              {Math.round(zoomLevel * 100)}%
            </span>
            <button
              onClick={handleZoomIn}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors cursor-pointer text-slate-200"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleRotate}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 transition-colors cursor-pointer text-slate-200 ml-1"
              title="Rotate 90 degrees"
            >
              <RotateCw className="w-4 h-4" />
            </button>
          </div>

          {document.fileType === 'pdf' && (
            <div className="flex items-center gap-1.5 text-xs">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                className="p-1.5 rounded-lg bg-white/10 disabled:opacity-30 hover:bg-white/20 transition-colors cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono text-[11px]">
                {currentPage}/{totalPages}
              </span>
              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))}
                className="p-1.5 rounded-lg bg-white/10 disabled:opacity-30 hover:bg-white/20 transition-colors cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
