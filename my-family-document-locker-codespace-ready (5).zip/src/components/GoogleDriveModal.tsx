import React, { useState, useEffect } from 'react';
import {
  Cloud,
  CheckCircle2,
  AlertCircle,
  Download,
  Upload,
  Trash2,
  X,
  Lock,
  Loader2,
  FileCheck,
  RefreshCw,
  Layers,
  AlertTriangle
} from 'lucide-react';
import { googleDriveService, DriveBackupFile } from '../services/googleDriveService';
import { LockerDocument, FamilyMember, TextNote } from '../types';
import { formatFileSize, formatDate } from '../utils/documentUtils';
import { encryptedIndexedDBService } from '../services/encryptedIndexedDBService';

interface GoogleDriveModalProps {
  isOpen: boolean;
  mode: 'backup' | 'restore';
  documents: LockerDocument[];
  familyMembers: FamilyMember[];
  textNotes: TextNote[];
  onClose: () => void;
  onDataRestored: () => void;
  onBackupSuccess: (fileName: string) => void;
}

export const GoogleDriveModal: React.FC<GoogleDriveModalProps> = ({
  isOpen,
  mode: initialMode,
  documents,
  familyMembers,
  textNotes,
  onClose,
  onDataRestored,
  onBackupSuccess
}) => {
  const [activeTab, setActiveTab] = useState<'backup' | 'restore'>(initialMode);
  const [backupPassword, setBackupPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [progressStage, setProgressStage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Restore list state
  const [backups, setBackups] = useState<DriveBackupFile[]>([]);
  const [isLoadingBackups, setIsLoadingBackups] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<DriveBackupFile | null>(null);
  const [restorePassword, setRestorePassword] = useState('');
  const [restorePreview, setRestorePreview] = useState<{
    docCount: number;
    familyCount: number;
    noteCount: number;
    rawPayload: any;
  } | null>(null);
  const [restoreMode, setRestoreMode] = useState<'merge' | 'replace'>('merge');
  const [showReplaceConfirm, setShowReplaceConfirm] = useState(false);
  const [deletingFileId, setDeletingFileId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setActiveTab(initialMode);
      setErrorMessage(null);
      setProgressStage(null);
      setIsSuccess(false);
      setBackupPassword('');
      setConfirmPassword('');
      setRestorePassword('');
      setRestorePreview(null);
      setShowReplaceConfirm(false);

      if (initialMode === 'restore') {
        loadBackupsList();
      }
    }
  }, [isOpen, initialMode]);

  const loadBackupsList = async () => {
    setIsLoadingBackups(true);
    setErrorMessage(null);
    try {
      const files = await googleDriveService.listBackups();
      setBackups(files);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to list Google Drive backups.');
    } finally {
      setIsLoadingBackups(false);
    }
  };

  if (!isOpen) return null;

  // Handle Backup Now
  const handlePerformBackup = async () => {
    if (!backupPassword || backupPassword.length < 6) {
      setErrorMessage('Backup password must be at least 6 characters long.');
      return;
    }

    if (backupPassword !== confirmPassword) {
      setErrorMessage('Passwords do not match. Please re-enter.');
      return;
    }

    setErrorMessage(null);
    setIsLoading(true);

    try {
      const res = await googleDriveService.uploadBackup(
        backupPassword,
        documents,
        familyMembers,
        textNotes,
        (stage) => setProgressStage(stage)
      );

      setIsSuccess(true);
      setSuccessMessage(`Encrypted vault backup (${res.fileName}) safely uploaded to Google Drive.`);
      onBackupSuccess(res.fileName);
    } catch (err: any) {
      setErrorMessage(err.message || 'Google Drive backup failed. Your local documents are safe.');
    } finally {
      setIsLoading(false);
      setProgressStage(null);
    }
  };

  // Preview Restore
  const handlePreviewSelectedBackup = async () => {
    if (!selectedBackup || !restorePassword) {
      setErrorMessage('Please enter the backup password to decrypt.');
      return;
    }

    setErrorMessage(null);
    setIsLoading(true);

    try {
      const decrypted = await googleDriveService.downloadAndDecryptBackup(
        selectedBackup.id,
        restorePassword,
        (stage) => setProgressStage(stage)
      );

      setRestorePreview({
        docCount: decrypted.documents?.length || 0,
        familyCount: decrypted.family?.length || 0,
        noteCount: decrypted.notes?.length || 0,
        rawPayload: decrypted
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Invalid backup password.');
    } finally {
      setIsLoading(false);
      setProgressStage(null);
    }
  };

  // Commit Restore
  const handleCommitRestore = async () => {
    if (!restorePreview) return;

    if (restoreMode === 'replace' && !showReplaceConfirm) {
      setShowReplaceConfirm(true);
      return;
    }

    setIsLoading(true);
    setProgressStage('Restoring records into encrypted vault...');

    try {
      const { rawPayload } = restorePreview;

      if (restoreMode === 'replace') {
        // Clear current vault items first
        await encryptedIndexedDBService.clearAllVaultData();
      }

      // Write restored documents
      for (const d of rawPayload.documents || []) {
        await encryptedIndexedDBService.putEncryptedItem(d.id, 'document', d);
      }

      // Write restored family members
      for (const f of rawPayload.family || []) {
        await encryptedIndexedDBService.putEncryptedItem(f.id, 'family', f);
      }

      // Write restored notes
      for (const n of rawPayload.notes || []) {
        await encryptedIndexedDBService.putEncryptedItem(n.id, 'note', n);
      }

      setIsSuccess(true);
      setSuccessMessage('Backup successfully restored to your vault!');
      onDataRestored();
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to complete restore.');
    } finally {
      setIsLoading(false);
      setProgressStage(null);
      setShowReplaceConfirm(false);
    }
  };

  // Delete Backup File from Drive
  const handleDeleteBackup = async (file: DriveBackupFile) => {
    if (!confirm(`Delete backup "${file.name}" from Google Drive? This will not affect your local vault.`)) {
      return;
    }

    setDeletingFileId(file.id);
    try {
      await googleDriveService.deleteBackup(file.id);
      setBackups((prev) => prev.filter((b) => b.id !== file.id));
      if (selectedBackup?.id === file.id) {
        setSelectedBackup(null);
        setRestorePreview(null);
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Could not delete backup from Google Drive.');
    } finally {
      setDeletingFileId(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn select-none">
      <div className="w-full max-w-md bg-white dark:bg-[#1a1b22] rounded-3xl shadow-2xl border border-slate-200 dark:border-white/10 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 px-5 border-b border-slate-100 dark:border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Google Drive Backup & Restore
              </h3>
              <p className="text-[11px] text-slate-500">
                AES-256-GCM Encrypted Cloud Storage
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="px-5 pt-3 flex gap-2">
          <button
            type="button"
            onClick={() => {
              setActiveTab('backup');
              setErrorMessage(null);
              setIsSuccess(false);
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'backup'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Backup Now</span>
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('restore');
              setErrorMessage(null);
              setIsSuccess(false);
              loadBackupsList();
            }}
            className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'restore'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-400'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>Restore Vault</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Error Banner */}
          {errorMessage && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
              <div className="flex-1">
                <p className="font-semibold">{errorMessage}</p>
              </div>
            </div>
          )}

          {/* Success Banner */}
          {isSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 text-center space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
              <h4 className="text-xs font-bold text-emerald-800 dark:text-emerald-200">
                ☁️ Operation Complete
              </h4>
              <p className="text-[11px] text-emerald-700 dark:text-emerald-300">
                {successMessage}
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-2 px-4 py-1.5 rounded-xl bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          )}

          {/* Progress Indicator */}
          {isLoading && progressStage && (
            <div className="p-4 rounded-2xl bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/40 text-center space-y-2 animate-pulse">
              <Loader2 className="w-6 h-6 text-blue-600 animate-spin mx-auto" />
              <p className="text-xs font-semibold text-blue-700 dark:text-blue-300">
                {progressStage}
              </p>
            </div>
          )}

          {/* TAB 1: BACKUP */}
          {!isSuccess && activeTab === 'backup' && (
            <div className="space-y-3.5">
              <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-1.5">
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                  Vault Summary to Encrypt
                </p>
                <div className="grid grid-cols-3 gap-2 text-center pt-1">
                  <div className="p-2 rounded-xl bg-white dark:bg-white/5 border border-slate-100 dark:border-white/5">
                    <span className="text-sm font-bold text-blue-600 font-mono">
                      {documents.length}
                    </span>
                    <p className="text-[10px] text-slate-500">Documents</p>
                  </div>
                  <div className="p-2 rounded-xl bg-white dark:bg-white/5 border border-slate-100 dark:border-white/5">
                    <span className="text-sm font-bold text-purple-600 font-mono">
                      {familyMembers.length}
                    </span>
                    <p className="text-[10px] text-slate-500">Family</p>
                  </div>
                  <div className="p-2 rounded-xl bg-white dark:bg-white/5 border border-slate-100 dark:border-white/5">
                    <span className="text-sm font-bold text-emerald-600 font-mono">
                      {textNotes.length}
                    </span>
                    <p className="text-[10px] text-slate-500">Notes</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <div>
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                    Backup Encryption Password
                  </label>
                  <div className="relative mt-1">
                    <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="password"
                      value={backupPassword}
                      onChange={(e) => setBackupPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      disabled={isLoading}
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                    Confirm Password
                  </label>
                  <div className="relative mt-1">
                    <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Re-enter password"
                      disabled={isLoading}
                      className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-slate-500 leading-tight">
                🔒 Your documents will be encrypted client-side with AES-256-GCM before upload. Neither Google nor anyone else can read your files without this password.
              </p>

              <button
                type="button"
                disabled={isLoading}
                onClick={handlePerformBackup}
                className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xs active:scale-[0.99]"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Cloud className="w-4 h-4" />
                )}
                <span>Upload Encrypted Backup to Drive</span>
              </button>
            </div>
          )}

          {/* TAB 2: RESTORE */}
          {!isSuccess && activeTab === 'restore' && (
            <div className="space-y-3.5">
              {!restorePreview ? (
                <>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Select Cloud Backup File
                    </span>
                    <button
                      type="button"
                      onClick={loadBackupsList}
                      disabled={isLoadingBackups}
                      className="text-xs text-blue-600 hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className={`w-3 h-3 ${isLoadingBackups ? 'animate-spin' : ''}`} />
                      <span>Refresh</span>
                    </button>
                  </div>

                  {isLoadingBackups ? (
                    <div className="py-8 text-center space-y-2">
                      <Loader2 className="w-6 h-6 animate-spin text-blue-600 mx-auto" />
                      <p className="text-xs text-slate-500">Checking Google Drive...</p>
                    </div>
                  ) : backups.length === 0 ? (
                    <div className="py-8 text-center p-4 rounded-2xl bg-slate-50 dark:bg-white/5 border border-dashed border-slate-200 dark:border-white/10">
                      <Cloud className="w-8 h-8 text-slate-300 dark:text-slate-600 mx-auto mb-2" />
                      <p className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        No Backups Found
                      </p>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        Create a backup first from the Backup tab.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {backups.map((file) => {
                        const isSelected = selectedBackup?.id === file.id;
                        return (
                          <div
                            key={file.id}
                            onClick={() => setSelectedBackup(file)}
                            className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between ${
                              isSelected
                                ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-500 ring-1 ring-blue-500/20'
                                : 'bg-slate-50 dark:bg-white/5 border-slate-200/80 dark:border-white/10 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center gap-2.5 overflow-hidden">
                              <FileCheck className="w-5 h-5 text-blue-500 shrink-0" />
                              <div className="overflow-hidden">
                                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                                  {file.name}
                                </p>
                                <p className="text-[10px] text-slate-500">
                                  {formatDate(file.createdTime)} • {formatFileSize(file.size)}
                                </p>
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleDeleteBackup(file);
                              }}
                              disabled={deletingFileId === file.id}
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                              title="Delete from Google Drive"
                            >
                              {deletingFileId === file.id ? (
                                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              ) : (
                                <Trash2 className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {selectedBackup && (
                    <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-white/10">
                      <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                        Enter Backup Password to Decrypt & Preview
                      </label>
                      <div className="relative">
                        <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                        <input
                          type="password"
                          value={restorePassword}
                          onChange={(e) => setRestorePassword(e.target.value)}
                          placeholder="Password used during backup"
                          disabled={isLoading}
                          className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>

                      <button
                        type="button"
                        disabled={isLoading || !restorePassword}
                        onClick={handlePreviewSelectedBackup}
                        className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs"
                      >
                        {isLoading ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <FileCheck className="w-4 h-4" />
                        )}
                        <span>Decrypt & Preview Contents</span>
                      </button>
                    </div>
                  )}
                </>
              ) : (
                /* Restore Preview & Mode Selection */
                <div className="space-y-3.5">
                  <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/40 space-y-2">
                    <div className="flex items-center gap-1.5 text-emerald-800 dark:text-emerald-200">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span className="text-xs font-bold">Backup Decrypted Successfully</span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-center pt-1">
                      <div className="p-2 rounded-xl bg-white dark:bg-white/5">
                        <span className="text-sm font-bold text-blue-600 font-mono">
                          {restorePreview.docCount}
                        </span>
                        <p className="text-[10px] text-slate-500">Documents</p>
                      </div>
                      <div className="p-2 rounded-xl bg-white dark:bg-white/5">
                        <span className="text-sm font-bold text-purple-600 font-mono">
                          {restorePreview.familyCount}
                        </span>
                        <p className="text-[10px] text-slate-500">Family</p>
                      </div>
                      <div className="p-2 rounded-xl bg-white dark:bg-white/5">
                        <span className="text-sm font-bold text-emerald-600 font-mono">
                          {restorePreview.noteCount}
                        </span>
                        <p className="text-[10px] text-slate-500">Notes</p>
                      </div>
                    </div>
                  </div>

                  {/* Restore Modes */}
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                      Restore Mode
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setRestoreMode('merge');
                          setShowReplaceConfirm(false);
                        }}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          restoreMode === 'merge'
                            ? 'bg-blue-50 dark:bg-blue-950/40 border-blue-500'
                            : 'bg-slate-50 dark:bg-white/5 border-slate-200/80 dark:border-white/10'
                        }`}
                      >
                        <p className="text-xs font-bold text-slate-900 dark:text-white">
                          Merge (Default)
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Adds records without overwriting
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setRestoreMode('replace')}
                        className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                          restoreMode === 'replace'
                            ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-500'
                            : 'bg-slate-50 dark:bg-white/5 border-slate-200/80 dark:border-white/10'
                        }`}
                      >
                        <p className="text-xs font-bold text-slate-900 dark:text-white">
                          Replace All
                        </p>
                        <p className="text-[10px] text-slate-500">
                          Overwrites vault with backup
                        </p>
                      </button>
                    </div>
                  </div>

                  {/* Strong confirmation for Replace */}
                  {restoreMode === 'replace' && showReplaceConfirm && (
                    <div className="p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800/60 text-xs text-amber-800 dark:text-amber-200 space-y-1">
                      <div className="flex items-center gap-1.5 font-bold">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        <span>Confirm Replace</span>
                      </div>
                      <p className="text-[11px]">
                        This will replace the current vault data on this device with the contents of this backup.
                      </p>
                    </div>
                  )}

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setRestorePreview(null)}
                      className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                    >
                      Back
                    </button>
                    <button
                      type="button"
                      disabled={isLoading}
                      onClick={handleCommitRestore}
                      className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      {isLoading ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      )}
                      <span>{restoreMode === 'replace' && !showReplaceConfirm ? 'Proceed to Replace' : 'Confirm Restore'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
