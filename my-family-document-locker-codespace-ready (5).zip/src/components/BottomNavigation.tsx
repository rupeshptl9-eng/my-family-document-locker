import React from 'react';
import { Home, FolderClosed, Users, Sparkles, Settings, Plus } from 'lucide-react';

export type NavTab = 'home' | 'documents' | 'family' | 'ai' | 'profile';

interface BottomNavigationProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  onOpenAddSheet: () => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentTab,
  onTabChange,
  onOpenAddSheet
}) => {
  return (
    <nav
      aria-label="Bottom Navigation"
      className="w-full bg-white/95 dark:bg-[#18191f]/95 backdrop-blur-md border-t border-slate-200/80 dark:border-white/10 px-1 pt-1 pb-2 flex items-center justify-around z-20 select-none shadow-lg"
    >
      {/* 1. Home */}
      <button
        onClick={() => onTabChange('home')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-full transition-all duration-200 ${
            currentTab === 'home'
              ? 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 font-semibold'
              : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800'
          }`}
        >
          <Home className="w-5 h-5" />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'home'
              ? 'text-blue-700 dark:text-blue-300 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          Home
        </span>
      </button>

      {/* 2. Documents */}
      <button
        onClick={() => onTabChange('documents')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-full transition-all duration-200 ${
            currentTab === 'documents'
              ? 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 font-semibold'
              : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800'
          }`}
        >
          <FolderClosed className="w-5 h-5" />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'documents'
              ? 'text-blue-700 dark:text-blue-300 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          Documents
        </span>
      </button>

      {/* Center Elevated Floating Add Button */}
      <div className="flex flex-col items-center justify-center -mt-6 px-1">
        <button
          onClick={onOpenAddSheet}
          aria-label="Add Document"
          className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-xl shadow-blue-500/35 flex items-center justify-center cursor-pointer transition-all duration-150 hover:scale-105 active:scale-90 border-2 border-white dark:border-[#18191f]"
          title="Add Document or Note"
        >
          <Plus className="w-7 h-7 stroke-[2.5]" />
        </button>
        <span className="text-[10px] mt-1 font-bold text-slate-700 dark:text-slate-300">
          Add
        </span>
      </div>

      {/* 3. Family */}
      <button
        onClick={() => onTabChange('family')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-full transition-all duration-200 ${
            currentTab === 'family'
              ? 'bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300 font-semibold'
              : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800'
          }`}
        >
          <Users className="w-5 h-5" />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'family'
              ? 'text-purple-700 dark:text-purple-300 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          Family
        </span>
      </button>

      {/* 4. AI Scan / Assistant */}
      <button
        onClick={() => onTabChange('ai')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-full transition-all duration-200 ${
            currentTab === 'ai'
              ? 'bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300 font-semibold'
              : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800'
          }`}
        >
          <Sparkles className="w-5 h-5" />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'ai'
              ? 'text-purple-700 dark:text-purple-300 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          AI Scan
        </span>
      </button>

      {/* 5. Settings / Profile */}
      <button
        onClick={() => onTabChange('profile')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-full transition-all duration-200 ${
            currentTab === 'profile'
              ? 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 font-semibold'
              : 'text-slate-500 dark:text-slate-400 group-hover:text-slate-800'
          }`}
        >
          <Settings className="w-5 h-5" />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'profile'
              ? 'text-blue-700 dark:text-blue-300 font-bold'
              : 'text-slate-500 dark:text-slate-400'
          }`}
        >
          Settings
        </span>
      </button>
    </nav>
  );
};
