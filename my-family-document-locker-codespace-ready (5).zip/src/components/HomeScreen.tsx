import React from 'react';
import {
  Bell,
  Sparkles,
  Camera,
  FilePlus,
  FileText,
  AlertTriangle,
  ChevronRight,
  Shield,
  CreditCard,
  Globe,
  Car,
  Landmark,
  HeartPulse,
  GraduationCap,
  Building,
  Folder,
  ArrowRight,
  Eye,
  Star,
  Clock,
  Lock,
  Vote,
  FileCheck
} from 'lucide-react';
import { DocumentCategory, FamilyMember, LockerDocument, TextNote, UserProfile } from '../types';
import { getExpiryStatus } from '../utils/documentUtils';
import { aiRouter, AIStatusInfo } from '../services/aiRouter';

interface HomeScreenProps {
  user: UserProfile;
  documents: LockerDocument[];
  familyMembers: FamilyMember[];
  textNotes: TextNote[];
  unreadNotifsCount: number;
  onOpenNotifications: () => void;
  onNavigateToTab: (tab: 'home' | 'documents' | 'ai' | 'profile') => void;
  onNavigateToSubView: (view: 'family' | 'text-locker') => void;
  onSelectCategory: (category: DocumentCategory) => void;
  onQuickAction: (action: 'camera' | 'upload' | 'text' | 'ai-scan') => void;
  onViewDocument: (doc: LockerDocument) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  user,
  documents,
  familyMembers,
  textNotes,
  unreadNotifsCount,
  onOpenNotifications,
  onNavigateToTab,
  onNavigateToSubView,
  onSelectCategory,
  onQuickAction,
  onViewDocument
}) => {
  const [aiStatus, setAiStatus] = React.useState<AIStatusInfo | null>(null);

  React.useEffect(() => {
    const unsub = aiRouter.subscribe((status) => {
      setAiStatus(status);
    });
    return unsub;
  }, []);

  // Category counts
  const categoryCounts = documents.reduce((acc, doc) => {
    acc[doc.category] = (acc[doc.category] || 0) + 1;
    return acc;
  }, {} as Record<DocumentCategory, number>);

  // Expiring soon documents (within 30 days)
  const expiringDocs = documents.filter((doc) => {
    const { status } = getExpiryStatus(doc.expiryDate);
    return status === 'EXPIRING_SOON' || status === 'EXPIRED';
  });

  // Favorite documents
  const favoriteDocs = documents.filter((doc) => doc.isFavorite);

  // Recently added documents (last 3)
  const recentDocs = [...documents]
    .sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
    .slice(0, 3);

  // Categories list
  const CATEGORIES: {
    name: DocumentCategory;
    icon: React.ReactNode;
    bg: string;
  }[] = [
    {
      name: 'Aadhaar',
      icon: <Shield className="w-5 h-5 text-orange-600 dark:text-orange-400" />,
      bg: 'bg-orange-500/10 dark:bg-orange-500/20'
    },
    {
      name: 'PAN',
      icon: <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      bg: 'bg-blue-500/10 dark:bg-blue-500/20'
    },
    {
      name: 'Passport',
      icon: <Globe className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />,
      bg: 'bg-indigo-500/10 dark:bg-indigo-500/20'
    },
    {
      name: 'Driving Licence',
      icon: <Car className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />,
      bg: 'bg-cyan-500/10 dark:bg-cyan-500/20'
    },
    {
      name: 'Voter ID',
      icon: <Vote className="w-5 h-5 text-teal-600 dark:text-teal-400" />,
      bg: 'bg-teal-500/10 dark:bg-teal-500/20'
    },
    {
      name: 'Bank',
      icon: <Landmark className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-500/10 dark:bg-emerald-500/20'
    },
    {
      name: 'Insurance',
      icon: <HeartPulse className="w-5 h-5 text-purple-600 dark:text-purple-400" />,
      bg: 'bg-purple-500/10 dark:bg-purple-500/20'
    },
    {
      name: 'Education',
      icon: <GraduationCap className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      bg: 'bg-amber-500/10 dark:bg-amber-500/20'
    },
    {
      name: 'Property',
      icon: <Building className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
      bg: 'bg-emerald-500/10 dark:bg-emerald-500/20'
    },
    {
      name: 'Vehicle',
      icon: <Car className="w-5 h-5 text-rose-600 dark:text-rose-400" />,
      bg: 'bg-rose-500/10 dark:bg-rose-500/20'
    },
    {
      name: 'Other',
      icon: <Folder className="w-5 h-5 text-slate-600 dark:text-slate-400" />,
      bg: 'bg-slate-500/10 dark:bg-slate-500/20'
    }
  ];

  const greetingName = user.displayName?.trim() ? user.displayName.split(' ')[0] : 'Family';

  return (
    <div className="flex-1 pb-20 px-4 pt-2 select-none animate-fadeIn space-y-4">
      {/* Top Bar */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateToTab('profile')}
            className="relative cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-sm flex items-center justify-center ring-2 ring-blue-500/30 group-hover:ring-blue-500 shadow-xs">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName}
                  className="w-full h-full rounded-2xl object-cover"
                />
              ) : (
                greetingName.charAt(0).toUpperCase()
              )}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white dark:border-[#121316]" />
          </button>

          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
              Hello, {greetingName} 👋
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Keep your important documents safe and organized.
            </p>
          </div>
        </div>

        <button
          onClick={onOpenNotifications}
          aria-label="Notifications"
          className="relative p-2.5 rounded-2xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/10 transition-all active:scale-95 cursor-pointer shadow-xs"
        >
          <Bell className="w-5 h-5" />
          {unreadNotifsCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse">
              {unreadNotifsCount}
            </span>
          )}
        </button>
      </div>

      {/* Prominent AI Card */}
      <div
        onClick={() => onNavigateToTab('ai')}
        className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 text-white shadow-xl shadow-indigo-500/20 cursor-pointer active:scale-[0.99] transition-transform group"
      >
        <div className="absolute -right-6 -bottom-8 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none group-hover:scale-125 transition-transform" />
        <div className="absolute right-4 top-4 opacity-20 pointer-events-none">
          <Sparkles className="w-20 h-20" />
        </div>

        <div className="relative z-10 flex items-start justify-between">
          <div className="space-y-1 max-w-[80%]">
            <div className="flex items-center gap-1.5 flex-wrap mb-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-semibold text-white">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Smart Document Assistant</span>
              </div>
              {aiStatus && (
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-black/25 backdrop-blur-md text-[10px] font-medium text-white/95">
                  <span className={`w-1.5 h-1.5 rounded-full ${aiStatus.badgeColor === 'emerald' ? 'bg-emerald-400' : aiStatus.badgeColor === 'amber' ? 'bg-amber-400 animate-pulse' : 'bg-blue-400'}`} />
                  <span>{aiStatus.badgeText}</span>
                </div>
              )}
            </div>
            <h3 className="text-lg font-bold tracking-tight">✨ Ask AI</h3>
            <p className="text-xs text-white/90 leading-snug">
              Search, scan and understand your documents
            </p>
          </div>

          <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 group-hover:translate-x-1 transition-transform">
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-2 mt-4 pt-3 border-t border-white/15 overflow-x-auto no-scrollbar text-[11px]">
          <span className="shrink-0 px-2.5 py-1 rounded-lg bg-white/15 text-white/95">
            "Which docs expire soon?"
          </span>
          <span className="shrink-0 px-2.5 py-1 rounded-lg bg-white/15 text-white/95">
            "Verify passport validity"
          </span>
          <span className="shrink-0 px-2.5 py-1 rounded-lg bg-white/15 text-white/95">
            "Summarize insurance coverage"
          </span>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <section className="space-y-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
          Quick Actions
        </h3>

        <div className="grid grid-cols-4 gap-2">
          {/* 1. 📷 Scan */}
          <button
            onClick={() => onQuickAction('camera')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/70 dark:border-white/10 hover:border-blue-400 dark:hover:border-blue-500 transition-all active:scale-95 text-center cursor-pointer shadow-xs group"
          >
            <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-950/70 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <Camera className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
              Scan
            </span>
          </button>

          {/* 2. 📄 Add Document */}
          <button
            onClick={() => onQuickAction('upload')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/70 dark:border-white/10 hover:border-blue-400 dark:hover:border-blue-500 transition-all active:scale-95 text-center cursor-pointer shadow-xs group"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <FilePlus className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
              Add Doc
            </span>
          </button>

          {/* 3. 📝 Add Text */}
          <button
            onClick={() => onQuickAction('text')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/70 dark:border-white/10 hover:border-blue-400 dark:hover:border-blue-500 transition-all active:scale-95 text-center cursor-pointer shadow-xs group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
              Add Text
            </span>
          </button>

          {/* 4. ✨ AI Scan */}
          <button
            onClick={() => onQuickAction('ai-scan')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/40 hover:border-purple-400 transition-all active:scale-95 text-center cursor-pointer shadow-xs group"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center mb-1.5 group-hover:scale-105 transition-transform shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-purple-900 dark:text-purple-300">
              AI Scan
            </span>
          </button>
        </div>
      </section>

      {/* Family Overview Shortcut */}
      <div className="p-3.5 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-2.5">
          <div className="flex -space-x-2 overflow-hidden">
            {familyMembers.length === 0 ? (
              <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold border-2 border-white dark:border-[#121316]">
                +
              </div>
            ) : (
              familyMembers.slice(0, 4).map((m) => (
                <div
                  key={m.id}
                  className="w-8 h-8 rounded-full border-2 border-white dark:border-[#121316] flex items-center justify-center text-white text-[10px] font-bold shadow-xs"
                  style={{ backgroundColor: m.color }}
                >
                  {m.name.charAt(0)}
                </div>
              ))
            )}
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              Family Members ({familyMembers.length})
            </h4>
            <p className="text-[11px] text-slate-500">
              {familyMembers.length === 0
                ? 'Tap to add family member profiles'
                : 'Organized documents by member'}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateToSubView('family')}
          className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1 cursor-pointer hover:underline"
        >
          <span>Manage</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* My Documents Categories */}
      <section className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            My Documents
          </h3>
          <button
            onClick={() => onNavigateToTab('documents')}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline cursor-pointer"
          >
            <span>View All ({documents.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {CATEGORIES.map((cat) => {
            const count = categoryCounts[cat.name] || 0;
            return (
              <button
                key={cat.name}
                onClick={() => onSelectCategory(cat.name)}
                className="flex items-center justify-between p-3 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/70 dark:border-white/10 hover:border-blue-400 dark:hover:border-blue-500 text-left transition-all active:scale-[0.98] cursor-pointer shadow-xs group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl ${cat.bg} flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform`}
                  >
                    {cat.icon}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {cat.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {count} {count === 1 ? 'doc' : 'docs'}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-500 transition-all shrink-0" />
              </button>
            );
          })}
        </div>
      </section>

      {/* Expiring Soon Section */}
      <section className="space-y-2 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Expiring Soon (Within 30 Days)
            </h3>
          </div>
          {expiringDocs.length > 0 && (
            <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400">
              {expiringDocs.length} pending
            </span>
          )}
        </div>

        {expiringDocs.length === 0 ? (
          <div className="p-3.5 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <FileCheck className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-semibold text-slate-900 dark:text-white">
                All Documents Up to Date
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                No documents are expiring in the next 30 days.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            {expiringDocs.map((doc) => {
              const { label, badgeColor } = getExpiryStatus(doc.expiryDate);
              return (
                <div
                  key={doc.id}
                  className="p-3 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 hover:border-amber-400 transition-all flex items-center justify-between shadow-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/70 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {doc.name}
                      </h4>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                        <span>{doc.familyMemberName}</span>
                        <span>·</span>
                        <span className={`font-semibold px-1.5 py-0.2 rounded-md ${badgeColor}`}>
                          {label}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onViewDocument(doc)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-white/10 hover:bg-slate-200 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors shrink-0 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Secure Text Locker Card */}
      <div
        onClick={() => onNavigateToSubView('text-locker')}
        className="p-4 rounded-3xl bg-emerald-50/70 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-900/40 flex items-center justify-between cursor-pointer active:scale-[0.99] transition-transform group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-emerald-950 dark:text-emerald-200">
              Secure Text Locker
            </h4>
            <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
              {textNotes.length} encrypted notes & emergency records
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
      </div>
    </div>
  );
};
