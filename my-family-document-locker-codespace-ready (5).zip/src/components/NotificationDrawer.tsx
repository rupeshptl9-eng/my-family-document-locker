import React from 'react';
import {
  Bell,
  X,
  AlertTriangle,
  ShieldCheck,
  HardDrive,
  Sparkles,
  ChevronRight,
  CheckCheck
} from 'lucide-react';
import { NotificationItem } from '../types';
import { formatDate } from '../utils/documentUtils';

interface NotificationDrawerProps {
  isOpen: boolean;
  notifications: NotificationItem[];
  onClose: () => void;
  onSelectNotification: (item: NotificationItem) => void;
  onMarkAllAsRead: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  notifications,
  onClose,
  onSelectNotification,
  onMarkAllAsRead
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end animate-fadeIn select-none">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
      />

      {/* Drawer Content */}
      <div className="relative w-full max-w-lg mx-auto bg-white dark:bg-[#1a1b22] rounded-t-[32px] p-6 shadow-2xl border-t border-slate-200 dark:border-white/10 z-10 max-h-[85vh] flex flex-col space-y-4 animate-slideUp">
        {/* Grab Handle */}
        <div className="w-12 h-1.5 rounded-full bg-slate-300 dark:bg-slate-600 mx-auto mb-2" />

        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Notifications & Alerts
              </h3>
              <p className="text-[11px] text-slate-500">
                Document expiry and locker security updates
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onMarkAllAsRead}
              className="p-1.5 text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline cursor-pointer flex items-center gap-1"
              title="Mark all as read"
            >
              <CheckCheck className="w-4 h-4" />
              <span>Mark Read</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto space-y-2.5 pr-0.5">
          {notifications.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              No new notifications. Everything is up to date!
            </div>
          ) : (
            notifications.map((item) => {
              return (
                <div
                  key={item.id}
                  onClick={() => onSelectNotification(item)}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-start gap-3 ${
                    item.read
                      ? 'bg-slate-50/60 dark:bg-white/5 border-slate-200/50 dark:border-white/5 opacity-80'
                      : 'bg-amber-50/40 dark:bg-amber-950/20 border-amber-200/70 dark:border-amber-800/40 shadow-xs'
                  }`}
                >
                  <div className="w-9 h-9 rounded-xl shrink-0 flex items-center justify-center bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400">
                    {item.type === 'expiry' && <AlertTriangle className="w-4 h-4" />}
                    {item.type === 'security' && <ShieldCheck className="w-4 h-4 text-emerald-500" />}
                    {item.type === 'backup' && <HardDrive className="w-4 h-4 text-blue-500" />}
                    {item.type === 'ai' && <Sparkles className="w-4 h-4 text-purple-500" />}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {item.title}
                      </h4>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {formatDate(item.date)}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5 leading-snug">
                      {item.message}
                    </p>
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 self-center" />
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
