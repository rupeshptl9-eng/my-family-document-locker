import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Smartphone,
  Maximize2,
  Moon,
  Sun,
  ShieldCheck,
  Signal
} from 'lucide-react';

interface AndroidContainerProps {
  children: React.ReactNode;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const AndroidContainer: React.FC<AndroidContainerProps> = ({
  children,
  theme,
  onToggleTheme
}) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);
  const [currentTime, setCurrentTime] = useState('');

  // Update status bar clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-200 flex flex-col items-center justify-center ${
        theme === 'dark'
          ? 'bg-[#0f1115] text-[#e2e8f0]'
          : 'bg-slate-200 text-slate-900'
      }`}
    >
      {/* Top Desktop Controls Bar (only visible on larger viewports to toggle phone frame vs full screen and dark mode) */}
      <header className="hidden md:flex items-center justify-between w-full max-w-4xl px-4 py-2.5 text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-2 font-medium">
          <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>My Family Document Locker</span>
          <span className="text-slate-400 dark:text-slate-600">·</span>
          <span className="text-[11px] text-slate-500">Android Material 3 Edition</span>
        </div>

        <div className="flex items-center gap-2">
          {/* Frame Toggle */}
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white dark:bg-slate-800 shadow-sm border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors cursor-pointer"
            title="Toggle between phone device mockup and full screen"
          >
            {isPhoneFrame ? (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Full Screen</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5" />
                <span>Phone Frame</span>
              </>
            )}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-1.5 rounded-md bg-white dark:bg-slate-800 shadow-sm border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors cursor-pointer"
            title="Toggle Light / Dark mode"
          >
            {theme === 'dark' ? (
              <Sun className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Moon className="w-3.5 h-3.5 text-slate-700" />
            )}
          </button>
        </div>
      </header>

      {/* Main Container: Android Phone Frame or Edge-to-Edge */}
      <div
        className={`w-full transition-all duration-300 relative flex flex-col overflow-hidden ${
          isPhoneFrame
            ? 'md:max-w-[430px] md:h-[915px] md:my-3 md:rounded-[44px] md:shadow-2xl md:ring-1 md:ring-black/10 dark:md:ring-white/10 md:border-[8px] md:border-slate-900 dark:md:border-slate-800'
            : 'max-w-2xl min-h-screen md:rounded-none'
        } ${theme === 'dark' ? 'bg-[#121316]' : 'bg-[#f8f9fc]'}`}
        style={{
          boxShadow: isPhoneFrame ? '0 25px 60px -15px rgba(0, 0, 0, 0.4)' : 'none'
        }}
      >
        {/* Android Native Status Bar */}
        <div
          className={`w-full px-6 pt-3 pb-1 flex items-center justify-between z-30 select-none text-[13px] font-semibold tracking-tight ${
            theme === 'dark'
              ? 'text-slate-200 bg-[#121316]'
              : 'text-slate-800 bg-[#f8f9fc]'
          }`}
        >
          {/* Time display */}
          <span className="font-mono text-xs font-semibold pl-1">
            {currentTime || '10:24'}
          </span>

          {/* Android Punch Hole Camera (on phone mockup) */}
          <div className="w-3.5 h-3.5 rounded-full bg-black/90 dark:bg-black/90 border border-slate-700/50 shadow-inner flex items-center justify-center">
            <div className="w-1 h-1 rounded-full bg-blue-900/60" />
          </div>

          {/* System Icons: 5G, Wi-Fi, Battery */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-[10px] font-bold tracking-tight">5G</span>
            <Signal className="w-3 h-3" />
            <Wifi className="w-3.5 h-3.5" />
            {/* Battery Indicator */}
            <div className="flex items-center gap-0.5 ml-0.5">
              <span className="text-[10px] font-mono">98%</span>
              <div className="w-4 h-2.5 border border-current rounded-xs p-[1px] flex items-center">
                <div className="w-full h-full bg-current rounded-2xs" />
              </div>
            </div>
          </div>
        </div>

        {/* Inner App Content Screen */}
        <div className="flex-1 flex flex-col relative overflow-y-auto no-scrollbar">
          {children}
        </div>

        {/* Android Bottom Gesture Navigation Pill */}
        <div
          className={`w-full py-2 flex items-center justify-center select-none z-30 ${
            theme === 'dark' ? 'bg-[#121316]' : 'bg-[#f8f9fc]'
          }`}
        >
          <div className="w-32 h-1 rounded-full bg-slate-400/50 dark:bg-slate-600/60 transition-all hover:bg-slate-500" />
        </div>
      </div>
    </div>
  );
};
