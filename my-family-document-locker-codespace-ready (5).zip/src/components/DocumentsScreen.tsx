import React, { useState } from 'react';
import {
  Search,
  X,
  Filter,
  Eye,
  EyeOff,
  Download,
  Trash2,
  Edit2,
  FileText,
  Plus,
  Shield,
  Star,
  Share2,
  Clock,
  Sparkles,
  AlertCircle,
  FileUp
} from 'lucide-react';
import { DocumentCategory, ExpiryStatus, FamilyMember, LockerDocument } from '../types';
import { getExpiryStatus, CATEGORY_CONFIG } from '../utils/documentUtils';

interface DocumentsScreenProps {
  documents: LockerDocument[];
  familyMembers: FamilyMember[];
  selectedCategoryFilter?: DocumentCategory | 'All';
  onSelectCategoryFilter: (category: DocumentCategory | 'All') => void;
  onViewDocument: (doc: LockerDocument) => void;
  onEditDocument: (doc: LockerDocument) => void;
  onDeleteDocument: (docId: string) => void;
  onDownloadDocument: (doc: LockerDocument) => void;
  onToggleFavorite: (docId: string) => void;
  onReplaceDocument: (doc: LockerDocument) => void;
  onAddNewDocument: () => void;
}

export const DocumentsScreen: React.FC<DocumentsScreenProps> = ({
  documents,
  familyMembers,
  selectedCategoryFilter = 'All',
  onSelectCategoryFilter,
  onViewDocument,
  onEditDocument,
  onDeleteDocument,
  onDownloadDocument,
  onToggleFavorite,
  onReplaceDocument,
  onAddNewDocument
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamilyFilter, setSelectedFamilyFilter] = useState<string>('All');
  const [selectedExpiryFilter, setSelectedExpiryFilter] = useState<'All' | ExpiryStatus>('All');
  const [activeVaultTab, setActiveVaultTab] = useState<'all' | 'favorites' | 'expiring' | 'recent'>('all');
  const [revealedDocIds, setRevealedDocIds] = useState<Record<string, boolean>>({});
  const [docToDelete, setDocToDelete] = useState<LockerDocument | null>(null);

  // Toggle reveal of masked document number
  const toggleReveal = (docId: string) => {
    setRevealedDocIds((prev) => ({
      ...prev,
      [docId]: !prev[docId]
    }));
  };

  const CATEGORIES: ('All' | DocumentCategory)[] = [
    'All',
    'Aadhaar',
    'PAN',
    'Passport',
    'Driving Licence',
    'Voter ID',
    'Ration Card',
    'Birth Certificate',
    'Marriage Certificate',
    'Education',
    'Insurance',
    'Bank',
    'Property',
    'Vehicle',
    'Other'
  ];

  // Filter documents
  const filteredDocs = documents.filter((doc) => {
    // Vault Section Tab
    if (activeVaultTab === 'favorites' && !doc.isFavorite) return false;
    if (activeVaultTab === 'expiring') {
      const { status } = getExpiryStatus(doc.expiryDate);
      if (status !== 'EXPIRING_SOON' && status !== 'EXPIRED') return false;
    }

    // Search Query (Handles name, category, person, tags, notes, and document number!)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = doc.name.toLowerCase().includes(q);
      const matchCat = doc.category.toLowerCase().includes(q);
      const matchNumber = doc.documentNumber.toLowerCase().includes(q);
      const matchMasked = doc.maskedNumber.toLowerCase().includes(q);
      const matchFamily = doc.familyMemberName.toLowerCase().includes(q);
      const matchNotes = (doc.notes || '').toLowerCase().includes(q);
      const matchTags = (doc.tags || []).some((t) => t.toLowerCase().includes(q));

      if (
        !matchName &&
        !matchCat &&
        !matchNumber &&
        !matchMasked &&
        !matchFamily &&
        !matchNotes &&
        !matchTags
      ) {
        return false;
      }
    }

    // Category Filter
    if (selectedCategoryFilter !== 'All' && doc.category !== selectedCategoryFilter) {
      return false;
    }

    // Family Member Filter
    if (selectedFamilyFilter !== 'All' && doc.familyMemberId !== selectedFamilyFilter) {
      return false;
    }

    // Expiry Status Filter
    if (selectedExpiryFilter !== 'All') {
      const { status } = getExpiryStatus(doc.expiryDate);
      if (status !== selectedExpiryFilter) return false;
    }

    return true;
  });

  // Sort if recent tab is active
  const displayDocs = activeVaultTab === 'recent'
    ? [...filteredDocs].sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
    : filteredDocs;

  const handleShare = async (doc: LockerDocument) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: doc.name,
          text: `${doc.name} (${doc.category}) - ${doc.maskedNumber}`
        });
      } catch {
        // Ignored
      }
    } else {
      navigator.clipboard.writeText(`${doc.name} (${doc.category}) - ${doc.maskedNumber}`);
      alert('Document info copied to clipboard');
    }
  };

  return (
    <div className="flex-1 pb-24 px-4 pt-3 select-none animate-fadeIn space-y-3.5">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Document Vault
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {documents.length} secure {documents.length === 1 ? 'document' : 'documents'} in locker
          </p>
        </div>

        <button
          onClick={onAddNewDocument}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition-all active:scale-95 shadow-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Doc</span>
        </button>
      </div>

      {/* Vault Sections Filter Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-white/5 rounded-2xl text-xs overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveVaultTab('all')}
          className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer ${
            activeVaultTab === 'all'
              ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          All ({documents.length})
        </button>
        <button
          onClick={() => setActiveVaultTab('favorites')}
          className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1 transition-all cursor-pointer ${
            activeVaultTab === 'favorites'
              ? 'bg-white dark:bg-slate-800 text-amber-500 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Star className="w-3.5 h-3.5" />
          <span>Favorites</span>
        </button>
        <button
          onClick={() => setActiveVaultTab('expiring')}
          className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1 transition-all cursor-pointer ${
            activeVaultTab === 'expiring'
              ? 'bg-white dark:bg-slate-800 text-rose-500 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Expiring</span>
        </button>
        <button
          onClick={() => setActiveVaultTab('recent')}
          className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer ${
            activeVaultTab === 'recent'
              ? 'bg-white dark:bg-slate-800 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Recent
        </button>
      </div>

      {/* Powerful Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search by name, ID number, person, or category..."
          className="w-full h-11 pl-10 pr-9 rounded-2xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategoryFilter === cat;
          return (
            <button
              key={cat}
              onClick={() => onSelectCategoryFilter(cat)}
              className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white dark:bg-white/5 text-slate-600 dark:text-slate-400 border border-slate-200/80 dark:border-white/10 hover:border-blue-400'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Family Member & Expiry Dropdowns */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar text-xs pb-1">
        <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 shrink-0">
          <Filter className="w-3 h-3" /> Filter:
        </span>

        <select
          value={selectedFamilyFilter}
          onChange={(e) => setSelectedFamilyFilter(e.target.value)}
          className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs focus:outline-none shrink-0"
        >
          <option value="All">All Family Members</option>
          {familyMembers.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} ({m.relationship})
            </option>
          ))}
        </select>

        <select
          value={selectedExpiryFilter}
          onChange={(e) => setSelectedExpiryFilter(e.target.value as any)}
          className="px-2.5 py-1 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs focus:outline-none shrink-0"
        >
          <option value="All">All Expiry Statuses</option>
          <option value="VALID">🟢 Valid</option>
          <option value="EXPIRING_SOON">🟡 Expiring Soon (30d)</option>
          <option value="EXPIRED">🔴 Expired</option>
        </select>
      </div>

      {/* Document Cards List */}
      {displayDocs.length === 0 ? (
        <div className="p-8 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/70 dark:border-white/10 text-center space-y-3 mt-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/70 text-blue-500 mx-auto flex items-center justify-center">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              No documents found
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Add your family's Aadhaar, PAN, Passport, or Insurance policies.
            </p>
          </div>
          <button
            onClick={onAddNewDocument}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold shadow-xs hover:bg-blue-700 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add First Document</span>
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {displayDocs.map((doc) => {
            const { status, label, badgeColor } = getExpiryStatus(doc.expiryDate);
            const isRevealed = Boolean(revealedDocIds[doc.id]);
            const displayNumber = isRevealed ? doc.documentNumber : doc.maskedNumber;
            const categoryMeta = CATEGORY_CONFIG[doc.category] || CATEGORY_CONFIG.Other;

            return (
              <div
                key={doc.id}
                className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 hover:border-slate-300 dark:hover:border-white/20 transition-all shadow-xs space-y-3"
              >
                {/* Top Row: Thumbnail + Title + Favorite Button + Expiry Pill */}
                <div className="flex items-start gap-3">
                  {/* Thumbnail */}
                  <div
                    onClick={() => onViewDocument(doc)}
                    className="w-12 h-12 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-white/5 relative shrink-0 cursor-pointer group"
                  >
                    <img
                      src={doc.fileUrl}
                      alt={doc.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                    />
                    <div className="absolute bottom-0 right-0 px-1 py-0.2 rounded-tl-sm bg-black/70 text-[9px] font-bold text-white uppercase font-mono">
                      {doc.fileType}
                    </div>
                  </div>

                  {/* Document Title, Person, and Category */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <h4
                        onClick={() => onViewDocument(doc)}
                        className="text-xs font-bold text-slate-900 dark:text-white truncate cursor-pointer hover:text-blue-600 dark:hover:text-blue-400"
                      >
                        {doc.name}
                      </h4>

                      <div className="flex items-center gap-1.5 shrink-0">
                        {/* Favorite Star Button */}
                        <button
                          onClick={() => onToggleFavorite(doc.id)}
                          className={`p-1 rounded-lg transition-colors cursor-pointer ${
                            doc.isFavorite
                              ? 'text-amber-500 fill-amber-500'
                              : 'text-slate-300 hover:text-amber-500'
                          }`}
                          title={doc.isFavorite ? 'Remove from favorites' : 'Add to favorites'}
                        >
                          <Star className={`w-4 h-4 ${doc.isFavorite ? 'fill-current' : ''}`} />
                        </button>

                        {/* Expiry Status */}
                        <span
                          className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${badgeColor}`}
                        >
                          {label}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      <span className={`font-semibold ${categoryMeta.textLight} ${categoryMeta.textDark}`}>
                        {doc.category}
                      </span>
                      <span>·</span>
                      <span className="truncate">{doc.familyMemberName}</span>
                      {doc.isAadhaar && (
                        <>
                          <span>·</span>
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                            <Shield className="w-3 h-3" /> Masked
                          </span>
                        </>
                      )}
                      <span>·</span>
                      {/* Cloud Sync Status Indicator */}
                      <span className="text-[10px] flex items-center gap-0.5">
                        {doc.syncStatus === 'cloud-synced' ? (
                          <span className="text-emerald-600 dark:text-emerald-400" title="Cloud Synced">☁️ Synced</span>
                        ) : doc.syncStatus === 'sync-failed' ? (
                          <span className="text-rose-600 dark:text-rose-400 font-semibold" title={doc.syncError || "Sync failed"}>⚠️ Sync Failed</span>
                        ) : doc.syncStatus === 'syncing' ? (
                          <span className="text-amber-500 animate-pulse" title="Syncing to cloud">⏳ Syncing</span>
                        ) : (
                          <span className="text-blue-500" title="Available on this device only">📱 Device Only</span>
                        )}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Masked ID Number Card with Reveal Button */}
                <div className="flex items-center justify-between px-3 py-2 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-200/60 dark:border-white/5 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">ID No:</span>
                    <span className="font-mono font-bold tracking-wider text-slate-800 dark:text-slate-200">
                      {displayNumber}
                    </span>
                  </div>

                  <button
                    onClick={() => toggleReveal(doc.id)}
                    className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
                    title={isRevealed ? 'Mask number' : 'Reveal number temporarily'}
                  >
                    {isRevealed ? (
                      <EyeOff className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                    ) : (
                      <Eye className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>

                {/* Card Actions: View, Edit, Download, Share, Replace, Delete */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-white/5 text-xs">
                  <span className="text-[11px] text-slate-400 font-mono">
                    {doc.uploadDate}
                  </span>

                  <div className="flex items-center gap-1">
                    {/* View */}
                    <button
                      onClick={() => onViewDocument(doc)}
                      className="px-2.5 py-1 rounded-xl bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 text-blue-600 dark:text-blue-400 font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <Eye className="w-3 h-3" />
                      <span>View</span>
                    </button>

                    {/* Edit */}
                    <button
                      onClick={() => onEditDocument(doc)}
                      className="p-1.5 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                      title="Edit metadata"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Replace file */}
                    <button
                      onClick={() => onReplaceDocument(doc)}
                      className="p-1.5 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                      title="Replace document file"
                    >
                      <FileUp className="w-3.5 h-3.5" />
                    </button>

                    {/* Download */}
                    <button
                      onClick={() => onDownloadDocument(doc)}
                      className="p-1.5 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                      title="Download file"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>

                    {/* Share */}
                    <button
                      onClick={() => handleShare(doc)}
                      className="p-1.5 rounded-xl text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 transition-colors cursor-pointer"
                      title="Share document details"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      onClick={() => setDocToDelete(doc)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                      title="Delete document"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {docToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-xs bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 mx-auto flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </div>

            <div className="text-center">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Delete Document Permanently?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Are you sure you want to permanently delete <strong>{docToDelete.name}</strong>? This will remove both the cloud backup and the local encrypted vault copy. This cannot be undone.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => setDocToDelete(null)}
                className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteDocument(docToDelete.id);
                  setDocToDelete(null);
                }}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-xs font-semibold text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
