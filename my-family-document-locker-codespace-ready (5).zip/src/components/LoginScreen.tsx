import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  Sparkles,
  Users,
  EyeOff,
  AlertCircle,
  KeyRound,
  CheckCircle2
} from 'lucide-react';
import { authService } from '../services/authService';
import { isFirebaseConfigured } from '../config/firebase';
import { UserProfile } from '../types';

interface LoginScreenProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [localVaultMode, setLocalVaultMode] = useState(false);
  const [vaultName, setVaultName] = useState('');
  const [vaultEmail, setVaultEmail] = useState('');

  // Handle Real Google Sign-In via Firebase
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      if (!isFirebaseConfigured) {
        // Show message that Firebase credentials can be configured or open Local Vault
        setErrorMessage(
          'Firebase cloud credentials not yet configured in .env. You can continue securely in Local Encrypted Vault mode below.'
        );
        setLocalVaultMode(true);
        setIsLoading(false);
        return;
      }

      const userProfile = await authService.signInWithGoogle();
      onLoginSuccess(userProfile);
    } catch (err: any) {
      console.warn('Authentication error:', err);
      let message = err.message || 'Failed to authenticate with Google.';
      if (err.code === 'auth/popup-closed-by-user') {
        message = 'Sign-in cancelled. Please try again.';
      } else if (err.code === 'auth/network-request-failed') {
        message = 'Network error. Please check your internet connection.';
      }
      setErrorMessage(message);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Local Encrypted Vault mode
  const handleLocalVaultLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vaultName.trim()) {
      setErrorMessage('Please enter your name to initialize your personal vault.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const user = await authService.signInLocalVault(vaultName, vaultEmail);
      onLoginSuccess(user);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to initialize local vault');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between p-6 select-none animate-fadeIn">
      {/* Brand Header */}
      <div className="pt-6 flex flex-col items-center text-center">
        <div className="relative mb-5">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-blue-600 to-indigo-600 shadow-xl shadow-blue-500/25 flex items-center justify-center text-white">
            <ShieldCheck className="w-10 h-10" />
          </div>
          <div className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-emerald-500 border-2 border-white dark:border-[#121316] flex items-center justify-center text-white shadow-xs">
            <Lock className="w-3.5 h-3.5" />
          </div>
        </div>

        <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white mb-1.5">
          My Family Document Locker
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs leading-relaxed">
          Military-grade encrypted vault for your family's personal identification, policies, and secure text notes.
        </p>
      </div>

      {/* Feature Highlights */}
      <div className="my-5 p-4 rounded-2xl bg-white/70 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 shadow-xs space-y-3">
        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-900 dark:text-slate-200">
              Gemini Vision OCR & Expiry Intelligence
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Auto-extracts dates, names & sends 30/15/7-day renewal alerts.
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 shrink-0">
            <Users className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-900 dark:text-slate-200">
              Family Organization
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Organize files by Self, Spouse, Children, and Parents.
            </p>
          </div>
        </div>

        <div className="flex items-start gap-3">
          <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 shrink-0">
            <EyeOff className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-semibold text-slate-900 dark:text-slate-200">
              Zero External UIDAI Lookups
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Visual OCR only. IDs are masked (XXXX XXXX 1234) for privacy.
            </p>
          </div>
        </div>
      </div>

      {/* Error alert */}
      {errorMessage && (
        <div className="mb-3 p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 text-amber-800 dark:text-amber-200 text-xs flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <span className="leading-snug">{errorMessage}</span>
        </div>
      )}

      {/* Login Options */}
      <div className="space-y-3 pb-2">
        {localVaultMode ? (
          /* Form for Local Vault Mode */
          <form onSubmit={handleLocalVaultLogin} className="space-y-2.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Your Full Name *
              </label>
              <input
                type="text"
                required
                value={vaultName}
                onChange={(e) => setVaultName(e.target.value)}
                placeholder="e.g. Vault Owner"
                className="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Email Address (Optional)
              </label>
              <input
                type="email"
                value={vaultEmail}
                onChange={(e) => setVaultEmail(e.target.value)}
                placeholder="owner@example.com"
                className="w-full px-3 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-12 rounded-2xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              <span>{isLoading ? 'Creating Vault...' : 'Enter Encrypted Locker'}</span>
            </button>

            <button
              type="button"
              onClick={() => setLocalVaultMode(false)}
              className="w-full py-1 text-center text-xs text-slate-500 hover:underline cursor-pointer"
            >
              ← Back to Google Sign-In
            </button>
          </form>
        ) : (
          /* Primary Google Sign-In */
          <>
            <button
              onClick={handleGoogleSignIn}
              disabled={isLoading}
              className="w-full h-13 rounded-2xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-100 font-semibold text-sm flex items-center justify-center gap-3 shadow-xs hover:shadow transition-all active:scale-[0.98] cursor-pointer"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
                  <span>Connecting...</span>
                </div>
              ) : (
                <>
                  <svg className="w-5 h-5" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>Sign in with Google</span>
                </>
              )}
            </button>

            {/* Offline / Local Vault option */}
            <button
              onClick={() => setLocalVaultMode(true)}
              className="w-full py-2.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Or use Local Encrypted Vault (Offline)</span>
            </button>
          </>
        )}

        <p className="text-center text-[10px] text-slate-400 dark:text-slate-500 px-4 leading-normal pt-1">
          {isFirebaseConfigured
            ? 'Protected by Firebase Authentication and Firestore Security Rules.'
            : 'Running in Local Encrypted Vault mode with AES-GCM encryption.'}
        </p>
      </div>
    </div>
  );
};
