import React, { useState, useRef, useEffect } from 'react';
import {
  Users,
  Shield,
  Bell,
  Sun,
  Moon,
  Lock,
  Download,
  Upload,
  RotateCcw,
  LogOut,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  HardDrive,
  KeyRound,
  Fingerprint,
  Cloud,
  Check,
  Clock,
  AlertTriangle,
  RefreshCw,
  FileCheck,
  Loader2,
  Cpu,
  Sparkles
} from 'lucide-react';
import { AutoLockInterval, FamilyMember, LockerDocument, TextNote, UserProfile } from '../types';
import { formatFileSize } from '../utils/documentUtils';
import { saveStoredUser, saveStoredAutoLockInterval, clearHarmlessPreferences } from '../utils/storage';
import { isFirebaseConfigured, auth } from '../config/firebase';
import { backupService } from '../services/backupService';
import { pinService } from '../services/pinService';
import { encryptedIndexedDBService } from '../services/encryptedIndexedDBService';
import { googleDriveService, DriveConnectionStatus } from '../services/googleDriveService';
import { GoogleDriveModal } from './GoogleDriveModal';
import { aiRouter, AIMode, AISettings, AIStatusInfo } from '../services/aiRouter';

interface ProfileScreenProps {
  user: UserProfile;
  familyMembers: FamilyMember[];
  documents: LockerDocument[];
  textNotes: TextNote[];
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
  onNavigateToFamily: () => void;
  onNavigateToTextLocker: () => void;
  onOpenPinSetup: () => void;
  onLockVaultNow: () => void;
  onLogout: () => void;
  onDataReload: () => void;
  onRetryPendingSync: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  familyMembers,
  documents,
  textNotes,
  theme,
  onToggleTheme,
  onNavigateToFamily,
  onNavigateToTextLocker,
  onOpenPinSetup,
  onLockVaultNow,
  onLogout,
  onDataReload,
  onRetryPendingSync
}) => {
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showDeleteAccountConfirm, setShowDeleteAccountConfirm] = useState(false);
  const [deleteAccountInput, setDeleteAccountInput] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Backup & Restore states
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [backupPassword, setBackupPassword] = useState('');
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [backupError, setBackupError] = useState<string | null>(null);

  const [showRestoreModal, setShowRestoreModal] = useState(false);
  const [restorePassword, setRestorePassword] = useState('');
  const [restoreFileContent, setRestoreFileContent] = useState<string | null>(null);
  const [restorePreview, setRestorePreview] = useState<{ docCount: number; familyCount: number; noteCount: number } | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreError, setRestoreError] = useState<string | null>(null);

  // Auto-lock & Biometric
  const [autoLockInterval, setAutoLockInterval] = useState<AutoLockInterval>(user.autoLockInterval || '5m');
  const [biometricAvailable, setBiometricAvailable] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [biometryLabel, setBiometryLabel] = useState('Fingerprint / Face ID');

  // Google Drive state
  const [driveStatus, setDriveStatus] = useState<DriveConnectionStatus>(googleDriveService.getConnectionStatus());
  const [isConnectingDrive, setIsConnectingDrive] = useState(false);
  const [showDriveModal, setShowDriveModal] = useState(false);
  const [driveModalMode, setDriveModalMode] = useState<'backup' | 'restore'>('backup');
  const [showDisconnectConfirm, setShowDisconnectConfirm] = useState(false);

  // AI & Privacy Engine state
  const [aiSettings, setAiSettings] = useState<AISettings>(aiRouter.getSettings());
  const [aiStatus, setAiStatus] = useState<AIStatusInfo | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    pinService.isBiometricAvailable().then((res) => {
      setBiometricAvailable(res.available);
      if (res.biometryType) {
        setBiometryLabel(res.biometryType);
      }
    });
    pinService.isBiometricEnabled().then((enabled) => {
      setBiometricEnabled(enabled);
    });
    setDriveStatus(googleDriveService.getConnectionStatus());
    aiRouter.getStatus().then((status) => setAiStatus(status));
  }, []);

  // AI Mode change
  const handleAiModeChange = (mode: AIMode) => {
    const updated = aiRouter.updateSettings({ aiMode: mode });
    setAiSettings(updated);
    aiRouter.getStatus().then((s) => setAiStatus(s));
    showToast(`AI mode: ${mode === 'auto' ? 'Auto (Local First)' : mode === 'offline' ? '100% Offline' : 'Cloud Allowed'}`);
  };

  // Toggle Cloud AI
  const handleToggleCloudAi = (enabled: boolean) => {
    const updated = aiRouter.updateSettings({ cloudAiEnabled: enabled });
    setAiSettings(updated);
    aiRouter.getStatus().then((s) => setAiStatus(s));
    showToast(enabled ? 'Cloud AI enabled' : 'Cloud AI disabled');
  };

  // Toggle Document Cloud Processing
  const handleToggleDocCloud = (enabled: boolean) => {
    const updated = aiRouter.updateSettings({ documentCloudProcessing: enabled });
    setAiSettings(updated);
    showToast(enabled ? 'Cloud Document OCR enabled' : 'Cloud Document OCR disabled (Local only)');
  };

  // Connect Google Drive
  const handleConnectGoogleDrive = async () => {
    setIsConnectingDrive(true);
    try {
      const res = await googleDriveService.connect();
      setDriveStatus(googleDriveService.getConnectionStatus());
      showToast(`Google Drive connected: ${res.email || ''}`);
    } catch (err: any) {
      showToast(err.message || 'Could not connect Google Drive');
    } finally {
      setIsConnectingDrive(false);
    }
  };

  // Disconnect Google Drive
  const handleDisconnectGoogleDrive = () => {
    googleDriveService.disconnect();
    setDriveStatus(googleDriveService.getConnectionStatus());
    setShowDisconnectConfirm(false);
    showToast('Google Drive disconnected. Cloud backups preserved.');
  };

  // Auto-backup schedule change
  const handleAutoBackupChange = (schedule: 'off' | 'daily' | 'weekly') => {
    googleDriveService.setAutoBackupSchedule(schedule);
    setDriveStatus(googleDriveService.getConnectionStatus());
    showToast(`Automatic backup set to ${schedule}`);
  };

  // Storage usage
  const totalDocBytes = documents.reduce((acc, d) => acc + d.fileSize, 0);
  const totalNoteBytes = textNotes.reduce((acc, n) => acc + (n.content?.length || 0) * 2, 0);
  const totalBytes = totalDocBytes + totalNoteBytes;
  const maxStorageBytes = 15 * 1024 * 1024 * 1024; // 15 GB
  const percentUsed = Math.max(0.1, (totalBytes / maxStorageBytes) * 100);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Handle encrypted backup export
  const handleExportBackup = async () => {
    if (!backupPassword || backupPassword.length < 6) {
      setBackupError('Password must be at least 6 characters');
      return;
    }

    setIsBackingUp(true);
    setBackupError(null);

    try {
      await backupService.createEncryptedBackup(
        backupPassword,
        documents,
        familyMembers,
        textNotes
      );
      setShowBackupModal(false);
      setBackupPassword('');
      showToast('AES-256-GCM encrypted backup (.mfdbackup) created');
    } catch (err: any) {
      setBackupError(err.message || 'Backup failed');
    } finally {
      setIsBackingUp(false);
    }
  };

  // Handle restore file selection
  const handleRestoreFileSelected = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setRestoreFileContent(content);
      setRestorePreview(null);
      setRestoreError(null);
      setShowRestoreModal(true);
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Preview restore
  const handlePreviewRestore = async () => {
    if (!restoreFileContent || !restorePassword) {
      setRestoreError('Please enter your backup password');
      return;
    }

    setIsRestoring(true);
    setRestoreError(null);

    try {
      const decrypted = await backupService.decryptBackup(restoreFileContent, restorePassword);
      setRestorePreview({
        docCount: decrypted.documents?.length || 0,
        familyCount: decrypted.family?.length || 0,
        noteCount: decrypted.notes?.length || 0
      });
    } catch (err: any) {
      setRestoreError(err.message || 'Invalid backup password.');
    } finally {
      setIsRestoring(false);
    }
  };

  // Commit restore into encrypted vault
  const handleConfirmRestore = async () => {
    if (!restoreFileContent || !restorePassword) return;

    setIsRestoring(true);
    try {
      const decrypted = await backupService.decryptBackup(restoreFileContent, restorePassword);

      for (const d of decrypted.documents || []) {
        await encryptedIndexedDBService.putEncryptedItem(d.id, 'document', d);
      }
      for (const f of decrypted.family || []) {
        await encryptedIndexedDBService.putEncryptedItem(f.id, 'family', f);
      }
      for (const n of decrypted.notes || []) {
        await encryptedIndexedDBService.putEncryptedItem(n.id, 'note', n);
      }

      setShowRestoreModal(false);
      setRestoreFileContent(null);
      setRestorePassword('');
      setRestorePreview(null);
      onDataReload();
      showToast('Encrypted backup successfully restored to vault!');
    } catch (err: any) {
      setRestoreError(err.message || 'Failed to restore backup.');
    } finally {
      setIsRestoring(false);
    }
  };

  // Handle auto-lock change
  const handleAutoLockChange = (interval: AutoLockInterval) => {
    setAutoLockInterval(interval);
    saveStoredAutoLockInterval(interval);
    const updated = { ...user, autoLockInterval: interval };
    saveStoredUser(updated);
    showToast(`Auto-lock set to ${interval === 'never' ? 'Never' : interval}`);
  };

  // Handle biometric toggle
  const handleToggleBiometric = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const nextVal = e.target.checked;
    setBiometricEnabled(nextVal);
    await pinService.setBiometricEnabled(nextVal);
    showToast(nextVal ? 'Biometric authentication enabled' : 'Biometric authentication disabled');
  };

  // Clear local cache
  const handleClearCache = async () => {
    if (confirm('Clear local offline cache? Your cloud records will remain safe.')) {
      clearHarmlessPreferences();
      showToast('Local cache cleared.');
      onDataReload();
    }
  };

  // Account deletion
  const handleDeleteAccount = async () => {
    if (deleteAccountInput.trim().toUpperCase() !== 'DELETE') {
      alert('Please type DELETE to confirm account deletion.');
      return;
    }

    try {
      // Clear all local encrypted vault items
      await encryptedIndexedDBService.clearAllVaultData();
      clearHarmlessPreferences();
      setShowDeleteAccountConfirm(false);
      onLogout();
    } catch (err) {
      console.warn('Account deletion error:', err);
    }
  };

  const syncFailedCount = documents.filter((d) => d.syncStatus === 'sync-failed').length;
  const deviceOnlyCount = documents.filter((d) => d.syncStatus === 'device-only').length;

  return (
    <div className="flex-1 pb-24 px-4 pt-3 select-none animate-fadeIn space-y-4">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-2xl bg-slate-900/95 dark:bg-white text-white dark:text-slate-900 text-xs font-semibold shadow-xl flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* User Card */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 flex items-center justify-between shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-bold text-lg flex items-center justify-center ring-2 ring-blue-500/30 shadow-xs">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName}
                className="w-full h-full rounded-2xl object-cover"
              />
            ) : (
              (user.displayName || 'V').charAt(0).toUpperCase()
            )}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {user.displayName || 'Vault Owner'}
              </h3>
              <span className="p-0.5 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-600 dark:text-blue-400">
                <Check className="w-3 h-3 stroke-[3]" />
              </span>
            </div>
            {user.email && (
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {user.email}
              </p>
            )}
            <div className="flex items-center gap-1 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 mt-1">
              <ShieldCheck className="w-3 h-3" />
              <span>
                {user.authProvider === 'firebase-google'
                  ? 'Google Account Connected'
                  : 'Local Encrypted Vault Active'}
              </span>
            </div>
          </div>
        </div>

        {/* Lock Vault Now Button */}
        <button
          onClick={onLockVaultNow}
          className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors cursor-pointer"
          title="Lock Vault Now"
        >
          <Lock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
        </button>
      </div>

      {/* Cloud Sync Status Banner */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-2.5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-blue-500" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Cloud Sync & Storage
            </h4>
          </div>
          {(syncFailedCount > 0 || deviceOnlyCount > 0) && (
            <button
              onClick={onRetryPendingSync}
              className="px-2.5 py-1 rounded-lg bg-blue-600 text-white text-[11px] font-semibold flex items-center gap-1 hover:bg-blue-700 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry Sync</span>
            </button>
          )}
        </div>

        <div className="flex items-center justify-between text-xs pt-1">
          <div className="space-y-0.5">
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              {isFirebaseConfigured ? 'Firestore & Cloud Storage Connected' : 'Local Device Vault'}
            </p>
            <p className="text-[11px] text-slate-500">
              {syncFailedCount > 0
                ? `${syncFailedCount} document(s) pending sync`
                : 'All documents secured and synchronized'}
            </p>
          </div>
          <span className="text-[11px] px-2 py-0.5 rounded-full font-semibold bg-emerald-100 dark:bg-emerald-950/70 text-emerald-600 dark:text-emerald-400">
            ☁️ Synced
          </span>
        </div>
      </div>

      {/* Quick Navigation Sections */}
      <div className="space-y-2">
        <button
          onClick={onNavigateToFamily}
          className="w-full p-3.5 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 hover:border-blue-400 flex items-center justify-between transition-all cursor-pointer shadow-xs active:scale-[0.99] group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-purple-100 dark:bg-purple-950/80 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                Family Management
              </h4>
              <p className="text-[11px] text-slate-500">
                {familyMembers.length} {familyMembers.length === 1 ? 'member' : 'members'} registered
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-500 group-hover:translate-x-0.5 transition-all" />
        </button>

        <button
          onClick={onNavigateToTextLocker}
          className="w-full p-3.5 rounded-2xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 hover:border-blue-400 flex items-center justify-between transition-all cursor-pointer shadow-xs active:scale-[0.99] group text-left"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                Text Locker
              </h4>
              <p className="text-[11px] text-slate-500">
                {textNotes.length} secure notes & accounts
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-500 group-hover:translate-x-0.5 transition-all" />
        </button>
      </div>

      {/* Security & PIN Settings (Phase 23) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-3.5 shadow-xs">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Security & Vault Access
          </h4>
        </div>

        {/* Change PIN */}
        <div className="flex items-center justify-between py-1 text-xs">
          <div>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              Vault Access PIN
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              PBKDF2-SHA256 derived AES-256 vault key
            </p>
          </div>
          <button
            onClick={onOpenPinSetup}
            className="px-3 py-1.5 rounded-xl bg-blue-600 text-white font-semibold text-xs hover:bg-blue-700 transition-colors cursor-pointer"
          >
            Change PIN
          </button>
        </div>

        {/* Biometric Lock */}
        {biometricAvailable && (
          <div className="flex items-center justify-between py-1 text-xs border-t border-slate-100 dark:border-white/5 pt-2">
            <div className="flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-purple-500" />
              <div>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {biometryLabel}
                </p>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">
                  Unlock vault with fingerprint or face
                </p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={biometricEnabled}
              onChange={handleToggleBiometric}
              className="w-4 h-4 text-blue-600 rounded-sm focus:ring-blue-500 cursor-pointer"
            />
          </div>
        )}

        {/* Auto-Lock Interval (Phase 24) */}
        <div className="flex items-center justify-between py-1 text-xs border-t border-slate-100 dark:border-white/5 pt-2">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-amber-500" />
            <div>
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Auto-Lock Timer
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Lock after inactivity or app switch
              </p>
            </div>
          </div>
          <select
            value={autoLockInterval}
            onChange={(e) => handleAutoLockChange(e.target.value as AutoLockInterval)}
            className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:outline-none"
          >
            <option value="immediately">Immediately</option>
            <option value="1m">1 minute</option>
            <option value="5m">5 minutes</option>
            <option value="15m">15 minutes</option>
            <option value="never">Never</option>
          </select>
        </div>

        {/* Lock Vault Now */}
        <button
          onClick={onLockVaultNow}
          className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-white/5 dark:hover:bg-white/10 text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <Lock className="w-3.5 h-3.5" />
          <span>Lock Vault Now</span>
        </button>
      </div>

      {/* AI & Privacy Engine Settings (Hybrid AI Router) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-3.5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              AI & Privacy Engine
            </h4>
          </div>
          {aiStatus && (
            <span
              className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                aiStatus.badgeColor === 'emerald'
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200'
                  : 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border-blue-200'
              }`}
            >
              {aiStatus.badgeText}
            </span>
          )}
        </div>

        {/* AI Mode Selector */}
        <div className="flex items-center justify-between py-1 text-xs">
          <div>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              AI Processing Mode
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {aiSettings.aiMode === 'auto'
                ? 'Auto: On-device OCR/Nano first, safe fallback'
                : aiSettings.aiMode === 'offline'
                ? '100% Offline: Zero internet communication'
                : 'Cloud Allowed: Enhanced cloud assistance'}
            </p>
          </div>
          <select
            value={aiSettings.aiMode}
            onChange={(e) => handleAiModeChange(e.target.value as AIMode)}
            className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:outline-none"
          >
            <option value="auto">Auto (Local First)</option>
            <option value="offline">Offline Only</option>
            <option value="cloud">Cloud Allowed</option>
          </select>
        </div>

        {/* Offline Engine Readiness */}
        <div className="flex items-center justify-between py-1 text-xs border-t border-slate-100 dark:border-white/5 pt-2">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-emerald-500" />
            <div>
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                On-Device Engine
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {aiStatus?.hasNano
                  ? 'Gemini Nano (Hardware Accelerated)'
                  : 'ML Kit & Tesseract OCR (Offline Ready)'}
              </p>
            </div>
          </div>
          <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
            Available
          </span>
        </div>

        {/* Cloud AI Toggle */}
        <div className="flex items-center justify-between py-1 text-xs border-t border-slate-100 dark:border-white/5 pt-2">
          <div>
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              Cloud AI Assistant
            </p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Enable server-side Gemini 3.8 Flash for complex questions
            </p>
          </div>
          <input
            type="checkbox"
            checked={aiSettings.cloudAiEnabled}
            onChange={(e) => handleToggleCloudAi(e.target.checked)}
            className="w-4 h-4 text-purple-600 rounded-sm focus:ring-purple-500 cursor-pointer"
          />
        </div>

        {/* Document Cloud Processing (Off by default for privacy) */}
        <div className="flex items-center justify-between py-1 text-xs border-t border-slate-100 dark:border-white/5 pt-2">
          <div>
            <div className="flex items-center gap-1.5">
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Cloud Document OCR
              </p>
              <span className="px-1.5 py-0.2 rounded text-[10px] bg-slate-100 dark:bg-white/10 text-slate-500">
                Off by default
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Send images to cloud only if offline OCR fails
            </p>
          </div>
          <input
            type="checkbox"
            checked={aiSettings.documentCloudProcessing}
            onChange={(e) => handleToggleDocCloud(e.target.checked)}
            className="w-4 h-4 text-purple-600 rounded-sm focus:ring-purple-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Storage Breakdown */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-3 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-cyan-500" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Storage Usage
            </h4>
          </div>
          <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300">
            {formatFileSize(totalBytes)} / 15 GB
          </span>
        </div>

        <div className="w-full h-2 rounded-full bg-slate-100 dark:bg-white/10 overflow-hidden flex">
          <div className="h-full bg-blue-600" style={{ width: `${percentUsed}%` }} />
        </div>

        <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-500 dark:text-slate-400 pt-1">
          <div>
            <span>Documents ({documents.length}):</span>{' '}
            <strong className="text-slate-700 dark:text-slate-200 font-mono">
              {formatFileSize(totalDocBytes)}
            </strong>
          </div>
          <div>
            <span>Notes ({textNotes.length}):</span>{' '}
            <strong className="text-slate-700 dark:text-slate-200 font-mono">
              {formatFileSize(totalNoteBytes)}
            </strong>
          </div>
        </div>
      </div>

      {/* Cloud Backup — Google Drive (Feature 1) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-3.5 shadow-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cloud className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Cloud Backup • Google Drive
            </h4>
          </div>
          <div className="flex items-center gap-1.5 text-xs font-semibold">
            {driveStatus.isConnected ? (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[11px]">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Google Drive Connected
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-white/5 text-slate-500 border border-slate-200 dark:border-white/10 text-[11px]">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                Not Connected
              </span>
            )}
          </div>
        </div>

        {/* Last Backup Display */}
        <div className="p-3 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-400">
            <Clock className="w-3.5 h-3.5" />
            <span>Last Backup:</span>
          </div>
          <span className="font-semibold text-slate-800 dark:text-slate-200 font-mono">
            {driveStatus.lastBackupDate || 'Never'}
          </span>
        </div>

        {/* Actions */}
        {!driveStatus.isConnected ? (
          <button
            onClick={handleConnectGoogleDrive}
            disabled={isConnectingDrive}
            className="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs active:scale-[0.99]"
          >
            {isConnectingDrive ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Cloud className="w-4 h-4" />
            )}
            <span>Connect Google Drive</span>
          </button>
        ) : (
          <div className="space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setDriveModalMode('backup');
                  setShowDriveModal(true);
                }}
                className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs active:scale-[0.99]"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Backup Now</span>
              </button>
              <button
                onClick={() => {
                  setDriveModalMode('restore');
                  setShowDriveModal(true);
                }}
                className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs active:scale-[0.99]"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Restore from Google Drive</span>
              </button>
            </div>

            {/* Automatic Backup Selection */}
            <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-100 dark:border-white/5">
              <span className="text-slate-600 dark:text-slate-400">Automatic Backup:</span>
              <select
                value={driveStatus.autoBackupSchedule || 'off'}
                onChange={(e) => handleAutoBackupChange(e.target.value as any)}
                className="px-2.5 py-1 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold focus:outline-none"
              >
                <option value="off">Off</option>
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
              </select>
            </div>

            {/* Disconnect Button */}
            <button
              onClick={() => setShowDisconnectConfirm(true)}
              className="w-full py-1 text-[11px] text-slate-400 hover:text-rose-500 transition-colors cursor-pointer text-center"
            >
              Disconnect Google Drive
            </button>
          </div>
        )}
      </div>

      {/* Encrypted Backup & Restore (.mfdbackup) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-2.5 shadow-xs">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
            Encrypted Backup & Restore (.mfdbackup)
          </h4>
        </div>

        <p className="text-[11px] text-slate-500">
          Backups are encrypted using AES-256-GCM. Plaintext is never written to disk.
        </p>

        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => {
              setBackupPassword('');
              setBackupError(null);
              setShowBackupModal(true);
            }}
            className="p-3 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200/60 dark:border-white/5 flex items-center justify-center gap-2 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4 text-blue-500" />
            <span>Create Backup</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="p-3 rounded-2xl bg-slate-50 hover:bg-slate-100 dark:bg-white/5 dark:hover:bg-white/10 border border-slate-200/60 dark:border-white/5 flex items-center justify-center gap-2 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
          >
            <Upload className="w-4 h-4 text-emerald-500" />
            <span>Restore Backup</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleRestoreFileSelected}
            accept=".mfdbackup,application/octet-stream"
            className="hidden"
          />
        </div>
      </div>

      {/* Privacy & Account Deletion (Phase 23 & 25) */}
      <div className="p-4 rounded-3xl bg-white dark:bg-white/5 border border-slate-200/80 dark:border-white/10 space-y-2 shadow-xs">
        <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
          Privacy & Cache
        </h4>

        <button
          onClick={handleClearCache}
          className="w-full py-2.5 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl bg-slate-50 dark:bg-white/5 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Clear Local Cache</span>
        </button>

        <button
          onClick={() => {
            setDeleteAccountInput('');
            setShowDeleteAccountConfirm(true);
          }}
          className="w-full py-2.5 text-xs text-rose-600 hover:text-rose-700 rounded-xl bg-rose-50 dark:bg-rose-950/20 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          <span>Delete Account & Wipe Vault</span>
        </button>
      </div>

      {/* Logout */}
      <button
        onClick={() => setShowLogoutConfirm(true)}
        className="w-full py-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 font-semibold text-xs flex items-center justify-center gap-2 border border-rose-200/70 dark:border-rose-900/40 hover:bg-rose-100 dark:hover:bg-rose-950/50 transition-colors cursor-pointer"
      >
        <LogOut className="w-4 h-4" />
        <span>Logout from Family Locker</span>
      </button>

      {/* Brand & Developer Footer */}
      <div className="py-4 text-center space-y-1 select-none">
        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
          My Family Document Locker
        </p>
        <p className="text-[11px] text-slate-500 dark:text-slate-400">
          Developed by <strong>Rupesh Patil</strong> • <strong>RP Tech Hub</strong>
        </p>
        <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">
          © 2026 RP Tech Hub. All Rights Reserved.
        </p>
      </div>

      {/* Encrypted Backup Creation Modal */}
      {showBackupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 space-y-4">
            <div className="flex items-center gap-2">
              <Download className="w-5 h-5 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Create Encrypted Backup
              </h3>
            </div>

            <p className="text-xs text-slate-500">
              Choose a strong password. This password is required to decrypt and restore your .mfdbackup file.
            </p>

            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                Backup Password (min 6 chars)
              </label>
              <input
                type="password"
                value={backupPassword}
                onChange={(e) => setBackupPassword(e.target.value)}
                placeholder="Enter backup password"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {backupError && (
              <p className="text-xs text-rose-500 font-medium">{backupError}</p>
            )}

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowBackupModal(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isBackingUp}
                onClick={handleExportBackup}
                className="flex-1 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-xs font-semibold text-white cursor-pointer"
              >
                {isBackingUp ? 'Encrypting...' : 'Export'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Encrypted Backup Restore Modal */}
      {showRestoreModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-sm bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 space-y-4">
            <div className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Restore Encrypted Backup
              </h3>
            </div>

            {!restorePreview ? (
              <>
                <p className="text-xs text-slate-500">
                  Enter the password you used when creating this backup file to decrypt and preview its contents.
                </p>

                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                    Backup Password
                  </label>
                  <input
                    type="password"
                    value={restorePassword}
                    onChange={(e) => setRestorePassword(e.target.value)}
                    placeholder="Enter backup password"
                    className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {restoreError && (
                  <p className="text-xs text-rose-500 font-medium">{restoreError}</p>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowRestoreModal(false)}
                    className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={isRestoring}
                    onClick={handlePreviewRestore}
                    className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white cursor-pointer"
                  >
                    {isRestoring ? 'Decrypting...' : 'Validate'}
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/40 text-xs space-y-1.5">
                  <p className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4" />
                    <span>Backup Decrypted Successfully</span>
                  </p>
                  <ul className="text-[11px] text-emerald-700 dark:text-emerald-400 space-y-0.5">
                    <li>• Documents: {restorePreview.docCount}</li>
                    <li>• Family Members: {restorePreview.familyCount}</li>
                    <li>• Text Notes: {restorePreview.noteCount}</li>
                  </ul>
                </div>

                <p className="text-xs text-slate-500">
                  Restoring will merge these records into your current encrypted vault.
                </p>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setRestorePreview(null)}
                    className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    disabled={isRestoring}
                    onClick={handleConfirmRestore}
                    className="flex-1 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-xs font-semibold text-white cursor-pointer"
                  >
                    Confirm Restore
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Account Deletion Dialog (Phase 25) */}
      {showDeleteAccountConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-xs bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 space-y-3.5">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>

            <div className="text-center">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Delete Account & Wipe Vault?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                This permanently deletes all your documents, family profiles, text notes, and cloud files. This action cannot be reversed.
              </p>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] text-slate-400">
                Type <strong>DELETE</strong> to confirm:
              </label>
              <input
                type="text"
                value={deleteAccountInput}
                onChange={(e) => setDeleteAccountInput(e.target.value)}
                placeholder="DELETE"
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-rose-300 dark:border-rose-900/50 text-xs text-center font-bold tracking-widest text-rose-600 focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => setShowDeleteAccountConfirm(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteAccount}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-xs font-semibold text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Permanently Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Logout Confirmation Dialog */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-xs bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 mx-auto flex items-center justify-center">
              <LogOut className="w-5 h-5" />
            </div>

            <div className="text-center">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Log Out?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Your locker documents remain safe and encrypted in your vault.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowLogoutConfirm(false);
                  onLogout();
                }}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-xs font-semibold text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Log Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Google Drive Backup & Restore Modal */}
      <GoogleDriveModal
        isOpen={showDriveModal}
        mode={driveModalMode}
        documents={documents}
        familyMembers={familyMembers}
        textNotes={textNotes}
        onClose={() => {
          setShowDriveModal(false);
          setDriveStatus(googleDriveService.getConnectionStatus());
        }}
        onDataRestored={() => {
          setShowDriveModal(false);
          onDataReload();
          showToast('Vault data restored from Google Drive!');
        }}
        onBackupSuccess={(fileName) => {
          setDriveStatus(googleDriveService.getConnectionStatus());
          showToast(`Backup ${fileName} uploaded to Google Drive!`);
        }}
      />

      {/* Disconnect Google Drive Dialog */}
      {showDisconnectConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-xs bg-white dark:bg-[#1a1b22] rounded-3xl p-5 shadow-2xl border border-slate-200 dark:border-white/10 space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-950/70 text-amber-600 mx-auto flex items-center justify-center">
              <Cloud className="w-5 h-5" />
            </div>

            <div className="text-center">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Disconnect Google Drive?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Disconnect Google Drive? Your existing backups will remain in Google Drive.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => setShowDisconnectConfirm(false)}
                className="flex-1 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleDisconnectGoogleDrive}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-xs font-semibold text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Disconnect
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
