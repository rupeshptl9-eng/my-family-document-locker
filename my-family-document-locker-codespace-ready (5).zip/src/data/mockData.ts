import { FamilyMember, LockerDocument, TextNote, UserProfile, NotificationItem } from '../types';

export const INITIAL_USER: UserProfile = {
  uid: 'unauthenticated',
  displayName: '',
  email: '',
  photoURL: '',
  isLoggedIn: false,
  pinLockEnabled: false,
  theme: 'system'
};

export const INITIAL_FAMILY: FamilyMember[] = [];
export const INITIAL_DOCUMENTS: LockerDocument[] = [];
export const INITIAL_TEXT_NOTES: TextNote[] = [];
export const INITIAL_NOTIFICATIONS: NotificationItem[] = [];
