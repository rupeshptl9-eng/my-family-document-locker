/**
 * Family Service
 * Syncs family member profiles with Firestore and encrypted IndexedDB.
 */

import { collection, doc, getDocs, setDoc, deleteDoc } from 'firebase/firestore';
import { db, isFirebaseConfigured, handleFirestoreError, OperationType } from '../config/firebase';
import { FamilyMember } from '../types';
import { encryptedIndexedDBService } from './encryptedIndexedDBService';
import { vaultKeyManager } from './vaultKeyManager';

export const familyService = {
  async getFamilyMembers(userId: string): Promise<FamilyMember[]> {
    let localMembers: FamilyMember[] = [];
    if (vaultKeyManager.isUnlocked()) {
      try {
        localMembers = await encryptedIndexedDBService.getDecryptedItemsByType<FamilyMember>('family');
      } catch (err) {
        console.warn('Could not read family from encrypted IndexedDB:', err);
      }
    }

    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/familyMembers`;
      try {
        const familyRef = collection(db, path);
        const snap = await getDocs(familyRef);
        const members: FamilyMember[] = [];
        snap.forEach((d) => members.push({ id: d.id, ...d.data() } as FamilyMember));

        if (members.length > 0) {
          if (vaultKeyManager.isUnlocked()) {
            for (const m of members) {
              await encryptedIndexedDBService.putEncryptedItem(m.id, 'family', m).catch(() => {});
            }
          }
          return members;
        }
      } catch (e: any) {
        if (e?.code === 'permission-denied') {
          handleFirestoreError(e, OperationType.LIST, path);
        }
        console.warn('Firestore family get failed, using local cache:', e);
      }
    }

    return localMembers;
  },

  async saveFamilyMember(userId: string, member: FamilyMember): Promise<void> {
    if (vaultKeyManager.isUnlocked()) {
      await encryptedIndexedDBService.putEncryptedItem(member.id, 'family', member).catch(() => {});
    }

    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/familyMembers/${member.id}`;
      try {
        const ref = doc(db, `users/${userId}/familyMembers`, member.id);
        await setDoc(ref, { ...member, userId }, { merge: true });
      } catch (e: any) {
        if (e?.code === 'permission-denied') {
          handleFirestoreError(e, OperationType.WRITE, path);
        }
        console.warn('Firestore family set failed:', e);
      }
    }
  },

  async deleteFamilyMember(userId: string, memberId: string): Promise<void> {
    if (vaultKeyManager.isUnlocked()) {
      await encryptedIndexedDBService.deleteItem(memberId).catch(() => {});
    }

    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/familyMembers/${memberId}`;
      try {
        const ref = doc(db, `users/${userId}/familyMembers`, memberId);
        await deleteDoc(ref);
      } catch (e: any) {
        if (e?.code === 'permission-denied') {
          handleFirestoreError(e, OperationType.DELETE, path);
        }
        console.warn('Firestore family delete failed:', e);
      }
    }
  }
};
