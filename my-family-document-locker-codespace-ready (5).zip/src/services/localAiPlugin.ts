/**
 * Local AI & OCR Plugin Bridge
 * Interfaces with:
 * - Native Android LocalAI Capacitor plugin (ML Kit OCR & AICore / Gemini Nano)
 * - In-browser Tesseract.js fallback for development / web preview
 *
 * Statuses:
 * - AVAILABLE: Model or local OCR engine is ready for inference
 * - DOWNLOADABLE: Gemini Nano model is available for download on device
 * - DOWNLOADING: Model is currently downloading in background
 * - UNAVAILABLE: Hardware does not support Gemini Nano; local OCR used instead
 * - BUSY: Model is currently warming up or processing an existing request
 * - ERROR: An error occurred
 */

import { registerPlugin, Capacitor } from '@capacitor/core';
import { createWorker } from 'tesseract.js';

export type LocalAIStatus =
  | 'AVAILABLE'
  | 'DOWNLOADABLE'
  | 'DOWNLOADING'
  | 'UNAVAILABLE'
  | 'BUSY'
  | 'ERROR';

export interface LocalAICheckResult {
  status: LocalAIStatus;
  hasNano: boolean;
  hasAICore: boolean;
  hasOcr: boolean;
  message: string;
}

export interface LocalAIDocumentResult {
  rawText: string;
  engine: 'local' | 'ocr';
  confidence: number;
  isOffline: boolean;
}

interface NativeLocalAIPlugin {
  checkLocalAIAvailability(): Promise<LocalAICheckResult>;
  downloadLocalAIModel(): Promise<{ success: boolean; status: LocalAIStatus }>;
  warmupLocalAI(): Promise<{ status: string }>;
  getLocalAIStatus(): Promise<{ status: LocalAIStatus; isWarmedUp: boolean }>;
  runLocalDocumentAI(options: { imageBase64?: string; imageUri?: string }): Promise<LocalAIDocumentResult>;
  runLocalAI(options: { prompt: string }): Promise<{ response: string; engine: string }>;
}

const NativeLocalAI = registerPlugin<NativeLocalAIPlugin>('LocalAI');

// Web Tesseract worker singleton
let webOcrWorker: any = null;
let isWebWorkerLoading = false;
let isWarmedUp = false;

export const localAiPlugin = {
  /**
   * Check if Gemini Nano or Local ML Kit OCR is available
   */
  async checkLocalAIAvailability(): Promise<LocalAICheckResult> {
    if (Capacitor.isNativePlatform()) {
      try {
        const result = await NativeLocalAI.checkLocalAIAvailability();
        return result;
      } catch (err: any) {
        console.warn('Native LocalAI check error:', err);
        return {
          status: 'UNAVAILABLE',
          hasNano: false,
          hasAICore: false,
          hasOcr: true,
          message: 'Local OCR active; Gemini Nano unavailable'
        };
      }
    }

    // Web Environment
    return {
      status: 'AVAILABLE',
      hasNano: false,
      hasAICore: false,
      hasOcr: true,
      message: 'Offline Web OCR ready (Tesseract.js engine)'
    };
  },

  /**
   * Download on-device AI model if supported
   */
  async downloadLocalAIModel(): Promise<boolean> {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await NativeLocalAI.downloadLocalAIModel();
        return res.success;
      } catch {
        return false;
      }
    }
    return true;
  },

  /**
   * Warm up local AI and OCR engines without blocking UI
   */
  async warmupLocalAI(): Promise<void> {
    if (isWarmedUp) return;

    if (Capacitor.isNativePlatform()) {
      try {
        await NativeLocalAI.warmupLocalAI();
        isWarmedUp = true;
      } catch (err) {
        console.warn('Native LocalAI warmup warning:', err);
      }
      return;
    }

    // Initialize web worker in background
    if (!webOcrWorker && !isWebWorkerLoading) {
      isWebWorkerLoading = true;
      try {
        const worker = await createWorker('eng');
        webOcrWorker = worker;
        isWarmedUp = true;
      } catch (err) {
        console.warn('Web OCR worker warmup warning:', err);
      } finally {
        isWebWorkerLoading = false;
      }
    }
  },

  /**
   * Get current on-device AI readiness
   */
  async getLocalAIStatus(): Promise<{ status: LocalAIStatus; isWarmedUp: boolean }> {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await NativeLocalAI.getLocalAIStatus();
        return res;
      } catch {
        return { status: 'AVAILABLE', isWarmedUp };
      }
    }

    return {
      status: 'AVAILABLE',
      isWarmedUp: Boolean(webOcrWorker)
    };
  },

  /**
   * Run on-device OCR on document image
   */
  async runLocalDocumentAI(options: {
    imageBase64?: string;
    imageUri?: string;
  }): Promise<LocalAIDocumentResult> {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await NativeLocalAI.runLocalDocumentAI(options);
        return res;
      } catch (err: any) {
        console.warn('Native ML Kit OCR failed, falling back to Web OCR:', err);
      }
    }

    // Web OCR fallback using Tesseract.js
    if (!options.imageBase64 && !options.imageUri) {
      throw new Error('No image data provided for local OCR');
    }

    try {
      if (!webOcrWorker) {
        webOcrWorker = await createWorker('eng');
      }

      const imageSource = options.imageBase64
        ? `data:image/jpeg;base64,${options.imageBase64.replace(/^data:[^;]+;base64,/, '')}`
        : options.imageUri!;

      const ret = await webOcrWorker.recognize(imageSource);
      const text = ret.data.text || '';
      const confidence = Math.round(ret.data.confidence || 85);

      return {
        rawText: text,
        engine: 'ocr',
        confidence,
        isOffline: true
      };
    } catch (err: any) {
      console.error('Web OCR engine error:', err);
      throw new Error('Unable to read this document clearly. Please retake the photo.');
    }
  },

  /**
   * Run on-device text query
   */
  async runLocalAI(prompt: string): Promise<{ response: string; engine: string }> {
    if (Capacitor.isNativePlatform()) {
      try {
        const res = await NativeLocalAI.runLocalAI({ prompt });
        return res;
      } catch (err) {
        console.warn('Native LocalAI run prompt error:', err);
      }
    }

    return {
      response: 'Processed on device',
      engine: 'local'
    };
  }
};
