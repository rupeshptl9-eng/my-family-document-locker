import {
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, googleProvider, isFirebaseConfigured, handleFirestoreError, OperationType } from '../config/firebase';
import { UserProfile } from '../types';
import { getStoredUser, saveStoredUser } from '../utils/storage';

export const authService = {
  /**
   * Listen to authentication state changes
   */
  onAuthStateChanged(callback: (user: UserProfile | null) => void): () => void {
    if (isFirebaseConfigured && auth) {
      return onAuthStateChanged(auth, async (fbUser: FirebaseUser | null) => {
        if (fbUser) {
          const stored = getStoredUser();
          const profile: UserProfile = {
            uid: fbUser.uid,
            displayName: fbUser.displayName || 'Vault Owner',
            email: fbUser.email || '',
            photoURL: fbUser.photoURL || '',
            isLoggedIn: true,
            pinLockEnabled: stored?.pinLockEnabled ?? false,
            pinHash: stored?.pinHash,
            theme: stored?.theme || 'system',
            authProvider: 'firebase-google'
          };
          saveStoredUser(profile);

          // Sync user document to Firestore users/{userId}
          if (db) {
            try {
              const userDocRef = doc(db, 'users', fbUser.uid);
              await setDoc(userDocRef, {
                uid: fbUser.uid,
                displayName: profile.displayName,
                email: profile.email,
                photoURL: profile.photoURL,
                pinLockEnabled: profile.pinLockEnabled,
                theme: profile.theme === 'dark' ? 'dark' : 'light'
              }, { merge: true });
            } catch (err: any) {
              if (err?.code === 'permission-denied') {
                handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
              }
              console.warn('Could not sync user document to Firestore:', err);
            }
          }

          callback(profile);
        } else {
          const stored = getStoredUser();
          if (stored.isLoggedIn && stored.authProvider === 'local-vault') {
            callback(stored);
          } else {
            callback(null);
          }
        }
      });
    }

    // Local Vault mode auth state
    const currentUser = getStoredUser();
    callback(currentUser.isLoggedIn ? currentUser : null);
    return () => {};
  },

  /**
   * Sign in with Google (Firebase)
   */
  async signInWithGoogle(): Promise<UserProfile> {
    if (isFirebaseConfigured && auth && googleProvider) {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const stored = getStoredUser();
      const profile: UserProfile = {
        uid: fbUser.uid,
        displayName: fbUser.displayName || 'Vault Owner',
        email: fbUser.email || '',
        photoURL: fbUser.photoURL || '',
        isLoggedIn: true,
        pinLockEnabled: stored?.pinLockEnabled ?? false,
        pinHash: stored?.pinHash,
        theme: stored?.theme || 'system',
        authProvider: 'firebase-google'
      };
      saveStoredUser(profile);

      // Sync user document to Firestore
      if (db) {
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          await setDoc(userDocRef, {
            uid: fbUser.uid,
            displayName: profile.displayName,
            email: profile.email,
            photoURL: profile.photoURL,
            pinLockEnabled: profile.pinLockEnabled,
            theme: profile.theme === 'dark' ? 'dark' : 'light'
          }, { merge: true });
        } catch (err: any) {
          if (err?.code === 'permission-denied') {
            handleFirestoreError(err, OperationType.WRITE, `users/${fbUser.uid}`);
          }
          console.warn('Could not sync user document to Firestore:', err);
        }
      }

      return profile;
    }

    throw new Error('Firebase is not yet configured. Please use Local Encrypted Vault.');
  },

  /**
   * Sign in or initialize Local Encrypted Vault
   */
  async signInLocalVault(name: string, email: string): Promise<UserProfile> {
    const stored = getStoredUser();
    const profile: UserProfile = {
      uid: stored.uid && stored.uid !== 'unauthenticated' ? stored.uid : `local_${Date.now()}`,
      displayName: name.trim() || 'Vault Owner',
      email: email.trim(),
      photoURL: '',
      isLoggedIn: true,
      pinLockEnabled: stored.pinLockEnabled,
      pinHash: stored.pinHash,
      theme: stored.theme || 'system',
      authProvider: 'local-vault'
    };
    saveStoredUser(profile);
    return profile;
  },

  /**
   * Sign out
   */
  async signOut(): Promise<void> {
    if (isFirebaseConfigured && auth) {
      try {
        await firebaseSignOut(auth);
      } catch (err) {
        console.warn('Firebase signout error:', err);
      }
    }
    const current = getStoredUser();
    const loggedOut: UserProfile = {
      ...current,
      isLoggedIn: false
    };
    saveStoredUser(loggedOut);
  }
};
