/**
 * AI Service (Frontend Client)
 * Communicates with secure server-side Gemini endpoints.
 * Never handles raw GEMINI_API_KEY directly.
 */

import { AIExtractionResult, DocumentCategory, FamilyMember, LockerDocument, TextNote } from '../types';

export const aiService = {
  /**
   * Scan document image/pdf via server-side Gemini OCR
   */
  async scanDocument(
    base64Data: string,
    mimeType: string,
    filename: string,
    retries: number = 1
  ): Promise<AIExtractionResult> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 35000); // 35s timeout

    try {
      const response = await fetch('/api/ai/scan-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          imageBase64: base64Data,
          mimeType,
          filename
        })
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorBody = await response.json().catch(() => ({}));
        throw new Error(errorBody.error || `Server responded with status ${response.status}`);
      }

      const resJson = await response.json();
      if (!resJson.success || !resJson.data) {
        throw new Error(resJson.error || 'Invalid AI extraction response');
      }

      return resJson.data as AIExtractionResult;
    } catch (error: any) {
      clearTimeout(timeoutId);
      if (error.name === 'AbortError') {
        throw new Error('AI document scan timed out. Please verify your connection and try again.');
      }

      // Retry once if requested
      if (retries > 0) {
        console.warn('AI scan failed, attempting retry...');
        await new Promise((r) => setTimeout(r, 1500));
        return this.scanDocument(base64Data, mimeType, filename, retries - 1);
      }

      throw error;
    }
  },

  /**
   * Ask question to the Family Document Locker assistant
   */
  async askQuestion(
    query: string,
    documents: LockerDocument[],
    familyMembers: FamilyMember[],
    textNotes: TextNote[]
  ): Promise<string> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);

    try {
      const response = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          query,
          documents,
          familyMembers,
          textNotes
        })
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`AI assistant error (${response.status})`);
      }

      const resJson = await response.json();
      return resJson.answer || 'No response generated.';
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (err.name === 'AbortError') {
        throw new Error('AI Assistant response timed out.');
      }
      throw err;
    }
  },

  /**
   * Suggest category and tags for Text Locker notes
   */
  async analyzeText(title: string, content: string): Promise<{ suggestedCategory: string; suggestedTags: string[] }> {
    try {
      const response = await fetch('/api/ai/analyze-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content })
      });
      if (!response.ok) throw new Error('Analysis failed');
      return await response.json();
    } catch {
      return {
        suggestedCategory: 'Important notes',
        suggestedTags: ['note', 'secure']
      };
    }
  }
};
