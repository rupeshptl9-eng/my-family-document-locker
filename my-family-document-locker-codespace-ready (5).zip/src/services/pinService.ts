/**
 * PIN and Biometric Security Service
 * Strong cryptographic security:
 * - PBKDF2-SHA256 (100,000 iterations)
 * - Unique random 16-byte salt per user
 * - Native Android Biometrics (Fingerprint/Face) via @aparajita/capacitor-biometric-auth
 * - WebAuthn fallback for desktop browsers
 * - Failed attempt lockout
 * - Auto-lock management
 */

import { Capacitor } from '@capacitor/core';
import { BiometricAuth, BiometryType } from '@aparajita/capacitor-biometric-auth';
import { encryptedIndexedDBService, VaultSecurityConfig } from './encryptedIndexedDBService';
import { vaultKeyManager, computePinVerifier, hexToBuffer, deriveVaultKeyFromPin } from './vaultKeyManager';

const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 60 * 1000;

let failedAttempts = 0;
let lockoutUntil = 0;

export const pinService = {
  /**
   * Check if PIN is currently configured
   */
  async hasPinConfigured(): Promise<boolean> {
    return await encryptedIndexedDBService.hasVaultPinConfigured();
  },

  /**
   * Check if user is locked out due to failed attempts
   */
  getLockoutRemainingSeconds(): number {
    const now = Date.now();
    if (now < lockoutUntil) {
      return Math.ceil((lockoutUntil - now) / 1000);
    }
    return 0;
  },

  /**
   * Set new user PIN (PBKDF2-SHA256 derived)
   */
  async setupPin(newPin: string, autoLockMinutes: number = 5): Promise<boolean> {
    if (!/^\d{4,6}$/.test(newPin)) {
      throw new Error('PIN must be 4 to 6 numeric digits');
    }

    await encryptedIndexedDBService.setupVaultPin(newPin, autoLockMinutes);
    failedAttempts = 0;
    lockoutUntil = 0;
    return true;
  },

  /**
   * Verify entered PIN and unlock vault
   */
  async verifyUserPin(enteredPin: string): Promise<{ success: boolean; remainingAttempts?: number; lockedSeconds?: number }> {
    const remaining = this.getLockoutRemainingSeconds();
    if (remaining > 0) {
      return { success: false, lockedSeconds: remaining };
    }

    const hasPin = await this.hasPinConfigured();
    if (!hasPin) {
      return { success: true };
    }

    const isMatch = await encryptedIndexedDBService.unlockWithPin(enteredPin);
    if (isMatch) {
      failedAttempts = 0;
      lockoutUntil = 0;
      return { success: true };
    }

    failedAttempts += 1;
    if (failedAttempts >= MAX_FAILED_ATTEMPTS) {
      lockoutUntil = Date.now() + LOCKOUT_DURATION_MS;
      failedAttempts = 0;
      return { success: false, lockedSeconds: 60 };
    }

    return {
      success: false,
      remainingAttempts: MAX_FAILED_ATTEMPTS - failedAttempts
    };
  },

  /**
   * Change existing PIN
   */
  async changePin(oldPin: string, newPin: string): Promise<boolean> {
    const check = await this.verifyUserPin(oldPin);
    if (!check.success) {
      throw new Error('Current PIN is incorrect');
    }
    return this.setupPin(newPin);
  },

  /**
   * Lock vault now
   */
  lockVault(): void {
    vaultKeyManager.lockVault();
  },

  /**
   * Check if vault is currently unlocked
   */
  isVaultUnlocked(): boolean {
    return vaultKeyManager.isUnlocked();
  },

  /**
   * Check if device supports Biometric Authentication
   */
  async isBiometricAvailable(): Promise<{ available: boolean; biometryType?: string }> {
    // 1. If running on native Android/iOS
    if (Capacitor.isNativePlatform()) {
      try {
        const info = await BiometricAuth.checkBiometry();
        const available = Boolean(info.isAvailable);
        let biometryType = 'Biometric';
        if (info.biometryType === BiometryType.fingerprintAuthentication) {
          biometryType = 'Fingerprint';
        } else if (info.biometryType === BiometryType.faceAuthentication) {
          biometryType = 'Face Recognition';
        }
        return { available, biometryType };
      } catch (err) {
        console.warn('Capacitor checkBiometry error:', err);
        return { available: false };
      }
    }

    // 2. Web browser fallback using WebAuthn
    if (typeof window !== 'undefined' && window.PublicKeyCredential) {
      try {
        const available = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
        return { available, biometryType: 'Biometric Screen Lock' };
      } catch {
        return { available: false };
      }
    }

    return { available: false };
  },

  /**
   * Trigger real Biometric authentication (Capacitor Android or WebAuthn)
   */
  async authenticateBiometric(): Promise<boolean> {
    const { available } = await this.isBiometricAvailable();
    if (!available) {
      throw new Error('Biometric authentication is unavailable. Use your PIN.');
    }

    // Native Android authentication prompt
    if (Capacitor.isNativePlatform()) {
      try {
        await BiometricAuth.authenticate({
          reason: 'Unlock My Family Document Locker',
          cancelTitle: 'Use PIN'
        });
        const unlocked = await encryptedIndexedDBService.unlockWithBiometricKey();
        if (!unlocked) {
          throw new Error('Biometric authentication is unavailable. Use your PIN.');
        }
        return true;
      } catch (err: any) {
        console.warn('Native biometric authentication cancelled or denied:', err);
        throw new Error('Biometric authentication is unavailable. Use your PIN.');
      }
    }

    // Web fallback
    try {
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      const credential = await navigator.credentials.get({
        publicKey: {
          challenge,
          rpId: window.location.hostname || 'localhost',
          userVerification: 'required',
          timeout: 60000
        }
      });
      if (credential) {
        const unlocked = await encryptedIndexedDBService.unlockWithBiometricKey();
        if (!unlocked) {
          throw new Error('Biometric authentication is unavailable. Use your PIN.');
        }
        return true;
      }
      return false;
    } catch (err: any) {
      console.warn('Web biometric authentication failed:', err);
      throw new Error('Biometric authentication is unavailable. Use your PIN.');
    }
  },

  /**
   * Enable or disable biometric setting
   */
  async setBiometricEnabled(enabled: boolean): Promise<void> {
    const config = await encryptedIndexedDBService.getVaultSecurityConfig();
    if (config) {
      config.biometricEnabled = enabled;
      await encryptedIndexedDBService.saveVaultSecurityConfig(config);
    }
  },

  /**
   * Check if biometric is enabled in user settings
   */
  async isBiometricEnabled(): Promise<boolean> {
    const config = await encryptedIndexedDBService.getVaultSecurityConfig();
    return Boolean(config?.biometricEnabled);
  }
};
