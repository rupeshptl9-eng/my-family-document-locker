/**
 * Notification Service
 * Analyzes document expiry dates and generates alerts for:
 * - Expiring in 30 days
 * - Expiring in 15 days
 * - Expiring in 7 days
 * - Expired
 */

import { LockerDocument, NotificationItem } from '../types';
import { getExpiryStatus } from '../utils/documentUtils';

let inMemoryNotifications: NotificationItem[] = [];

export const notificationService = {
  /**
   * Refresh and generate expiry notifications based on stored documents
   */
  generateExpiryNotifications(documents: LockerDocument[]): NotificationItem[] {
    const newNotifs: NotificationItem[] = [];

    documents.forEach((doc) => {
      if (!doc.expiryDate) return;
      const { status, daysRemaining } = getExpiryStatus(doc.expiryDate);

      if (daysRemaining === null) return;

      // Identify thresholds
      let thresholdTag: string | null = null;
      let title = '';
      let message = '';

      if (daysRemaining < 0) {
        thresholdTag = `expired_${doc.id}`;
        title = `🔴 Document Expired: ${doc.name}`;
        message = `${doc.name} (${doc.familyMemberName}) expired ${Math.abs(daysRemaining)} days ago. Immediate renewal required.`;
      } else if (daysRemaining <= 7) {
        thresholdTag = `exp7_${doc.id}`;
        title = `⚠️ Critical Expiry in ${daysRemaining} Days: ${doc.name}`;
        message = `${doc.name} for ${doc.familyMemberName} expires in ${daysRemaining} days (${doc.expiryDate}).`;
      } else if (daysRemaining <= 15) {
        thresholdTag = `exp15_${doc.id}`;
        title = `🟡 Expiry Alert (15 Days): ${doc.name}`;
        message = `${doc.name} for ${doc.familyMemberName} expires in ${daysRemaining} days.`;
      } else if (daysRemaining <= 30) {
        thresholdTag = `exp30_${doc.id}`;
        title = `🟡 Expiring Soon: ${doc.name}`;
        message = `${doc.name} (${doc.category}) expires on ${doc.expiryDate} (${daysRemaining} days remaining).`;
      }

      if (thresholdTag) {
        // Prevent duplicate notifications
        const exists = newNotifs.some((n) => n.id === thresholdTag);
        if (!exists) {
          newNotifs.unshift({
            id: thresholdTag,
            title,
            message,
            date: new Date().toISOString(),
            type: 'expiry',
            read: false,
            documentId: doc.id,
            daysRemaining
          });
        }
      }
    });

    inMemoryNotifications = newNotifs;
    return newNotifs;
  },

  getNotifications(): NotificationItem[] {
    return inMemoryNotifications;
  },

  clearNotifications(): void {
    inMemoryNotifications = [];
  }
};
