/**
 * Secure Storage Service
 * Backwards-compatible facade routing directly to vaultKeyManager and encryptedIndexedDBService.
 * All static keys and hardcoded salts have been completely removed.
 */

import {
  encryptWithVaultKey,
  decryptWithVaultKey,
  vaultKeyManager
} from './vaultKeyManager';
import { encryptedIndexedDBService } from './encryptedIndexedDBService';

/**
 * Encrypt arbitrary JSON data with AES-256-GCM using active vault key
 */
export async function encryptData(data: unknown): Promise<string> {
  return encryptWithVaultKey(data);
}

/**
 * Decrypt data previously encrypted with AES-256-GCM
 */
export async function decryptData<T>(cipherBase64: string): Promise<T> {
  return decryptWithVaultKey<T>(cipherBase64);
}

/**
 * Save encrypted record to IndexedDB
 */
export async function saveSecureRecord(key: string, data: unknown): Promise<void> {
  await encryptedIndexedDBService.putEncryptedItem(key, 'document', data);
}

/**
 * Get encrypted record from IndexedDB
 */
export async function getSecureRecord<T>(key: string): Promise<T | null> {
  return encryptedIndexedDBService.getDecryptedItem<T>(key);
}

/**
 * Remove record from IndexedDB
 */
export async function deleteSecureRecord(key: string): Promise<void> {
  await encryptedIndexedDBService.deleteItem(key);
}
