/**
 * Local AI Context & Offline Query Engine (Local RAG)
 * - Safe in-memory metadata index of unlocked vault records
 * - Zero plaintext disk storage
 * - Offline-first natural language answer generator for common queries
 * - Minimizes / sanitizes context before any AI evaluation
 * - Full offline query coverage:
 *   "Show Kavya documents", "Which documents expire this month?",
 *   "Show Aadhaar documents", "Which documents belong to Bhavik?",
 *   "Which insurance documents are expiring?", "Show passport documents"
 */

import { LockerDocument, FamilyMember, TextNote } from '../types';

export interface LocalQueryResult {
  handledOffline: boolean;
  reply: string;
  matchedDocuments: LockerDocument[];
  matchedMembers: FamilyMember[];
  matchedNotes: TextNote[];
  engine: 'rules' | 'local';
}

export const localAiContext = {
  /**
   * Process natural language query offline using in-memory metadata
   */
  answerQueryOffline(
    query: string,
    documents: LockerDocument[],
    familyMembers: FamilyMember[],
    textNotes: TextNote[]
  ): LocalQueryResult | null {
    const q = query.toLowerCase().trim();
    if (!q) return null;

    const matchedDocs: LockerDocument[] = [];
    const matchedMembers: FamilyMember[] = [];
    const matchedNotes: TextNote[] = [];

    // Helper: Extract name tokens from queries like "Show Kavya documents" or "Which documents belong to Bhavik?"
    const extractQueriedName = (input: string): string | null => {
      // Pattern: "belong to <name>" or "documents for <name>" or "show <name> documents" or "<name> documents"
      const belongMatch = input.match(/belong(?:s)?\s+to\s+([a-z]+)/i);
      if (belongMatch) return belongMatch[1].toLowerCase();

      const forMatch = input.match(/(?:documents|docs)\s+(?:of|for)\s+([a-z]+)/i);
      if (forMatch) return forMatch[1].toLowerCase();

      const showMatch = input.match(/(?:show|find|list|get)\s+([a-z]+)\s+(?:documents|docs)/i);
      if (showMatch && !['all', 'my', 'the', 'these', 'any', 'aadhaar', 'pan', 'passport', 'insurance', 'expiring'].includes(showMatch[1].toLowerCase())) {
        return showMatch[1].toLowerCase();
      }

      return null;
    };

    // 1. Specific Intersection: "Which insurance documents are expiring?"
    if (q.includes('insurance') && (q.includes('expir') || q.includes('validity') || q.includes('due'))) {
      const now = new Date();
      const insDocs = documents.filter((d) => d.category === 'Insurance' || d.name.toLowerCase().includes('insurance'));
      const expiringIns = insDocs.filter((d) => {
        if (!d.expiryDate) return false;
        const exp = new Date(d.expiryDate);
        if (isNaN(exp.getTime())) return false;
        // Expired or expiring within 180 days
        const diffDays = Math.ceil((exp.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        return diffDays <= 180;
      });

      if (expiringIns.length === 0) {
        return {
          handledOffline: true,
          reply: `None of your Insurance policies or health cards are currently expiring soon (checked ${insDocs.length} policy records).`,
          matchedDocuments: insDocs,
          matchedMembers: [],
          matchedNotes: [],
          engine: 'rules'
        };
      }

      return {
        handledOffline: true,
        reply: `Found ${expiringIns.length} expiring **Insurance** document(s):\n` +
          expiringIns.map((d) => `• **${d.name}** (${d.familyMemberName || 'Self'})\n  Expiry Date: ${d.expiryDate}${d.maskedNumber ? ` • ${d.maskedNumber}` : ''}`).join('\n\n'),
        matchedDocuments: expiringIns,
        matchedMembers: [],
        matchedNotes: [],
        engine: 'rules'
      };
    }

    // 2. Expiry Queries: "Which documents expire this month?", "expiring documents", "expired"
    if (q.includes('expire') || q.includes('expiring') || q.includes('validity') || q.includes('expired')) {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth(); // 0-indexed

      const expiringThisMonth: LockerDocument[] = [];
      const expiredDocs: LockerDocument[] = [];
      const soonExpiring: LockerDocument[] = [];

      for (const doc of documents) {
        if (!doc.expiryDate) continue;
        const exp = new Date(doc.expiryDate);
        if (isNaN(exp.getTime())) continue;

        if (exp < now) {
          expiredDocs.push(doc);
        } else if (exp.getFullYear() === currentYear && exp.getMonth() === currentMonth) {
          expiringThisMonth.push(doc);
        } else {
          // within 90 days
          const diffDays = Math.ceil((exp.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
          if (diffDays <= 90) {
            soonExpiring.push(doc);
          }
        }
      }

      let reply = '';
      if (q.includes('this month')) {
        if (expiringThisMonth.length === 0) {
          reply = 'Good news! None of your family documents are expiring this month.';
        } else {
          reply = `Found ${expiringThisMonth.length} document(s) expiring this month:\n` +
            expiringThisMonth.map((d) => `• ${d.name} (${d.familyMemberName || 'Self'}) - Expires on ${d.expiryDate}`).join('\n');
          matchedDocs.push(...expiringThisMonth);
        }
      } else {
        const total = expiredDocs.length + expiringThisMonth.length + soonExpiring.length;
        if (total === 0) {
          reply = 'All your stored documents have valid expiry dates or do not require expiration renewal.';
        } else {
          const parts: string[] = [];
          if (expiredDocs.length > 0) {
            parts.push(`⚠️ **Expired (${expiredDocs.length})**:\n` + expiredDocs.map((d) => `• ${d.name} (Expired: ${d.expiryDate})`).join('\n'));
            matchedDocs.push(...expiredDocs);
          }
          if (expiringThisMonth.length > 0) {
            parts.push(`📅 **Expiring this month (${expiringThisMonth.length})**:\n` + expiringThisMonth.map((d) => `• ${d.name} (Expires: ${d.expiryDate})`).join('\n'));
            matchedDocs.push(...expiringThisMonth);
          }
          if (soonExpiring.length > 0) {
            parts.push(`⏳ **Expiring within 90 days (${soonExpiring.length})**:\n` + soonExpiring.map((d) => `• ${d.name} (Expires: ${d.expiryDate})`).join('\n'));
            matchedDocs.push(...soonExpiring);
          }
          reply = parts.join('\n\n');
        }
      }

      return {
        handledOffline: true,
        reply,
        matchedDocuments: matchedDocs,
        matchedMembers: [],
        matchedNotes: [],
        engine: 'rules'
      };
    }

    // 3. Member & Person Queries: "Show Kavya documents", "Which documents belong to Bhavik?", "Rahul documents"
    const targetName = extractQueriedName(q);

    // First check existing familyMembers list
    for (const member of familyMembers) {
      const memberName = member.name.toLowerCase();
      if (q.includes(memberName) || (targetName && memberName.includes(targetName))) {
        const memberDocs = documents.filter(
          (d) => d.familyMemberId === member.id ||
                 d.familyMemberName?.toLowerCase().includes(memberName) ||
                 d.holderName?.toLowerCase().includes(memberName) ||
                 d.name.toLowerCase().includes(memberName)
        );

        const reply = memberDocs.length > 0
          ? `Found ${memberDocs.length} document(s) for **${member.name}** (${member.relationship}):\n` +
            memberDocs.map((d) => `• ${d.name} [${d.category}]${d.maskedNumber ? ` • ${d.maskedNumber}` : ''}`).join('\n')
          : `No documents are currently linked to ${member.name}. You can add one by tapping Scan Document.`;

        return {
          handledOffline: true,
          reply,
          matchedDocuments: memberDocs,
          matchedMembers: [member],
          matchedNotes: [],
          engine: 'rules'
        };
      }
    }

    // If not found in familyMembers list, search holderName or document name in documents
    if (targetName) {
      const matchedByName = documents.filter(
        (d) => (d.holderName && d.holderName.toLowerCase().includes(targetName)) ||
               (d.familyMemberName && d.familyMemberName.toLowerCase().includes(targetName)) ||
               d.name.toLowerCase().includes(targetName)
      );

      if (matchedByName.length > 0) {
        const capitalized = targetName.charAt(0).toUpperCase() + targetName.slice(1);
        return {
          handledOffline: true,
          reply: `Found ${matchedByName.length} document(s) belonging to **${capitalized}**:\n` +
            matchedByName.map((d) => `• ${d.name} [${d.category}]${d.maskedNumber ? ` • ${d.maskedNumber}` : ''}`).join('\n'),
          matchedDocuments: matchedByName,
          matchedMembers: [],
          matchedNotes: [],
          engine: 'rules'
        };
      }
    }

    // 4. Category Queries: "Show Aadhaar documents", "Show passport documents", "Show PAN cards", "Driving licence"
    const categories = [
      'Aadhaar',
      'PAN',
      'Passport',
      'Driving Licence',
      'Voter ID',
      'Ration Card',
      'Birth Certificate',
      'Marriage Certificate',
      'Education',
      'Insurance',
      'Bank',
      'Property',
      'Vehicle'
    ];

    for (const cat of categories) {
      const catLower = cat.toLowerCase();
      const isMatch = q.includes(catLower) ||
        (cat === 'Driving Licence' && (q.includes('license') || q.includes('licence') || q.includes('dl'))) ||
        (cat === 'Aadhaar' && (q.includes('aadhar') || q.includes('adhar') || q.includes('uidai'))) ||
        (cat === 'Voter ID' && (q.includes('voter') || q.includes('epic'))) ||
        (cat === 'Vehicle' && (q.includes('rc') || q.includes('car') || q.includes('bike')));

      if (isMatch) {
        const catDocs = documents.filter((d) => d.category === cat || d.name.toLowerCase().includes(catLower));

        const reply = catDocs.length > 0
          ? `Found ${catDocs.length} **${cat}** document(s) in your vault:\n` +
            catDocs.map((d) => `• ${d.name} (${d.familyMemberName || 'Self'})${d.maskedNumber ? ` • ${d.maskedNumber}` : ''}`).join('\n')
          : `No ${cat} documents found in your locker.`;

        return {
          handledOffline: true,
          reply,
          matchedDocuments: catDocs,
          matchedMembers: [],
          matchedNotes: [],
          engine: 'rules'
        };
      }
    }

    // 5. Note Queries: "Show notes", "passwords", "text notes", "secret note"
    if (q.includes('note') || q.includes('secret') || q.includes('password') || q.includes('credentials')) {
      if (textNotes.length === 0) {
        return {
          handledOffline: true,
          reply: 'You have no secure notes saved in Text Locker.',
          matchedDocuments: [],
          matchedMembers: [],
          matchedNotes: [],
          engine: 'rules'
        };
      }
      return {
        handledOffline: true,
        reply: `You have ${textNotes.length} secure notes in your Text Locker:\n` +
          textNotes.map((n) => `• ${n.title} (${n.category})`).join('\n'),
        matchedDocuments: [],
        matchedMembers: [],
        matchedNotes: textNotes,
        engine: 'rules'
      };
    }

    // 6. Total vault stats: "How many documents?", "vault summary", "summary", "status"
    if (q.includes('how many') || q.includes('summary') || q.includes('total') || q.includes('overview') || q.includes('status')) {
      const reply = `**Vault Summary**:\n• Total Documents: ${documents.length}\n• Family Members: ${familyMembers.length}\n• Secure Notes: ${textNotes.length}\n\nAll records are encrypted on-device with AES-256-GCM.`;
      return {
        handledOffline: true,
        reply,
        matchedDocuments: documents.slice(0, 5),
        matchedMembers: familyMembers,
        matchedNotes: textNotes.slice(0, 5),
        engine: 'rules'
      };
    }

    // Open-ended query: return null so AI Router can handle it with local AI or cloud fallback
    return null;
  }
};
