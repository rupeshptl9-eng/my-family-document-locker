/**
 * Secure Data Migration Service (Phase 22)
 * Detects legacy plaintext data in localStorage from v1.
 * Encrypts records with AES-256-GCM and moves them to secure IndexedDB.
 * Only removes plaintext localStorage keys after full verification.
 */

import { encryptedIndexedDBService } from './encryptedIndexedDBService';
import { vaultKeyManager } from './vaultKeyManager';
import { LockerDocument, FamilyMember, TextNote } from '../types';

const LEGACY_KEYS = {
  DOCUMENTS: 'family_locker_documents_v1',
  FAMILY: 'family_locker_family_v1',
  NOTES: 'family_locker_notes_v1',
  NOTIFICATIONS: 'family_locker_notifications_v1',
  MIGRATED_FLAG: 'mfd_migrated_v2'
};

export interface MigrationResult {
  needed: boolean;
  success: boolean;
  documentCount: number;
  familyCount: number;
  noteCount: number;
  error?: string;
}

export const migrationService = {
  /**
   * Check if legacy plaintext data exists in localStorage
   */
  hasLegacyPlaintextData(): boolean {
    if (localStorage.getItem(LEGACY_KEYS.MIGRATED_FLAG) === 'true') {
      return false;
    }

    const hasDocs = Boolean(localStorage.getItem(LEGACY_KEYS.DOCUMENTS));
    const hasFamily = Boolean(localStorage.getItem(LEGACY_KEYS.FAMILY));
    const hasNotes = Boolean(localStorage.getItem(LEGACY_KEYS.NOTES));

    return hasDocs || hasFamily || hasNotes;
  },

  /**
   * Migrate plaintext data to encrypted IndexedDB
   * Requires active vault key
   */
  async migrateToEncryptedVault(): Promise<MigrationResult> {
    if (!this.hasLegacyPlaintextData()) {
      return {
        needed: false,
        success: true,
        documentCount: 0,
        familyCount: 0,
        noteCount: 0
      };
    }

    if (!vaultKeyManager.isUnlocked()) {
      return {
        needed: true,
        success: false,
        documentCount: 0,
        familyCount: 0,
        noteCount: 0,
        error: 'Vault must be unlocked before migration can encrypt data.'
      };
    }

    let docCount = 0;
    let familyCount = 0;
    let noteCount = 0;

    try {
      // 1. Read legacy data safely
      const rawDocs = localStorage.getItem(LEGACY_KEYS.DOCUMENTS);
      const rawFamily = localStorage.getItem(LEGACY_KEYS.FAMILY);
      const rawNotes = localStorage.getItem(LEGACY_KEYS.NOTES);

      const docs: LockerDocument[] = rawDocs ? JSON.parse(rawDocs) : [];
      const family: FamilyMember[] = rawFamily ? JSON.parse(rawFamily) : [];
      const notes: TextNote[] = rawNotes ? JSON.parse(rawNotes) : [];

      // 2. Encrypt & Save to IndexedDB
      for (const d of docs) {
        await encryptedIndexedDBService.putEncryptedItem(d.id, 'document', d);
        docCount++;
      }

      for (const f of family) {
        await encryptedIndexedDBService.putEncryptedItem(f.id, 'family', f);
        familyCount++;
      }

      for (const n of notes) {
        await encryptedIndexedDBService.putEncryptedItem(n.id, 'note', n);
        noteCount++;
      }

      // 3. Verification: Read back to ensure data integrity
      const verifiedDocs = await encryptedIndexedDBService.getDecryptedItemsByType<LockerDocument>('document');
      if (verifiedDocs.length < docs.length) {
        throw new Error('Verification failed: Encrypted count does not match source count.');
      }

      // 4. Safely remove legacy plaintext keys ONLY after full verification
      localStorage.removeItem(LEGACY_KEYS.DOCUMENTS);
      localStorage.removeItem(LEGACY_KEYS.FAMILY);
      localStorage.removeItem(LEGACY_KEYS.NOTES);
      localStorage.removeItem(LEGACY_KEYS.NOTIFICATIONS);
      localStorage.setItem(LEGACY_KEYS.MIGRATED_FLAG, 'true');

      return {
        needed: true,
        success: true,
        documentCount: docCount,
        familyCount,
        noteCount
      };
    } catch (err: any) {
      console.warn('Data migration failed, preserving original localStorage:', err);
      return {
        needed: true,
        success: false,
        documentCount: docCount,
        familyCount,
        noteCount,
        error: err?.message || 'Migration encountered an error. Plaintext data preserved.'
      };
    }
  }
};
