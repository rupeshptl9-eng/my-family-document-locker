/**
 * Secure Encrypted Backup & Restore Service
 * Produces encrypted .mfdbackup files protected with AES-256-GCM and PBKDF2-SHA256.
 * Sensitive data is never exported in plaintext.
 */

import {
  bufferToBase64,
  base64ToBuffer,
  bufferToHex,
  hexToBuffer,
  generateRandomSalt
} from './vaultKeyManager';
import { LockerDocument, FamilyMember, TextNote } from '../types';

export interface BackupMetadata {
  exportDate: string;
  appVersion: string;
  documentCount: number;
  familyCount: number;
  noteCount: number;
}

export interface BackupPayload {
  mfd_magic: 'MFDBACKUP_V2';
  algorithm: 'AES-256-GCM';
  kdf: 'PBKDF2-SHA256';
  iterations: number;
  salt: string;
  iv: string;
  ciphertext: string;
  metadata: BackupMetadata;
}

export interface DecryptedBackupContent {
  exportDate: string;
  documents: LockerDocument[];
  family: FamilyMember[];
  notes: TextNote[];
}

/**
 * Derive AES-256-GCM key from user backup password
 */
async function deriveKeyFromPassword(password: string, salt: Uint8Array): Promise<CryptoKey> {
  const enc = new TextEncoder();
  const passwordBuffer = enc.encode(`mfd_backup_pass_${password}`);

  const baseKey = await crypto.subtle.importKey(
    'raw',
    passwordBuffer,
    'PBKDF2',
    false,
    ['deriveKey']
  );

  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: salt as BufferSource,
      iterations: 100000,
      hash: 'SHA-256'
    },
    baseKey,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

export const backupService = {
  /**
   * Generate encrypted backup payload as a JSON string (.mfdbackup)
   */
  async generateEncryptedBackupPayload(
    password: string,
    documents: LockerDocument[],
    family: FamilyMember[],
    notes: TextNote[]
  ): Promise<string> {
    if (!password || password.length < 6) {
      throw new Error('Backup password must be at least 6 characters long.');
    }

    const salt = generateRandomSalt();
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await deriveKeyFromPassword(password, salt);

    const payloadContent: DecryptedBackupContent = {
      exportDate: new Date().toISOString(),
      documents,
      family,
      notes
    };

    const enc = new TextEncoder();
    const plaintext = enc.encode(JSON.stringify(payloadContent));

    const encrypted = await crypto.subtle.encrypt(
      {
        name: 'AES-GCM',
        iv
      },
      key,
      plaintext
    );

    const backupFile: BackupPayload = {
      mfd_magic: 'MFDBACKUP_V2',
      algorithm: 'AES-256-GCM',
      kdf: 'PBKDF2-SHA256',
      iterations: 100000,
      salt: bufferToHex(salt),
      iv: bufferToHex(iv),
      ciphertext: bufferToBase64(new Uint8Array(encrypted)),
      metadata: {
        exportDate: new Date().toISOString(),
        appVersion: '2.0',
        documentCount: documents.length,
        familyCount: family.length,
        noteCount: notes.length
      }
    };

    return JSON.stringify(backupFile, null, 2);
  },

  /**
   * Create and trigger download of an AES-256-GCM encrypted backup file (.mfdbackup)
   */
  async createEncryptedBackup(
    password: string,
    documents: LockerDocument[],
    family: FamilyMember[],
    notes: TextNote[]
  ): Promise<void> {
    const jsonString = await this.generateEncryptedBackupPayload(password, documents, family, notes);

    const blob = new Blob([jsonString], {
      type: 'application/octet-stream'
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const dateStr = new Date().toISOString().slice(0, 10);
    a.download = `MyFamilyDocumentLocker-Backup-${dateStr}.mfdbackup`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  },

  /**
   * Decrypt and validate .mfdbackup file content
   */
  async decryptBackup(
    fileContent: string,
    password: string
  ): Promise<DecryptedBackupContent> {
    let parsed: BackupPayload;
    try {
      parsed = JSON.parse(fileContent);
    } catch {
      throw new Error('Invalid backup file format.');
    }

    if (parsed.mfd_magic !== 'MFDBACKUP_V2' || !parsed.salt || !parsed.iv || !parsed.ciphertext) {
      throw new Error('Unsupported or corrupted backup file.');
    }

    try {
      const salt = hexToBuffer(parsed.salt);
      const iv = hexToBuffer(parsed.iv);
      const key = await deriveKeyFromPassword(password, salt);
      const ciphertext = base64ToBuffer(parsed.ciphertext);

      const decryptedBuffer = await crypto.subtle.decrypt(
        {
          name: 'AES-GCM',
          iv: iv as BufferSource
        },
        key,
        ciphertext as BufferSource
      );

      const dec = new TextDecoder();
      const content = JSON.parse(dec.decode(decryptedBuffer)) as DecryptedBackupContent;
      return content;
    } catch {
      // Intentionally sanitized error message per Phase 6 specification
      throw new Error('Invalid backup password.');
    }
  }
};
