/**
 * Document Service
 * Hybrid Encrypted Storage Architecture:
 * - Local IndexedDB: AES-256-GCM encrypted document vault
 * - Cloud Firestore: Client-side encrypted sensitive fields (documentNumber, address, notes) + non-sensitive search metadata
 * - Firebase Storage: Authenticated user-isolated document binaries
 * - Offline Sync Queue & Cloud Sync Status indicators
 */

import {
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  orderBy
} from 'firebase/firestore';
import { db, isFirebaseConfigured, handleFirestoreError, OperationType } from '../config/firebase';
import { LockerDocument, SyncStatus } from '../types';
import { encryptedIndexedDBService } from './encryptedIndexedDBService';
import { encryptWithVaultKey, decryptWithVaultKey, vaultKeyManager } from './vaultKeyManager';
import { storageService } from './storageService';

export const documentService = {
  /**
   * Fetch documents: loads from encrypted IndexedDB, then syncs with Firestore if online & unlocked
   */
  async getDocuments(userId: string): Promise<LockerDocument[]> {
    // 1. If vault is unlocked, read from local encrypted IndexedDB first
    let localDocs: LockerDocument[] = [];
    if (vaultKeyManager.isUnlocked()) {
      try {
        localDocs = await encryptedIndexedDBService.getDecryptedItemsByType<LockerDocument>('document');
      } catch (err) {
        console.warn('Could not read from encrypted IndexedDB:', err);
      }
    }

    // 2. If online and Firebase configured, fetch and sync cloud metadata
    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/documents`;
      try {
        const docsRef = collection(db, path);
        const q = query(docsRef, orderBy('uploadDate', 'desc'));
        const snap = await getDocs(q);

        const cloudDocs: LockerDocument[] = [];
        for (const d of snap.docs) {
          const data = d.data();
          let decryptedSensitive: any = {};

          if (data.encryptedPayload && vaultKeyManager.isUnlocked()) {
            try {
              decryptedSensitive = await decryptWithVaultKey<any>(data.encryptedPayload);
            } catch {
              // Key mismatch or corrupted payload
            }
          }

          const mergedDoc: LockerDocument = {
            id: d.id,
            userId,
            name: data.name,
            category: data.category,
            familyMemberId: data.familyMemberId || 'self',
            familyMemberName: data.familyMemberName || 'Self',
            holderName: decryptedSensitive.holderName || data.holderName || '',
            documentNumber: decryptedSensitive.documentNumber || data.maskedNumber,
            maskedNumber: data.maskedNumber,
            dob: decryptedSensitive.dob || data.dob,
            gender: data.gender,
            address: decryptedSensitive.address || data.address,
            issueDate: data.issueDate,
            expiryDate: data.expiryDate,
            issuingAuthority: data.issuingAuthority,
            fileType: data.fileType || 'jpg',
            fileUrl: data.fileUrl || '',
            storagePath: data.storagePath,
            thumbnailPath: data.thumbnailPath,
            fileName: data.fileName || `${data.name}.jpg`,
            fileSize: data.fileSize || 0,
            uploadDate: data.uploadDate || new Date().toISOString().slice(0, 10),
            notes: decryptedSensitive.notes || data.notes || '',
            tags: data.tags || [],
            isAadhaar: data.isAadhaar,
            isFavorite: data.isFavorite,
            verifiedByUser: data.verifiedByUser,
            syncStatus: 'cloud-synced'
          };

          cloudDocs.push(mergedDoc);

          // Update local encrypted cache
          if (vaultKeyManager.isUnlocked()) {
            await encryptedIndexedDBService.putEncryptedItem(d.id, 'document', mergedDoc).catch(() => {});
          }
        }

        if (cloudDocs.length > 0) {
          return cloudDocs;
        }
      } catch (err: any) {
        if (err?.code === 'permission-denied') {
          handleFirestoreError(err, OperationType.LIST, path);
        }
        console.warn('Firestore getDocs failed, returning local vault:', err);
      }
    }

    return localDocs;
  },

  /**
   * Save or create document
   * Encrypts sensitive fields before sending to Firestore
   * Saves encrypted copy in IndexedDB
   */
  async saveDocument(userId: string, document: LockerDocument): Promise<LockerDocument> {
    let syncStatus: SyncStatus = 'device-only';
    let syncError: string | undefined;

    // 1. Save locally in encrypted IndexedDB
    if (vaultKeyManager.isUnlocked()) {
      try {
        await encryptedIndexedDBService.putEncryptedItem(document.id, 'document', {
          ...document,
          syncStatus
        });
      } catch (err) {
        console.warn('Error saving to encrypted IndexedDB:', err);
      }
    }

    // 2. Sync to Firestore if authenticated & online
    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/documents/${document.id}`;
      try {
        let encryptedPayload = '';
        if (vaultKeyManager.isUnlocked()) {
          encryptedPayload = await encryptWithVaultKey({
            documentNumber: document.documentNumber,
            address: document.address || '',
            notes: document.notes || '',
            dob: document.dob || '',
            holderName: document.holderName || ''
          });
        }

        // Firestore document: sensitive identifiers encrypted, non-sensitive index fields plain
        const firestorePayload = {
          id: document.id,
          userId,
          name: document.name,
          category: document.category,
          familyMemberId: document.familyMemberId,
          familyMemberName: document.familyMemberName,
          maskedNumber: document.maskedNumber,
          fileType: document.fileType,
          fileUrl: document.fileUrl,
          storagePath: document.storagePath || '',
          thumbnailPath: document.thumbnailPath || '',
          fileName: document.fileName,
          fileSize: document.fileSize,
          uploadDate: document.uploadDate,
          issueDate: document.issueDate || '',
          expiryDate: document.expiryDate || '',
          issuingAuthority: document.issuingAuthority || '',
          notes: document.notes || '',
          tags: document.tags || [],
          isAadhaar: Boolean(document.isAadhaar),
          isFavorite: Boolean(document.isFavorite),
          verifiedByUser: Boolean(document.verifiedByUser),
          encryptedPayload
        };

        const docRef = doc(db, `users/${userId}/documents`, document.id);
        await setDoc(docRef, firestorePayload, { merge: true });

        syncStatus = 'cloud-synced';
        syncError = undefined;
      } catch (err: any) {
        syncStatus = 'sync-failed';
        syncError = 'Cloud sync failed. Your document is currently available on this device only.';
        console.warn('Firestore setDoc failed:', err);

        // Queue for background retry
        await encryptedIndexedDBService.enqueueSyncItem({
          id: `sync_doc_${document.id}`,
          action: 'update',
          entityType: 'document',
          payload: document
        }).catch(() => {});
      }
    } else {
      // Offline: Enqueue for sync
      syncStatus = 'device-only';
      if (userId && userId !== 'unauthenticated') {
        await encryptedIndexedDBService.enqueueSyncItem({
          id: `sync_doc_${document.id}`,
          action: 'update',
          entityType: 'document',
          payload: document
        }).catch(() => {});
      }
    }

    const updatedDocument: LockerDocument = {
      ...document,
      syncStatus,
      syncError
    };

    // Update local cache with syncStatus
    if (vaultKeyManager.isUnlocked()) {
      await encryptedIndexedDBService.putEncryptedItem(document.id, 'document', updatedDocument).catch(() => {});
    }

    return updatedDocument;
  },

  /**
   * Delete document permanently from Firestore, Storage, and IndexedDB
   */
  async deleteDocument(userId: string, document: LockerDocument): Promise<void> {
    // 1. Delete from Firestore
    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/documents/${document.id}`;
      try {
        const docRef = doc(db, `users/${userId}/documents`, document.id);
        await deleteDoc(docRef);
      } catch (err: any) {
        console.warn('Firestore deleteDoc error:', err);
      }
    }

    // 2. Delete from Firebase Storage (original + thumbnail)
    await storageService.deleteDocumentFile(
      document.storagePath,
      document.id,
      document.thumbnailPath
    );

    // 3. Delete from local encrypted IndexedDB
    try {
      await encryptedIndexedDBService.deleteItem(document.id);
      await encryptedIndexedDBService.removeSyncQueueItem(`sync_doc_${document.id}`);
    } catch {
      // Ignored
    }
  },

  /**
   * Retry sync for all pending offline items
   */
  async processOfflineSyncQueue(userId: string): Promise<number> {
    if (!isFirebaseConfigured || !db || !userId || !navigator.onLine) {
      return 0;
    }

    const queue = await encryptedIndexedDBService.getSyncQueue();
    let syncedCount = 0;

    for (const item of queue) {
      try {
        if (item.entityType === 'document' && item.payload) {
          await this.saveDocument(userId, item.payload);
          await encryptedIndexedDBService.removeSyncQueueItem(item.id);
          syncedCount++;
        }
      } catch (err) {
        console.warn(`Sync retry failed for ${item.id}:`, err);
      }
    }

    return syncedCount;
  }
};
