/**
 * Google Drive Backup & Restore Service
 * Scope: https://www.googleapis.com/auth/drive.file
 *
 * Folders:
 * "My Family Document Locker" -> "Backups"
 *
 * File naming:
 * MFDL-Backup-YYYY-MM-DD-HH-mm.mfdbackup
 *
 * Security:
 * - Minimum required scope: drive.file
 * - AES-256-GCM encrypted payloads ONLY
 * - In-memory access token cache ONLY (never stored in localStorage)
 * - Data integrity verification via SHA-256
 */

import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth, isFirebaseConfigured } from '../config/firebase';
import { backupService, DecryptedBackupContent } from './backupService';
import { LockerDocument, FamilyMember, TextNote } from '../types';

export interface DriveBackupFile {
  id: string;
  name: string;
  size: number;
  createdTime: string;
  modifiedTime: string;
  checksum?: string;
  appVersion?: string;
}

export interface DriveConnectionStatus {
  isConnected: boolean;
  email?: string;
  lastBackupDate?: string;
  autoBackupSchedule?: 'off' | 'daily' | 'weekly';
}

const DRIVE_API_URL = 'https://www.googleapis.com/drive/v3/files';
const DRIVE_UPLOAD_URL = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
const DRIVE_SCOPE = 'https://www.googleapis.com/auth/drive.file';

const APP_FOLDER_NAME = 'My Family Document Locker';
const BACKUPS_FOLDER_NAME = 'Backups';

// In-memory access token cache ONLY per security guidelines
let cachedAccessToken: string | null = null;
let cachedAppFolderId: string | null = null;
let cachedBackupsFolderId: string | null = null;

// Preference keys for non-sensitive connection settings
const STORAGE_KEYS = {
  LAST_BACKUP: 'mfd_drive_last_backup_date',
  AUTO_BACKUP_SCHEDULE: 'mfd_drive_auto_backup_schedule',
  CONNECTED_FLAG: 'mfd_drive_connected_flag'
};

/**
 * Compute SHA-256 hex string for integrity validation
 */
async function computeSha256(content: string): Promise<string> {
  const enc = new TextEncoder();
  const buffer = await crypto.subtle.digest('SHA-256', enc.encode(content));
  const hashArray = Array.from(new Uint8Array(buffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * Format timestamp to MFDL-Backup-YYYY-MM-DD-HH-mm.mfdbackup
 */
function generateBackupFileName(): string {
  const now = new Date();
  const pad = (n: number) => n.toString().padStart(2, '0');
  const year = now.getFullYear();
  const month = pad(now.getMonth() + 1);
  const day = pad(now.getDate());
  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());

  return `MFDL-Backup-${year}-${month}-${day}-${hours}-${minutes}.mfdbackup`;
}

export const googleDriveService = {
  /**
   * Set in-memory token from external sign-in
   */
  setAccessToken(token: string | null): void {
    cachedAccessToken = token;
    if (token) {
      localStorage.setItem(STORAGE_KEYS.CONNECTED_FLAG, 'true');
    }
  },

  /**
   * Get in-memory token
   */
  getAccessToken(): string | null {
    return cachedAccessToken;
  },

  /**
   * Check connection status
   */
  getConnectionStatus(): DriveConnectionStatus {
    const isConnected = Boolean(cachedAccessToken) || localStorage.getItem(STORAGE_KEYS.CONNECTED_FLAG) === 'true';
    const lastBackupDate = localStorage.getItem(STORAGE_KEYS.LAST_BACKUP) || undefined;
    const autoBackupSchedule = (localStorage.getItem(STORAGE_KEYS.AUTO_BACKUP_SCHEDULE) as 'off' | 'daily' | 'weekly') || 'off';
    const email = auth?.currentUser?.email || undefined;

    return {
      isConnected,
      email,
      lastBackupDate,
      autoBackupSchedule
    };
  },

  /**
   * Set auto-backup schedule preference
   */
  setAutoBackupSchedule(schedule: 'off' | 'daily' | 'weekly'): void {
    localStorage.setItem(STORAGE_KEYS.AUTO_BACKUP_SCHEDULE, schedule);
  },

  /**
   * Connect to Google Drive using OAuth with drive.file scope
   */
  async connect(): Promise<{ success: boolean; email?: string }> {
    if (!navigator.onLine) {
      throw new Error('You are offline. Please reconnect to the internet to connect Google Drive.');
    }

    if (!isFirebaseConfigured || !auth) {
      throw new Error('Google Authentication is not configured in this environment.');
    }

    const provider = new GoogleAuthProvider();
    provider.addScope(DRIVE_SCOPE);

    try {
      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (!credential?.accessToken) {
        throw new Error('Could not acquire Google Drive access token.');
      }

      cachedAccessToken = credential.accessToken;
      localStorage.setItem(STORAGE_KEYS.CONNECTED_FLAG, 'true');

      // Pre-warm / ensure folder structure exists
      await this.ensureBackupsFolder();

      return {
        success: true,
        email: result.user.email || undefined
      };
    } catch (err: any) {
      console.error('Google Drive connection error:', err);
      if (err?.code === 'auth/popup-closed-by-user') {
        throw new Error('Google Drive connection was cancelled.');
      }
      throw new Error(err.message || 'Failed to connect to Google Drive.');
    }
  },

  /**
   * Disconnect Google Drive without deleting cloud backups
   */
  disconnect(): void {
    cachedAccessToken = null;
    cachedAppFolderId = null;
    cachedBackupsFolderId = null;
    localStorage.removeItem(STORAGE_KEYS.CONNECTED_FLAG);
  },

  /**
   * Ensure or acquire a valid access token
   */
  async ensureAccessToken(): Promise<string> {
    if (cachedAccessToken) {
      return cachedAccessToken;
    }

    // Try prompt to re-connect if user is already signed in
    if (auth?.currentUser) {
      const provider = new GoogleAuthProvider();
      provider.addScope(DRIVE_SCOPE);
      const result = await signInWithPopup(auth, provider);
      const cred = GoogleAuthProvider.credentialFromResult(result);
      if (cred?.accessToken) {
        cachedAccessToken = cred.accessToken;
        localStorage.setItem(STORAGE_KEYS.CONNECTED_FLAG, 'true');
        return cachedAccessToken;
      }
    }

    throw new Error('Google Drive is not connected. Please connect Google Drive first.');
  },

  /**
   * Ensure 'My Family Document Locker/Backups/' directory structure exists
   * Avoids duplicate folders.
   */
  async ensureBackupsFolder(): Promise<string> {
    if (cachedBackupsFolderId) {
      return cachedBackupsFolderId;
    }

    const token = await this.ensureAccessToken();

    // 1. Find or create root folder: "My Family Document Locker"
    let appFolderId = cachedAppFolderId;
    if (!appFolderId) {
      const q = `name = '${APP_FOLDER_NAME}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
      const searchRes = await fetch(`${DRIVE_API_URL}?q=${encodeURIComponent(q)}&fields=files(id, name)`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      if (!searchRes.ok) {
        throw new Error(`Google Drive API error (${searchRes.status}): Failed to query folder.`);
      }

      const searchData = await searchRes.json();
      if (searchData.files && searchData.files.length > 0) {
        appFolderId = searchData.files[0].id;
      } else {
        // Create root folder
        const createRes = await fetch(DRIVE_API_URL, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            name: APP_FOLDER_NAME,
            mimeType: 'application/vnd.google-apps.folder'
          })
        });

        if (!createRes.ok) {
          throw new Error('Failed to create application folder on Google Drive.');
        }

        const createData = await createRes.json();
        appFolderId = createData.id;
      }
      cachedAppFolderId = appFolderId;
    }

    // 2. Find or create child folder: "Backups"
    const subQuery = `name = '${BACKUPS_FOLDER_NAME}' and '${appFolderId}' in parents and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
    const subRes = await fetch(`${DRIVE_API_URL}?q=${encodeURIComponent(subQuery)}&fields=files(id, name)`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!subRes.ok) {
      throw new Error(`Google Drive API error (${subRes.status}): Failed to query Backups subfolder.`);
    }

    const subData = await subRes.json();
    if (subData.files && subData.files.length > 0) {
      const existingId: string = subData.files[0].id;
      cachedBackupsFolderId = existingId;
      return existingId;
    }

    // Create Backups folder
    const createSubRes = await fetch(DRIVE_API_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: BACKUPS_FOLDER_NAME,
        mimeType: 'application/vnd.google-apps.folder',
        parents: [appFolderId]
      })
    });

    if (!createSubRes.ok) {
      throw new Error('Failed to create Backups folder on Google Drive.');
    }

    const createSubData = await createSubRes.json();
    const createdId: string = createSubData.id;
    cachedBackupsFolderId = createdId;
    return createdId;
  },

  /**
   * Upload encrypted .mfdbackup file to Google Drive
   */
  async uploadBackup(
    password: string,
    documents: LockerDocument[],
    family: FamilyMember[],
    notes: TextNote[],
    onProgress?: (stage: string) => void
  ): Promise<{ fileName: string; fileId: string; size: number }> {
    if (!navigator.onLine) {
      throw new Error('You are offline. Backup will be available when you reconnect.');
    }

    onProgress?.('Preparing backup...');
    const folderId = await this.ensureBackupsFolder();
    const token = await this.ensureAccessToken();

    onProgress?.('Encrypting with AES-256-GCM...');
    const backupJsonString = await backupService.generateEncryptedBackupPayload(
      password,
      documents,
      family,
      notes
    );

    const fileName = generateBackupFileName();
    const checksum = await computeSha256(backupJsonString);

    onProgress?.('Uploading to Google Drive...');
    const metadata = {
      name: fileName,
      parents: [folderId],
      mimeType: 'application/octet-stream',
      description: `MFDL Encrypted Vault Backup. Checksum: ${checksum}`
    };

    const boundary = '-------314159265358979323846';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/octet-stream\r\n\r\n' +
      backupJsonString +
      closeDelimiter;

    const uploadRes = await fetch(DRIVE_UPLOAD_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`
      },
      body: multipartRequestBody
    });

    if (!uploadRes.ok) {
      console.error('Drive upload failed with HTTP status:', uploadRes.status);
      throw new Error('Google Drive backup failed. Your local documents are safe. Please try again.');
    }

    onProgress?.('Verifying upload...');
    const uploadedData = await uploadRes.json();

    const nowFormatted = new Date().toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });

    localStorage.setItem(STORAGE_KEYS.LAST_BACKUP, nowFormatted);

    return {
      fileName,
      fileId: uploadedData.id,
      size: new Blob([backupJsonString]).size
    };
  },

  /**
   * List existing backup files in Google Drive
   */
  async listBackups(): Promise<DriveBackupFile[]> {
    if (!navigator.onLine) {
      throw new Error('You are offline. Cannot fetch backups without an internet connection.');
    }

    const folderId = await this.ensureBackupsFolder();
    const token = await this.ensureAccessToken();

    const q = `'${folderId}' in parents and trashed = false and name contains '.mfdbackup'`;
    const url = `${DRIVE_API_URL}?q=${encodeURIComponent(q)}&orderBy=createdTime desc&fields=files(id, name, size, createdTime, modifiedTime, description)`;

    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      throw new Error('Failed to retrieve backup list from Google Drive.');
    }

    const data = await res.json();
    const files: DriveBackupFile[] = (data.files || []).map((f: any) => ({
      id: f.id,
      name: f.name,
      size: Number(f.size || 0),
      createdTime: f.createdTime,
      modifiedTime: f.modifiedTime,
      checksum: f.description?.includes('Checksum: ') ? f.description.split('Checksum: ')[1] : undefined
    }));

    return files;
  },

  /**
   * Download and decrypt a backup file from Google Drive for restoration
   */
  async downloadAndDecryptBackup(
    fileId: string,
    password: string,
    onProgress?: (stage: string) => void
  ): Promise<DecryptedBackupContent> {
    if (!navigator.onLine) {
      throw new Error('You are offline. Reconnect to download cloud backup.');
    }

    onProgress?.('Downloading from Google Drive...');
    const token = await this.ensureAccessToken();

    const res = await fetch(`${DRIVE_API_URL}/${fileId}?alt=media`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      throw new Error('Failed to download backup file from Google Drive.');
    }

    const content = await res.text();

    onProgress?.('Verifying integrity...');
    // Verify file format
    let parsed: any;
    try {
      parsed = JSON.parse(content);
    } catch {
      throw new Error('Backup verification failed. The backup file is corrupted.');
    }

    if (parsed.mfd_magic !== 'MFDBACKUP_V2' && parsed.format !== 'MFDL_BACKUP') {
      throw new Error('Unsupported backup version. Please check for app updates.');
    }

    onProgress?.('Decrypting vault payload...');
    const decrypted = await backupService.decryptBackup(content, password);

    onProgress?.('Validating contents...');
    if (!decrypted || !Array.isArray(decrypted.documents)) {
      throw new Error('Backup verification failed. The backup was not restored.');
    }

    return decrypted;
  },

  /**
   * Delete a backup file from Google Drive
   */
  async deleteBackup(fileId: string): Promise<void> {
    if (!navigator.onLine) {
      throw new Error('You are offline. Cannot delete cloud backup while offline.');
    }

    const token = await this.ensureAccessToken();

    const res = await fetch(`${DRIVE_API_URL}/${fileId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok && res.status !== 404) {
      throw new Error('Failed to delete backup file from Google Drive.');
    }
  }
};
