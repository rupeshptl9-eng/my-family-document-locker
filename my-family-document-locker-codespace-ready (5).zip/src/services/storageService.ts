/**
 * Storage Service
 * Handles user-isolated document storage in Firebase Storage:
 * Paths:
 * - users/{uid}/documents/{documentId}/original.{ext}
 * - users/{uid}/documents/{documentId}/thumbnail.jpg
 * When offline or unauthenticated: stores encrypted payload in IndexedDB.
 */

import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage, isFirebaseConfigured } from '../config/firebase';
import { encryptedIndexedDBService } from './encryptedIndexedDBService';
import { compressImage } from '../utils/imageUtils';

export const storageService = {
  /**
   * Upload original and thumbnail document files to Firebase Storage
   */
  async uploadDocumentFile(
    userId: string,
    documentId: string,
    fileDataUrlOrBlob: string | Blob,
    fileName: string,
    mimeType: string
  ): Promise<{ fileUrl: string; storagePath: string; thumbnailPath?: string; syncStatus: 'cloud-synced' | 'device-only' }> {
    const ext = fileName.split('.').pop() || (mimeType.includes('pdf') ? 'pdf' : 'jpg');
    const storagePath = `users/${userId}/documents/${documentId}/original.${ext}`;
    const thumbnailPath = `users/${userId}/documents/${documentId}/thumbnail.jpg`;

    // 1. Try Firebase Storage if configured and online
    if (isFirebaseConfigured && storage && userId && userId !== 'unauthenticated' && navigator.onLine) {
      try {
        let blob: Blob;
        let dataUrl: string;

        if (typeof fileDataUrlOrBlob === 'string') {
          dataUrl = fileDataUrlOrBlob;
          const res = await fetch(fileDataUrlOrBlob);
          blob = await res.blob();
        } else {
          blob = fileDataUrlOrBlob;
          dataUrl = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result as string);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
          });
        }

        // Upload original file
        const originalRef = ref(storage, storagePath);
        await uploadBytes(originalRef, blob, {
          contentType: mimeType,
          customMetadata: {
            uploadedBy: userId,
            documentId
          }
        });
        const fileUrl = await getDownloadURL(originalRef);

        // Upload thumbnail for image files
        if (!mimeType.includes('pdf')) {
          try {
            const thumb = await compressImage(dataUrl, 320, 0.7);
            const thumbRes = await fetch(thumb.dataUrl);
            const thumbBlob = await thumbRes.blob();
            const thumbRef = ref(storage, thumbnailPath);
            await uploadBytes(thumbRef, thumbBlob, {
              contentType: 'image/jpeg',
              customMetadata: { uploadedBy: userId, documentId }
            });
          } catch (thumbErr) {
            console.warn('Could not generate/upload thumbnail:', thumbErr);
          }
        }

        // Also save encrypted local copy in IndexedDB for fast offline access
        try {
          await encryptedIndexedDBService.putEncryptedItem(`blob_${documentId}`, 'document', {
            documentId,
            dataUrl,
            fileName,
            mimeType
          });
        } catch {
          // Ignored
        }

        return { fileUrl, storagePath, thumbnailPath, syncStatus: 'cloud-synced' };
      } catch (fbError) {
        console.warn('Firebase Storage upload failed, storing in encrypted IndexedDB:', fbError);
      }
    }

    // 2. Offline / Local Encrypted Vault fallback
    let dataUrl: string;
    if (typeof fileDataUrlOrBlob === 'string') {
      dataUrl = fileDataUrlOrBlob;
    } else {
      dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(fileDataUrlOrBlob);
      });
    }

    try {
      await encryptedIndexedDBService.putEncryptedItem(`blob_${documentId}`, 'document', {
        documentId,
        dataUrl,
        fileName,
        mimeType
      });
    } catch (err) {
      console.warn('Could not store encrypted blob in IndexedDB:', err);
    }

    // Enqueue for background sync when connection is restored
    if (userId && userId !== 'unauthenticated') {
      encryptedIndexedDBService.enqueueSyncItem({
        id: `sync_file_${documentId}`,
        action: 'create',
        entityType: 'document',
        payload: { documentId, fileName, mimeType }
      }).catch(() => {});
    }

    return {
      fileUrl: dataUrl,
      storagePath,
      thumbnailPath,
      syncStatus: 'device-only'
    };
  },

  /**
   * Delete document files from Firebase Storage and local vault
   */
  async deleteDocumentFile(storagePath?: string, documentId?: string, thumbnailPath?: string): Promise<void> {
    if (storagePath && isFirebaseConfigured && storage && navigator.onLine) {
      try {
        const originalRef = ref(storage, storagePath);
        await deleteObject(originalRef);
      } catch (e) {
        console.warn('Firebase delete original error:', e);
      }
    }

    if (thumbnailPath && isFirebaseConfigured && storage && navigator.onLine) {
      try {
        const thumbRef = ref(storage, thumbnailPath);
        await deleteObject(thumbRef);
      } catch (e) {
        console.warn('Firebase delete thumbnail error:', e);
      }
    }

    if (documentId) {
      try {
        await encryptedIndexedDBService.deleteItem(`blob_${documentId}`);
        await encryptedIndexedDBService.removeSyncQueueItem(`sync_file_${documentId}`);
      } catch {
        // Ignored
      }
    }
  }
};
