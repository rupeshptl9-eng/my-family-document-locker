/**
 * Image Utilities: Conversion, Compression, Cropping & Base64 Processing
 * Real Camera and File stream handling for My Family Document Locker
 */

export interface ProcessedImage {
  base64Data: string; // Clean raw base64 without prefix (for Gemini API)
  dataUrl: string;    // Full data:image/...;base64,... for preview and display
  mimeType: string;
  size: number;
  width: number;
  height: number;
}

export interface CropRect {
  x: number;      // 0 to 1 percentage of width
  y: number;      // 0 to 1 percentage of height
  width: number;  // 0 to 1 percentage of width
  height: number; // 0 to 1 percentage of height
}

/**
 * Validates file type and size
 * Accepts JPG, JPEG, PNG, WEBP, and PDF up to 25MB
 */
export function validateDocumentFile(file: File): { valid: boolean; error?: string } {
  const allowedMimeTypes = [
    'image/jpeg',
    'image/jpg',
    'image/png',
    'image/webp',
    'application/pdf'
  ];

  const lowerType = file.type.toLowerCase();
  const ext = file.name.split('.').pop()?.toLowerCase() || '';

  const isMimeAllowed = allowedMimeTypes.includes(lowerType);
  const isExtAllowed = ['jpg', 'jpeg', 'png', 'webp', 'pdf'].includes(ext);

  if (!isMimeAllowed && !isExtAllowed) {
    return {
      valid: false,
      error: `Unsupported file format (.${ext || file.type}). Please select a JPG, JPEG, PNG, WEBP, or PDF document.`
    };
  }

  // Max 25 MB limit
  const maxBytes = 25 * 1024 * 1024;
  if (file.size > maxBytes) {
    return {
      valid: false,
      error: `File is too large (${(file.size / (1024 * 1024)).toFixed(1)} MB). Maximum allowed size is 25 MB.`
    };
  }

  return { valid: true };
}

/**
 * Reads a File object as ArrayBuffer (for binary security / hashing if needed)
 */
export function fileToArrayBuffer(file: File): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (reader.result instanceof ArrayBuffer) {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read file as ArrayBuffer'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('FileReader error'));
    reader.readAsArrayBuffer(file);
  });
}

/**
 * Reads a file as Data URL using FileReader
 */
export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Failed to read file as string'));
      }
    };
    reader.onerror = () => reject(reader.error || new Error('FileReader error'));
    reader.readAsDataURL(file);
  });
}

/**
 * Extracts clean base64 data and MIME type from a File object
 */
export async function fileToBase64Clean(file: File): Promise<{
  base64Data: string;
  mimeType: string;
  dataUrl: string;
  size: number;
}> {
  const dataUrl = await readFileAsDataUrl(file);
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (match) {
    return {
      mimeType: match[1] || file.type || 'image/jpeg',
      base64Data: match[2],
      dataUrl,
      size: file.size
    };
  }
  const cleanBase64 = dataUrl.replace(/^data:[^;]+;base64,/, '');
  return {
    mimeType: file.type || 'image/jpeg',
    base64Data: cleanBase64,
    dataUrl,
    size: file.size
  };
}

/**
 * Compresses an image client-side using an HTMLCanvasElement.
 * Resizes images exceeding maxDimension and compresses with target quality.
 */
export async function compressImage(
  fileOrDataUrl: File | string,
  maxDimension: number = 1600,
  quality: number = 0.85
): Promise<ProcessedImage> {
  let dataUrl: string;
  let originalMime = 'image/jpeg';

  if (typeof fileOrDataUrl === 'string') {
    dataUrl = fileOrDataUrl;
    const match = dataUrl.match(/^data:([^;]+);base64,/);
    if (match) originalMime = match[1];
  } else {
    originalMime = fileOrDataUrl.type || 'image/jpeg';
    dataUrl = await readFileAsDataUrl(fileOrDataUrl);
  }

  // If PDF, cannot compress via 2D canvas, return directly
  if (originalMime.includes('pdf')) {
    const cleanBase64 = dataUrl.replace(/^data:[^;]+;base64,/, '');
    return {
      base64Data: cleanBase64,
      dataUrl,
      mimeType: 'application/pdf',
      size: Math.round((cleanBase64.length * 3) / 4),
      width: 0,
      height: 0
    };
  }

  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      let { width, height } = img;

      // Scale dimensions if larger than maxDimension
      if (width > maxDimension || height > maxDimension) {
        if (width > height) {
          height = Math.round((height * maxDimension) / width);
          width = maxDimension;
        } else {
          width = Math.round((width * maxDimension) / height);
          height = maxDimension;
        }
      }

      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, width);
      canvas.height = Math.max(1, height);
      const ctx = canvas.getContext('2d');

      if (!ctx) {
        reject(new Error('Could not get 2D canvas context'));
        return;
      }

      // Draw image
      ctx.drawImage(img, 0, 0, width, height);

      // Normalize format to image/jpeg or image/webp
      const targetMime = originalMime === 'image/png' ? 'image/png' : 'image/jpeg';
      const compressedDataUrl = canvas.toDataURL(targetMime, quality);
      const cleanBase64 = compressedDataUrl.replace(/^data:[^;]+;base64,/, '');

      resolve({
        base64Data: cleanBase64,
        dataUrl: compressedDataUrl,
        mimeType: targetMime,
        size: Math.round((cleanBase64.length * 3) / 4),
        width,
        height
      });
    };

    img.onerror = () => reject(new Error('Failed to load image for compression'));
    img.src = dataUrl;
  });
}

/**
 * Rotates an image Data URL by 90-degree steps
 */
export function rotateImageDataUrl(dataUrl: string, degrees: number): Promise<string> {
  if (degrees % 360 === 0) return Promise.resolve(dataUrl);

  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }

      const rad = (degrees * Math.PI) / 180;
      const is90or270 = degrees % 180 !== 0;

      canvas.width = is90or270 ? img.height : img.width;
      canvas.height = is90or270 ? img.width : img.height;

      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(rad);
      ctx.drawImage(img, -img.width / 2, -img.height / 2);

      resolve(canvas.toDataURL('image/jpeg', 0.9));
    };
    img.onerror = () => reject(new Error('Failed to load image for rotation'));
    img.src = dataUrl;
  });
}

/**
 * Crops an image Data URL according to percentage crop rectangle
 */
export function cropImageDataUrl(
  dataUrl: string,
  crop: CropRect,
  quality: number = 0.9
): Promise<ProcessedImage> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const sx = Math.max(0, Math.floor(crop.x * img.width));
      const sy = Math.max(0, Math.floor(crop.y * img.height));
      const sWidth = Math.min(img.width - sx, Math.floor(crop.width * img.width));
      const sHeight = Math.min(img.height - sy, Math.floor(crop.height * img.height));

      if (sWidth <= 0 || sHeight <= 0) {
        reject(new Error('Invalid crop dimensions'));
        return;
      }

      const canvas = document.createElement('canvas');
      canvas.width = sWidth;
      canvas.height = sHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Canvas context not available'));
        return;
      }

      ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);

      const targetMime = 'image/jpeg';
      const croppedDataUrl = canvas.toDataURL(targetMime, quality);
      const cleanBase64 = croppedDataUrl.replace(/^data:[^;]+;base64,/, '');

      resolve({
        base64Data: cleanBase64,
        dataUrl: croppedDataUrl,
        mimeType: targetMime,
        size: Math.round((cleanBase64.length * 3) / 4),
        width: sWidth,
        height: sHeight
      });
    };
    img.onerror = () => reject(new Error('Failed to load image for cropping'));
    img.src = dataUrl;
  });
}
