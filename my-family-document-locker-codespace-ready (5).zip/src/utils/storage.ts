/**
 * Storage Utility
 * PHASE 1 COMPLIANCE:
 * Sensitive document details, notes, Aadhaar/PAN numbers, and family records
 * are NEVER stored in plain localStorage.
 *
 * localStorage is strictly restricted to harmless UI preferences:
 * - Theme
 * - Auto-lock interval
 * - Language / UI settings
 * - Non-sensitive session cache
 */

import {
  FamilyMember,
  LockerDocument,
  NotificationItem,
  TextNote,
  UserProfile,
  AutoLockInterval
} from '../types';
import {
  INITIAL_DOCUMENTS,
  INITIAL_FAMILY,
  INITIAL_NOTIFICATIONS,
  INITIAL_TEXT_NOTES,
  INITIAL_USER
} from '../data/mockData';

const PREFERENCE_KEYS = {
  USER_SESSION: 'family_locker_user_session_v2',
  THEME: 'family_locker_theme_v2',
  AUTOLOCK: 'family_locker_autolock_v2',
  LAST_BACKUP: 'family_locker_last_backup_date'
};

// Legacy keys strictly for one-time migration to encrypted IndexedDB vault
export const LEGACY_KEYS = {
  DOCUMENTS: 'family_locker_documents_v1',
  FAMILY: 'family_locker_family_v1',
  NOTES: 'family_locker_notes_v1',
  NOTIFICATIONS: 'family_locker_notifications_v1',
  USER: 'family_locker_user_v1'
};

export function getStoredTheme(): 'light' | 'dark' {
  try {
    const stored = localStorage.getItem(PREFERENCE_KEYS.THEME);
    if (stored === 'dark' || stored === 'light') return stored;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  } catch {
    return 'light';
  }
}

export function saveStoredTheme(theme: 'light' | 'dark'): void {
  try {
    localStorage.setItem(PREFERENCE_KEYS.THEME, theme);
  } catch (e) {
    console.error('Failed to save theme preference:', e);
  }
}

export function getStoredAutoLockInterval(): AutoLockInterval {
  try {
    const val = localStorage.getItem(PREFERENCE_KEYS.AUTOLOCK) as AutoLockInterval | null;
    if (val && ['immediately', '1m', '5m', '15m', 'never'].includes(val)) {
      return val;
    }
    return '5m';
  } catch {
    return '5m';
  }
}

export function saveStoredAutoLockInterval(interval: AutoLockInterval): void {
  try {
    localStorage.setItem(PREFERENCE_KEYS.AUTOLOCK, interval);
  } catch (e) {
    console.error('Failed to save auto-lock interval:', e);
  }
}

export function getStoredUser(): UserProfile {
  try {
    const raw = localStorage.getItem(PREFERENCE_KEYS.USER_SESSION);
    if (!raw) {
      return INITIAL_USER;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_USER;
  }
}

export function saveStoredUser(user: UserProfile): void {
  try {
    // Sanitize user before saving to localStorage session
    // Never persist raw PIN, pinHash, or sensitive secrets in localStorage
    const safeUser: UserProfile = {
      uid: user.uid,
      displayName: user.displayName,
      email: user.email,
      photoURL: user.photoURL,
      isLoggedIn: user.isLoggedIn,
      pinLockEnabled: user.pinLockEnabled,
      biometricEnabled: user.biometricEnabled,
      theme: user.theme,
      authProvider: user.authProvider,
      autoLockInterval: user.autoLockInterval
    };
    localStorage.setItem(PREFERENCE_KEYS.USER_SESSION, JSON.stringify(safeUser));
  } catch (e) {
    console.error('Failed to save user session:', e);
  }
}

/**
 * Migration helpers: Read legacy plaintext data from localStorage if existing
 */
export function getLegacyPlaintextDocuments(): LockerDocument[] {
  try {
    const raw = localStorage.getItem(LEGACY_KEYS.DOCUMENTS);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function getLegacyPlaintextFamily(): FamilyMember[] {
  try {
    const raw = localStorage.getItem(LEGACY_KEYS.FAMILY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function getLegacyPlaintextNotes(): TextNote[] {
  try {
    const raw = localStorage.getItem(LEGACY_KEYS.NOTES);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

/**
 * Clean up legacy plaintext records after migration into encrypted IndexedDB
 */
export function purgeLegacyPlaintextStorage(): void {
  try {
    localStorage.removeItem(LEGACY_KEYS.DOCUMENTS);
    localStorage.removeItem(LEGACY_KEYS.FAMILY);
    localStorage.removeItem(LEGACY_KEYS.NOTES);
    localStorage.removeItem(LEGACY_KEYS.NOTIFICATIONS);
    localStorage.removeItem(LEGACY_KEYS.USER);
    console.info('Legacy plaintext data securely purged from localStorage.');
  } catch (err) {
    console.warn('Purge legacy storage warning:', err);
  }
}

/**
 * Backwards compatibility stubs (in-memory or redirecting) so any remaining imports don't crash
 */
export function getStoredDocuments(): LockerDocument[] {
  // Return legacy if still unmigrated, else empty array (all real documents live in encrypted IndexedDB)
  return getLegacyPlaintextDocuments();
}

export function saveStoredDocuments(_docs: LockerDocument[]): void {
  // No-op for security: Never write sensitive documents to localStorage!
}

export function getStoredFamily(): FamilyMember[] {
  return getLegacyPlaintextFamily();
}

export function saveStoredFamily(_family: FamilyMember[]): void {
  // No-op for security
}

export function getStoredNotes(): TextNote[] {
  return getLegacyPlaintextNotes();
}

export function saveStoredNotes(_notes: TextNote[]): void {
  // No-op for security
}

export function getStoredNotifications(): NotificationItem[] {
  return INITIAL_NOTIFICATIONS;
}

export function saveStoredNotifications(_notifs: NotificationItem[]): void {
  // Harmless in-memory notifications
}

export function clearHarmlessPreferences(): void {
  try {
    localStorage.removeItem(PREFERENCE_KEYS.USER_SESSION);
    localStorage.removeItem(PREFERENCE_KEYS.THEME);
    localStorage.removeItem(PREFERENCE_KEYS.AUTOLOCK);
    localStorage.removeItem(PREFERENCE_KEYS.LAST_BACKUP);
  } catch (err) {
    console.warn('Could not clear preferences:', err);
  }
}

export function resetLockerData(): void {
  purgeLegacyPlaintextStorage();
  clearHarmlessPreferences();
}

