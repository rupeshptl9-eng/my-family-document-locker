/**
 * Image Preprocessing Utility for Offline OCR
 * - Downscales oversized images to max 1600px (improves OCR speed and memory usage)
 * - Enhances contrast for clearer text recognition
 * - Non-destructive: Operates on in-memory canvas copy, preserves original user file
 * - Cleans up object URLs to prevent memory leaks
 */

export interface PreprocessedImageResult {
  base64Data: string;
  mimeType: string;
  width: number;
  height: number;
  cleanUp: () => void;
}

const MAX_OCR_DIMENSION = 1600;

export async function preprocessImageForOCR(
  fileOrBlob: File | Blob
): Promise<PreprocessedImageResult> {
  // If it's a PDF, we can't rasterize via standard Image element directly; return base64
  if (fileOrBlob.type.includes('pdf')) {
    const buffer = await fileOrBlob.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64Data = btoa(binary);
    return {
      base64Data,
      mimeType: 'application/pdf',
      width: 0,
      height: 0,
      cleanUp: () => {}
    };
  }

  const objectUrl = URL.createObjectURL(fileOrBlob);

  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';

    img.onload = () => {
      try {
        let width = img.naturalWidth || img.width;
        let height = img.naturalHeight || img.height;

        // Downscale while preserving aspect ratio
        if (width > MAX_OCR_DIMENSION || height > MAX_OCR_DIMENSION) {
          if (width > height) {
            height = Math.round((height * MAX_OCR_DIMENSION) / width);
            width = MAX_OCR_DIMENSION;
          } else {
            width = Math.round((width * MAX_OCR_DIMENSION) / height);
            height = MAX_OCR_DIMENSION;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d', { willReadFrequently: true });

        if (!ctx) {
          throw new Error('Canvas 2D context unavailable');
        }

        // Draw image onto canvas
        ctx.drawImage(img, 0, 0, width, height);

        // Moderate contrast enhancement to make document text crisper for OCR
        try {
          const imageData = ctx.getImageData(0, 0, width, height);
          const data = imageData.data;
          const factor = 1.15; // 15% contrast boost
          for (let i = 0; i < data.length; i += 4) {
            data[i] = Math.min(255, Math.max(0, factor * (data[i] - 128) + 128));     // R
            data[i + 1] = Math.min(255, Math.max(0, factor * (data[i + 1] - 128) + 128)); // G
            data[i + 2] = Math.min(255, Math.max(0, factor * (data[i + 2] - 128) + 128)); // B
          }
          ctx.putImageData(imageData, 0, 0);
        } catch {
          // If ImageData manipulation is restricted, proceed with original drawing
        }

        const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
        const base64Data = dataUrl.replace(/^data:image\/[a-z]+;base64,/, '');

        resolve({
          base64Data,
          mimeType: 'image/jpeg',
          width,
          height,
          cleanUp: () => {
            URL.revokeObjectURL(objectUrl);
            canvas.width = 0;
            canvas.height = 0;
          }
        });
      } catch (err) {
        URL.revokeObjectURL(objectUrl);
        reject(err);
      }
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to load image for OCR preprocessing.'));
    };

    img.src = objectUrl;
  });
}
