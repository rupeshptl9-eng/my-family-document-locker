export type DocumentCategory =
  | 'Aadhaar'
  | 'PAN'
  | 'Passport'
  | 'Driving Licence'
  | 'Voter ID'
  | 'Ration Card'
  | 'Birth Certificate'
  | 'Marriage Certificate'
  | 'Education'
  | 'Insurance'
  | 'Bank'
  | 'Property'
  | 'Vehicle'
  | 'Other';

export type FamilyRelationship =
  | 'Self'
  | 'Wife'
  | 'Husband'
  | 'Daughter'
  | 'Son'
  | 'Father'
  | 'Mother'
  | 'Brother'
  | 'Sister'
  | 'Other';

export type Gender = 'Male' | 'Female' | 'Other' | 'Unspecified';

export interface FamilyMember {
  id: string;
  name: string;
  relationship: FamilyRelationship;
  dob?: string;
  gender?: Gender;
  photoUrl?: string;
  notes?: string;
  color: string;
  createdAt?: string;
  userId?: string;
}

export type ExpiryStatus = 'VALID' | 'EXPIRING_SOON' | 'EXPIRED';

export type SyncStatus = 'cloud-synced' | 'synced' | 'device-only' | 'syncing' | 'sync-failed';

export type AutoLockInterval = 'immediately' | '1m' | '5m' | '15m' | 'never';

export interface LockerDocument {
  id: string;
  name: string;
  category: DocumentCategory;
  familyMemberId: string;
  familyMemberName: string;
  holderName?: string;
  documentNumber: string;
  maskedNumber: string;
  dob?: string;
  gender?: Gender;
  address?: string;
  issueDate?: string;
  expiryDate?: string;
  issuingAuthority?: string;
  fileType: 'pdf' | 'jpg' | 'jpeg' | 'png' | 'webp';
  fileUrl: string;
  thumbnailUrl?: string;
  thumbnailPath?: string;
  storagePath?: string;
  fileName: string;
  fileSize: number; // in bytes
  uploadDate: string;
  notes?: string;
  tags?: string[];
  isAadhaar?: boolean;
  isFavorite?: boolean;
  verifiedByUser?: boolean;
  syncStatus?: SyncStatus;
  syncError?: string;
  userId?: string;
  encryptedDocumentNumber?: string;
  encryptedAddress?: string;
  encryptedNotes?: string;
}

export interface AIExtractionResult {
  docType: DocumentCategory;
  docName: string;
  holderName: string;
  dob?: string;
  gender?: Gender;
  address?: string;
  documentNumber: string;
  issueDate?: string;
  expiryDate?: string;
  issuingAuthority?: string;
  suggestedFamilyMember?: string;
  notes?: string;
  keyDetails?: string[];
  isAadhaar?: boolean;
  confidenceScore?: number;
  requiresUserVerification?: boolean;
  complianceNotice?: string;
}

export type TextCategory =
  | 'Important notes'
  | 'Bank information'
  | 'Insurance details'
  | 'Emergency information'
  | 'Personal notes'
  | 'Account information'
  | 'Addresses'
  | 'Reference numbers';

export interface TextNote {
  id: string;
  title: string;
  content: string;
  category: TextCategory;
  familyMemberId: string;
  familyMemberName: string;
  tags: string[];
  isFavorite?: boolean;
  isLocked?: boolean;
  createdAt: string;
  updatedAt: string;
  userId?: string;
}

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  isLoggedIn: boolean;
  pinLockEnabled: boolean;
  pinHash?: string;
  saltHex?: string;
  verifierHex?: string;
  biometricEnabled?: boolean;
  autoLockInterval?: AutoLockInterval;
  theme: 'system' | 'light' | 'dark';
  authProvider?: 'firebase-google' | 'local-vault';
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  date: string;
  type: 'expiry' | 'security' | 'backup' | 'ai';
  read: boolean;
  documentId?: string;
  daysRemaining?: number;
}
