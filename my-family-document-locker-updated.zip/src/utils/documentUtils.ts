import { DocumentCategory, ExpiryStatus } from '../types';

/**
 * Calculates document expiry status and remaining days
 * 🟢 Valid (> 30 days)
 * 🟡 Expiring Soon (0 to 30 days)
 * 🔴 Expired (< 0 days)
 */
export function getExpiryStatus(expiryDate?: string): {
  status: ExpiryStatus;
  daysRemaining: number | null;
  label: string;
  badgeColor: string;
} {
  if (!expiryDate || expiryDate.trim() === '') {
    return {
      status: 'VALID',
      daysRemaining: null,
      label: 'No Expiry',
      badgeColor: 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300'
    };
  }

  const targetDate = new Date(expiryDate);
  if (isNaN(targetDate.getTime())) {
    return {
      status: 'VALID',
      daysRemaining: null,
      label: 'Valid',
      badgeColor: 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300'
    };
  }

  // Use current applet context time or system time
  const now = new Date();
  const diffTime = targetDate.getTime() - now.getTime();
  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (daysRemaining < 0) {
    return {
      status: 'EXPIRED',
      daysRemaining,
      label: `Expired (${Math.abs(daysRemaining)}d ago)`,
      badgeColor: 'text-rose-700 bg-rose-50 dark:bg-rose-950/40 dark:text-rose-300'
    };
  }

  if (daysRemaining <= 30) {
    return {
      status: 'EXPIRING_SOON',
      daysRemaining,
      label: daysRemaining === 0 ? 'Expires Today' : `Expires in ${daysRemaining}d`,
      badgeColor: 'text-amber-700 bg-amber-50 dark:bg-amber-950/40 dark:text-amber-300'
    };
  }

  return {
    status: 'VALID',
    daysRemaining,
    label: 'Valid',
    badgeColor: 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300'
  };
}

/**
 * Masks sensitive document numbers to protect user privacy
 * Aadhaar: •••• •••• 9128
 * PAN: •••••4812F
 * Passport: ••••••458
 */
export function maskDocumentNumber(docNumber: string, category: DocumentCategory): string {
  if (!docNumber) return '••••';
  const clean = docNumber.replace(/\s+/g, '');

  if (category === 'Aadhaar') {
    const last4 = clean.slice(-4);
    return `•••• •••• ${last4 || '••••'}`;
  }

  if (category === 'PAN') {
    if (clean.length >= 10) {
      const last5 = clean.slice(5);
      return `•••••${last5}`;
    }
    return `•••••${clean.slice(-4)}`;
  }

  if (category === 'Passport') {
    if (clean.length > 3) {
      const last3 = clean.slice(-3);
      return `•••••${last3}`;
    }
    return '••••••••';
  }

  // Default mask: preserve last 4 digits
  if (clean.length > 4) {
    const maskedLen = Math.max(clean.length - 4, 3);
    return `${'•'.repeat(maskedLen)}${clean.slice(-4)}`;
  }

  return '••••';
}

/**
 * Formats file size in readable units
 */
export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

/**
 * Formats standard date YYYY-MM-DD
 */
export function formatDate(dateString?: string): string {
  if (!dateString) return 'Not specified';
  try {
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return dateString;
  }
}

/**
 * Category color and visual config
 */
export const CATEGORY_CONFIG: Record<
  DocumentCategory,
  {
    label: string;
    iconBg: string;
    gradient: string;
    glassBorder: string;
    glowColor: string;
    textDark: string;
    textLight: string;
  }
> = {
  Aadhaar: {
    label: 'Aadhaar',
    iconBg: 'bg-orange-500/10 text-orange-600 dark:bg-orange-500/20 dark:text-orange-400',
    gradient: 'from-orange-500/20 via-amber-500/15 to-transparent',
    glassBorder: 'border-orange-500/30 hover:border-orange-500/60',
    glowColor: 'rgba(249, 115, 22, 0.25)',
    textLight: 'text-orange-600',
    textDark: 'dark:text-orange-400'
  },
  PAN: {
    label: 'PAN',
    iconBg: 'bg-blue-500/10 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400',
    gradient: 'from-blue-600/20 via-indigo-500/15 to-transparent',
    glassBorder: 'border-blue-500/30 hover:border-blue-500/60',
    glowColor: 'rgba(59, 130, 246, 0.25)',
    textLight: 'text-blue-600',
    textDark: 'dark:text-blue-400'
  },
  Passport: {
    label: 'Passport',
    iconBg: 'bg-indigo-500/10 text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-400',
    gradient: 'from-indigo-600/20 via-violet-500/15 to-transparent',
    glassBorder: 'border-indigo-500/30 hover:border-indigo-500/60',
    glowColor: 'rgba(99, 102, 241, 0.25)',
    textLight: 'text-indigo-600',
    textDark: 'dark:text-indigo-400'
  },
  'Driving Licence': {
    label: 'Driving Licence',
    iconBg: 'bg-cyan-500/10 text-cyan-600 dark:bg-cyan-500/20 dark:text-cyan-400',
    gradient: 'from-cyan-500/20 via-teal-500/15 to-transparent',
    glassBorder: 'border-cyan-500/30 hover:border-cyan-500/60',
    glowColor: 'rgba(6, 182, 212, 0.25)',
    textLight: 'text-cyan-600',
    textDark: 'dark:text-cyan-400'
  },
  'Voter ID': {
    label: 'Voter ID',
    iconBg: 'bg-teal-500/10 text-teal-600 dark:bg-teal-500/20 dark:text-teal-400',
    gradient: 'from-teal-500/20 via-emerald-500/15 to-transparent',
    glassBorder: 'border-teal-500/30 hover:border-teal-500/60',
    glowColor: 'rgba(20, 184, 166, 0.25)',
    textLight: 'text-teal-600',
    textDark: 'dark:text-teal-400'
  },
  'Ration Card': {
    label: 'Ration Card',
    iconBg: 'bg-lime-500/10 text-lime-600 dark:bg-lime-500/20 dark:text-lime-400',
    gradient: 'from-lime-500/20 via-emerald-500/15 to-transparent',
    glassBorder: 'border-lime-500/30 hover:border-lime-500/60',
    glowColor: 'rgba(132, 204, 22, 0.25)',
    textLight: 'text-lime-600',
    textDark: 'dark:text-lime-400'
  },
  'Birth Certificate': {
    label: 'Birth Certificate',
    iconBg: 'bg-sky-500/10 text-sky-600 dark:bg-sky-500/20 dark:text-sky-400',
    gradient: 'from-sky-500/20 via-blue-500/15 to-transparent',
    glassBorder: 'border-sky-500/30 hover:border-sky-500/60',
    glowColor: 'rgba(14, 165, 233, 0.25)',
    textLight: 'text-sky-600',
    textDark: 'dark:text-sky-400'
  },
  'Marriage Certificate': {
    label: 'Marriage Certificate',
    iconBg: 'bg-pink-500/10 text-pink-600 dark:bg-pink-500/20 dark:text-pink-400',
    gradient: 'from-pink-500/20 via-rose-500/15 to-transparent',
    glassBorder: 'border-pink-500/30 hover:border-pink-500/60',
    glowColor: 'rgba(236, 72, 153, 0.25)',
    textLight: 'text-pink-600',
    textDark: 'dark:text-pink-400'
  },
  Bank: {
    label: 'Bank',
    iconBg: 'bg-emerald-500/10 text-emerald-600 dark:bg-emerald-500/20 dark:text-emerald-400',
    gradient: 'from-emerald-500/20 via-teal-500/15 to-transparent',
    glassBorder: 'border-emerald-500/30 hover:border-emerald-500/60',
    glowColor: 'rgba(16, 185, 129, 0.25)',
    textLight: 'text-emerald-600',
    textDark: 'dark:text-emerald-400'
  },
  Insurance: {
    label: 'Insurance',
    iconBg: 'bg-purple-500/10 text-purple-600 dark:bg-purple-500/20 dark:text-purple-400',
    gradient: 'from-purple-500/20 via-violet-500/15 to-transparent',
    glassBorder: 'border-purple-500/30 hover:border-purple-500/60',
    glowColor: 'rgba(168, 85, 247, 0.25)',
    textLight: 'text-purple-600',
    textDark: 'dark:text-purple-400'
  },
  Education: {
    label: 'Education',
    iconBg: 'bg-amber-500/10 text-amber-600 dark:bg-amber-500/20 dark:text-amber-400',
    gradient: 'from-amber-500/20 via-yellow-500/15 to-transparent',
    glassBorder: 'border-amber-500/30 hover:border-amber-500/60',
    glowColor: 'rgba(245, 158, 11, 0.25)',
    textLight: 'text-amber-600',
    textDark: 'dark:text-amber-400'
  },
  Property: {
    label: 'Property',
    iconBg: 'bg-teal-500/10 text-teal-600 dark:bg-teal-500/20 dark:text-teal-400',
    gradient: 'from-teal-600/20 via-cyan-500/15 to-transparent',
    glassBorder: 'border-teal-500/30 hover:border-teal-500/60',
    glowColor: 'rgba(20, 184, 166, 0.25)',
    textLight: 'text-teal-600',
    textDark: 'dark:text-teal-400'
  },
  Vehicle: {
    label: 'Vehicle',
    iconBg: 'bg-rose-500/10 text-rose-600 dark:bg-rose-500/20 dark:text-rose-400',
    gradient: 'from-rose-500/20 via-red-500/15 to-transparent',
    glassBorder: 'border-rose-500/30 hover:border-rose-500/60',
    glowColor: 'rgba(244, 63, 94, 0.25)',
    textLight: 'text-rose-600',
    textDark: 'dark:text-rose-400'
  },
  Other: {
    label: 'Other',
    iconBg: 'bg-slate-500/10 text-slate-600 dark:bg-slate-500/20 dark:text-slate-400',
    gradient: 'from-slate-500/15 via-slate-400/10 to-transparent',
    glassBorder: 'border-slate-500/20 hover:border-slate-500/40',
    glowColor: 'rgba(100, 116, 139, 0.2)',
    textLight: 'text-slate-600',
    textDark: 'dark:text-slate-400'
  }
};
