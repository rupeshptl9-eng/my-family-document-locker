import React from 'react';
import { FileUp, FileText, Camera, Sparkles, X } from 'lucide-react';

interface AddBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectAction: (action: 'upload' | 'text' | 'camera' | 'ai-scan') => void;
}

export const AddBottomSheet: React.FC<AddBottomSheetProps> = ({
  isOpen,
  onClose,
  onSelectAction
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end animate-fadeIn select-none">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm transition-opacity"
      />

      {/* Sheet Content (Slide Up) */}
      <div className="relative w-full max-w-lg mx-auto glass-modal rounded-t-[32px] p-6 shadow-2xl border-t border-white/20 dark:border-white/10 z-10 animate-slideUp">
        {/* Grab Handle */}
        <div className="w-12 h-1.5 rounded-full bg-slate-300 dark:bg-white/20 mx-auto mb-4" />

        {/* Header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">
              Add to Family Locker
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Choose how you want to add documents or secure notes
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-2xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4 Actions Grid */}
        <div className="grid grid-cols-1 gap-2.5 pb-2">
          {/* 1. Add Document */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('upload');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl glass-card hover:border-blue-400/50 dark:hover:border-blue-500/40 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-blue-500/20">
              <FileUp className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>📄 Add Document</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                Upload PDF, JPG, or PNG from device storage
              </p>
            </div>
          </button>

          {/* 2. Add Text */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('text');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl glass-card hover:border-emerald-400/50 dark:hover:border-emerald-500/40 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-emerald-500/20">
              <FileText className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>📝 Add Secure Text</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                Save passwords, bank details, emergency notes
              </p>
            </div>
          </button>

          {/* 3. Scan Document */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('camera');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl glass-card hover:border-cyan-400/50 dark:hover:border-cyan-500/40 transition-all active:scale-[0.98] text-left cursor-pointer group"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-cyan-500/20">
              <Camera className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                <span>📷 Scan Document</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                Capture physical documents with device camera
              </p>
            </div>
          </button>

          {/* 4. Scan with AI */}
          <button
            onClick={() => {
              onClose();
              onSelectAction('ai-scan');
            }}
            className="flex items-center gap-4 p-3.5 rounded-2xl glass-card border-purple-300/40 dark:border-purple-800/40 hover:border-purple-400 dark:hover:border-purple-600 transition-all active:scale-[0.98] text-left cursor-pointer group relative overflow-hidden"
          >
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-pink-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-purple-500/25">
              <Sparkles className="w-6 h-6" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-semibold text-purple-900 dark:text-purple-300">
                  ✨ Scan with AI
                </h4>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/50">
                  Smart OCR
                </span>
              </div>
              <p className="text-xs text-purple-700/80 dark:text-purple-300/70 truncate mt-0.5">
                Auto-extract ID number, expiry dates & verify before saving
              </p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

