import React, { useState } from 'react';
import {
  Users,
  Plus,
  ChevronRight,
  FolderClosed,
  Calendar,
  Heart,
  Edit2,
  Trash2,
  X,
  Check,
  User
} from 'lucide-react';
import { FamilyMember, FamilyRelationship, Gender, LockerDocument } from '../types';
import { formatDate } from '../utils/documentUtils';

interface FamilyScreenProps {
  familyMembers: FamilyMember[];
  documents: LockerDocument[];
  onSelectFamilyMember: (member: FamilyMember) => void;
  onAddFamilyMember: (member: FamilyMember) => void;
  onUpdateFamilyMember: (member: FamilyMember) => void;
  onDeleteFamilyMember: (memberId: string) => void;
}

const RELATIONSHIPS: FamilyRelationship[] = [
  'Self',
  'Wife',
  'Husband',
  'Daughter',
  'Son',
  'Father',
  'Mother',
  'Brother',
  'Sister',
  'Other'
];

const AVATAR_COLORS = [
  '#3b82f6', // blue
  '#ec4899', // pink
  '#06b6d4', // cyan
  '#8b5cf6', // purple
  '#10b981', // emerald
  '#f59e0b', // amber
  '#ef4444'  // red
];

export const FamilyScreen: React.FC<FamilyScreenProps> = ({
  familyMembers,
  documents,
  onSelectFamilyMember,
  onAddFamilyMember,
  onUpdateFamilyMember,
  onDeleteFamilyMember
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<FamilyMember | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [relationship, setRelationship] = useState<FamilyRelationship>('Wife');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState<Gender>('Unspecified');
  const [notes, setNotes] = useState('');
  const [color, setColor] = useState(AVATAR_COLORS[0]);
  const [photoUrl, setPhotoUrl] = useState('');

  const openAddModal = () => {
    setEditingMember(null);
    setName('');
    setRelationship('Wife');
    setDob('');
    setGender('Unspecified');
    setNotes('');
    setColor(AVATAR_COLORS[1]);
    setPhotoUrl('');
    setIsAddModalOpen(true);
  };

  const openEditModal = (member: FamilyMember, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingMember(member);
    setName(member.name);
    setRelationship(member.relationship);
    setDob(member.dob || '');
    setGender(member.gender || 'Unspecified');
    setNotes(member.notes || '');
    setColor(member.color || AVATAR_COLORS[0]);
    setPhotoUrl(member.photoUrl || '');
    setIsAddModalOpen(true);
  };

  const handleSaveMember = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingMember) {
      onUpdateFamilyMember({
        ...editingMember,
        name: name.trim(),
        relationship,
        dob,
        gender,
        notes: notes.trim(),
        color,
        photoUrl: photoUrl.trim() || editingMember.photoUrl
      });
    } else {
      const newMember: FamilyMember = {
        id: `fam_${Date.now()}`,
        name: name.trim(),
        relationship,
        dob,
        gender,
        notes: notes.trim(),
        color,
        photoUrl: photoUrl.trim() || '',
        createdAt: new Date().toISOString()
      };
      onAddFamilyMember(newMember);
    }

    setIsAddModalOpen(false);
  };

  return (
    <div className="flex-1 pb-24 px-4 pt-3 select-none animate-fadeIn space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Family Members
            </h2>
            <span className="glass-pill text-[10px] font-bold px-2 py-0.5 text-blue-600 dark:text-blue-400">
              {familyMembers.length} {familyMembers.length === 1 ? 'Profile' : 'Profiles'}
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Organize & securely isolate documents for each family member
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-semibold hover:shadow-lg hover:shadow-blue-500/25 transition-all active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add Member</span>
        </button>
      </div>

      {/* Empty State */}
      {familyMembers.length === 0 ? (
        <div className="glass-card p-8 rounded-3xl text-center space-y-3 mt-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-purple-500/10 to-indigo-500/10 dark:from-purple-500/20 dark:to-indigo-500/20 text-purple-600 dark:text-purple-400 mx-auto flex items-center justify-center border border-purple-500/20">
            <Users className="w-7 h-7" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white">
              No family members added yet
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
              Add yourself, spouse, children, or parents to categorize and protect your locker documents.
            </p>
          </div>
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-semibold shadow-md shadow-blue-500/20 hover:shadow-lg transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Family Profile</span>
          </button>
        </div>
      ) : (
        /* Family Members Cards */
        <div className="space-y-3">
          {familyMembers.map((member) => {
            const memberDocs = documents.filter((d) => d.familyMemberId === member.id);

            return (
              <div
                key={member.id}
                onClick={() => onSelectFamilyMember(member)}
                className="glass-card p-4 rounded-3xl transition-all cursor-pointer shadow-xs hover:shadow-md hover:border-blue-400/50 dark:hover:border-blue-500/40 active:scale-[0.99] group space-y-3 relative overflow-hidden"
              >
                {/* Subtle top ambient glow from member color */}
                <div
                  className="absolute top-0 right-0 w-32 h-32 rounded-full blur-2xl opacity-10 pointer-events-none transition-opacity group-hover:opacity-20"
                  style={{ backgroundColor: member.color }}
                />

                <div className="flex items-center justify-between relative z-10">
                  <div className="flex items-center gap-3.5">
                    {/* Avatar */}
                    <div className="relative">
                      {member.photoUrl ? (
                        <img
                          src={member.photoUrl}
                          alt={member.name}
                          className="w-12 h-12 rounded-2xl object-cover border-2 transition-transform group-hover:scale-105 shadow-xs"
                          style={{ borderColor: member.color }}
                        />
                      ) : (
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-base shadow-sm ring-2 ring-white/20 dark:ring-white/10"
                          style={{
                            background: `linear-gradient(135deg, ${member.color}, ${member.color}dd)`
                          }}
                        >
                          {member.name.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div
                        className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-[#0f172a] flex items-center justify-center text-white shadow-xs"
                        style={{ backgroundColor: member.color }}
                      >
                        <Heart className="w-2.5 h-2.5 fill-current" />
                      </div>
                    </div>

                    {/* Member Details */}
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                          {member.name}
                        </h4>
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-white/10 text-slate-700 dark:text-slate-300 border border-slate-200/50 dark:border-white/5">
                          {member.relationship}
                        </span>
                      </div>

                      <div className="flex items-center gap-2.5 text-xs text-slate-500 dark:text-slate-400 mt-1">
                        {member.dob && (
                          <span className="flex items-center gap-1 text-[11px]">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <span>Born {formatDate(member.dob)}</span>
                          </span>
                        )}
                        {member.gender && member.gender !== 'Unspecified' && (
                          <span className="text-[11px]">· {member.gender}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => openEditModal(member, e)}
                      className="p-2 text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-white/10 rounded-xl transition-colors cursor-pointer"
                      title="Edit profile"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <ChevronRight className="w-5 h-5 text-slate-400 group-hover:text-blue-500 group-hover:translate-x-0.5 transition-all" />
                  </div>
                </div>

                {member.notes && (
                  <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50/70 dark:bg-white/5 p-2.5 rounded-2xl border border-slate-200/50 dark:border-white/5 relative z-10">
                    {member.notes}
                  </p>
                )}

                <div className="flex items-center justify-between pt-2.5 border-t border-slate-200/60 dark:border-white/5 text-xs text-slate-500 dark:text-slate-400 relative z-10">
                  <span className="flex items-center gap-1.5 font-medium">
                    <FolderClosed className="w-3.5 h-3.5 text-blue-500" />
                    <span>{memberDocs.length} {memberDocs.length === 1 ? 'document' : 'documents'} stored</span>
                  </span>
                  <span className="text-blue-600 dark:text-blue-400 font-semibold group-hover:underline text-[11px] flex items-center gap-1">
                    <span>View Documents</span>
                    <span>→</span>
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Family Member Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-md animate-fadeIn select-none">
          <div className="w-full max-w-sm glass-modal rounded-3xl p-6 shadow-2xl border border-white/20 dark:border-white/10 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200/60 dark:border-white/10">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                {editingMember ? 'Edit Family Member' : 'Add Family Member'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100/80 dark:hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveMember} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Kishori Patil"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-100/70 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Relationship *
                  </label>
                  <select
                    value={relationship}
                    onChange={(e) => setRelationship(e.target.value as FamilyRelationship)}
                    className="w-full px-2.5 py-2.5 rounded-xl bg-slate-100/70 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {RELATIONSHIPS.map((rel) => (
                      <option key={rel} value={rel}>
                        {rel}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Gender
                  </label>
                  <select
                    value={gender}
                    onChange={(e) => setGender(e.target.value as Gender)}
                    className="w-full px-2.5 py-2.5 rounded-xl bg-slate-100/70 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="Unspecified">Unspecified</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Date of Birth
                </label>
                <input
                  type="date"
                  value={dob}
                  onChange={(e) => setDob(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-100/70 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Color Tag
                </label>
                <div className="flex items-center gap-2">
                  {AVATAR_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-7 h-7 rounded-full cursor-pointer flex items-center justify-center transition-all ${
                        color === c ? 'ring-2 ring-offset-2 ring-blue-500 scale-110' : 'hover:scale-105 opacity-80 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: c }}
                    >
                      {color === c && <Check className="w-3.5 h-3.5 text-white stroke-[3]" />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Notes (Insurance role, medical allergies, etc.)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notes about policy nominee, school info..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-100/70 dark:bg-white/5 border border-slate-200/80 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                {editingMember && (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm(`Remove ${editingMember.name} from family profiles?`)) {
                        onDeleteFamilyMember(editingMember.id);
                        setIsAddModalOpen(false);
                      }
                    }}
                    className="p-2.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors cursor-pointer"
                    title="Delete member"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-xs font-semibold text-white hover:shadow-md transition-all cursor-pointer"
                >
                  Save Profile
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
