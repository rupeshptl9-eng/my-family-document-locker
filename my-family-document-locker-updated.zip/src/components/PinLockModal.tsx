import React, { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  Fingerprint,
  ShieldCheck,
  AlertCircle,
  Delete,
  X,
  HelpCircle
} from 'lucide-react';
import { pinService } from '../services/pinService';

interface PinLockModalProps {
  mode: 'unlock' | 'setup' | 'change';
  isOpen: boolean;
  userEmail?: string;
  onSuccess: () => void;
  onCancel?: () => void;
  onResetViaAccount?: () => void;
}

export const PinLockModal: React.FC<PinLockModalProps> = ({
  mode,
  isOpen,
  userEmail,
  onSuccess,
  onCancel,
  onResetViaAccount
}) => {
  const [pinDigits, setPinDigits] = useState<string>('');
  const [confirmDigits, setConfirmDigits] = useState<string>('');
  const [step, setStep] = useState<'enter' | 'confirm'>('enter');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLockedOut, setIsLockedOut] = useState<boolean>(false);
  const [lockoutSeconds, setLockoutSeconds] = useState<number>(0);
  const [biometricAvailable, setBiometricAvailable] = useState<boolean>(false);
  const [biometryLabel, setBiometryLabel] = useState<string>('Biometric');

  useEffect(() => {
    if (isOpen) {
      setPinDigits('');
      setConfirmDigits('');
      setStep('enter');
      setErrorMessage(null);

      // Check lockout status
      const remaining = pinService.getLockoutRemainingSeconds();
      if (remaining > 0) {
        setIsLockedOut(true);
        setLockoutSeconds(remaining);
      } else {
        setIsLockedOut(false);
      }

      // Check biometric availability
      pinService.isBiometricAvailable().then((res) => {
        setBiometricAvailable(res.available);
        if (res.biometryType) {
          setBiometryLabel(res.biometryType);
        }
        if (res.available && mode === 'unlock' && remaining === 0) {
          triggerBiometric();
        }
      });
    }
  }, [isOpen, mode]);

  // Lockout countdown timer
  useEffect(() => {
    if (lockoutSeconds > 0) {
      const timer = setInterval(() => {
        setLockoutSeconds((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setIsLockedOut(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [lockoutSeconds]);

  if (!isOpen) return null;

  // Trigger biometric
  const triggerBiometric = async () => {
    try {
      setErrorMessage(null);
      const success = await pinService.authenticateBiometric();
      if (success) {
        onSuccess();
      }
    } catch (err: any) {
      setErrorMessage('Biometric authentication is unavailable. Use your PIN.');
    }
  };

  // Handle number pad button tap
  const handleDigitTap = async (digit: string) => {
    if (isLockedOut) return;

    if (mode === 'setup') {
      if (step === 'enter') {
        const next = pinDigits + digit;
        if (next.length <= 4) {
          setPinDigits(next);
          if (next.length === 4) {
            setStep('confirm');
          }
        }
      } else {
        const next = confirmDigits + digit;
        if (next.length <= 4) {
          setConfirmDigits(next);
          if (next.length === 4) {
            if (next === pinDigits) {
              await pinService.setupPin(next);
              onSuccess();
            } else {
              setErrorMessage('PINs do not match. Please try again.');
              setPinDigits('');
              setConfirmDigits('');
              setStep('enter');
            }
          }
        }
      }
    } else {
      // Unlock or Change
      const next = pinDigits + digit;
      if (next.length <= 4) {
        setPinDigits(next);
        if (next.length === 4) {
          const result = await pinService.verifyUserPin(next);
          if (result.success) {
            onSuccess();
          } else {
            setPinDigits('');
            if (result.lockedSeconds) {
              setIsLockedOut(true);
              setLockoutSeconds(result.lockedSeconds);
              setErrorMessage(`Too many incorrect attempts. Locked for ${result.lockedSeconds}s.`);
            } else {
              setErrorMessage(`Incorrect PIN. ${result.remainingAttempts || 0} attempts left.`);
            }
          }
        }
      }
    }
  };

  // Backspace
  const handleBackspace = () => {
    if (step === 'confirm') {
      setConfirmDigits((prev) => prev.slice(0, -1));
    } else {
      setPinDigits((prev) => prev.slice(0, -1));
    }
  };

  const activeDigits = step === 'confirm' ? confirmDigits : pinDigits;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-fadeIn select-none">
      <div className="w-full max-w-xs glass-modal rounded-3xl p-6 shadow-2xl border border-white/20 dark:border-white/10 flex flex-col items-center text-center space-y-4 relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-10 left-1/2 -translate-x-1/2 w-40 h-40 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Header Icon */}
        <div className="relative">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-lg shadow-blue-500/30">
            <Lock className="w-8 h-8" />
          </div>
        </div>

        <div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {mode === 'setup'
              ? step === 'enter'
                ? 'Create Vault PIN'
                : 'Confirm Vault PIN'
              : 'Unlock Encrypted Vault'}
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {mode === 'setup'
              ? 'Set a 4-digit PIN to derive your AES-256 vault encryption key'
              : 'Enter your PIN or biometric to decrypt your documents'}
          </p>
        </div>

        {/* PIN Dots Display */}
        <div className="flex items-center gap-3 py-2">
          {[0, 1, 2, 3].map((index) => {
            const isFilled = activeDigits.length > index;
            return (
              <div
                key={index}
                className={`w-3.5 h-3.5 rounded-full transition-all duration-150 ${
                  isFilled
                    ? 'bg-gradient-to-r from-blue-500 to-indigo-600 scale-125 shadow-xs shadow-blue-500/50'
                    : 'bg-slate-200 dark:bg-white/15 border border-slate-300 dark:border-white/20'
                }`}
              />
            );
          })}
        </div>

        {/* Error message */}
        {errorMessage && (
          <p className="text-xs text-rose-500 font-medium px-2 leading-tight">
            {errorMessage}
          </p>
        )}

        {/* Lockout status */}
        {isLockedOut && (
          <div className="p-2.5 rounded-xl bg-rose-50/80 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-xs text-rose-700 dark:text-rose-300">
            Locked for {lockoutSeconds} seconds
          </div>
        )}

        {/* Numeric Keypad (3x4 Grid) */}
        <div className="grid grid-cols-3 gap-2.5 w-full pt-1">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              type="button"
              disabled={isLockedOut}
              onClick={() => handleDigitTap(digit)}
              className="h-12 rounded-2xl bg-slate-100/80 hover:bg-slate-200/80 dark:bg-white/5 dark:hover:bg-white/10 active:scale-95 text-base font-bold text-slate-900 dark:text-white border border-slate-200/50 dark:border-white/5 transition-all cursor-pointer shadow-2xs hover:border-blue-400/40"
            >
              {digit}
            </button>
          ))}

          {/* Biometric button or cancel */}
          {biometricAvailable && mode === 'unlock' ? (
            <button
              type="button"
              onClick={triggerBiometric}
              className="h-12 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/40 text-blue-600 dark:text-blue-400 flex items-center justify-center active:scale-95 transition-all cursor-pointer"
              title={`Unlock with ${biometryLabel}`}
            >
              <Fingerprint className="w-6 h-6" />
            </button>
          ) : onCancel ? (
            <button
              type="button"
              onClick={onCancel}
              className="h-12 rounded-2xl bg-slate-100/80 dark:bg-white/5 border border-slate-200/50 dark:border-white/5 text-slate-500 hover:text-slate-800 dark:hover:text-white flex items-center justify-center text-xs font-semibold active:scale-95 cursor-pointer"
            >
              Cancel
            </button>
          ) : (
            <div className="h-12" />
          )}

          {/* 0 digit */}
          <button
            type="button"
            disabled={isLockedOut}
            onClick={() => handleDigitTap('0')}
            className="h-12 rounded-2xl bg-slate-100/80 hover:bg-slate-200/80 dark:bg-white/5 dark:hover:bg-white/10 active:scale-95 text-base font-bold text-slate-900 dark:text-white border border-slate-200/50 dark:border-white/5 transition-all cursor-pointer shadow-2xs hover:border-blue-400/40"
          >
            0
          </button>

          {/* Backspace */}
          <button
            type="button"
            onClick={handleBackspace}
            className="h-12 rounded-2xl bg-slate-100/80 hover:bg-slate-200/80 dark:bg-white/5 dark:hover:bg-white/10 text-slate-600 dark:text-slate-400 flex items-center justify-center active:scale-95 transition-all cursor-pointer border border-slate-200/50 dark:border-white/5"
            title="Delete"
          >
            <Delete className="w-5 h-5" />
          </button>
        </div>

        {/* Forgot PIN / Reset Account Option */}
        {mode === 'unlock' && onResetViaAccount && (
          <button
            type="button"
            onClick={onResetViaAccount}
            className="text-[11px] text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors pt-1 cursor-pointer flex items-center gap-1"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Reset Vault PIN via Google Account</span>
          </button>
        )}
      </div>
    </div>
  );
};
