import React, { useState, useEffect, useRef, useMemo } from 'react';
import * as d3 from 'd3';
import { BarChart3, PieChart, HardDrive, ShieldCheck, Layers } from 'lucide-react';
import { LockerDocument, TextNote } from '../types';
import { formatFileSize } from '../utils/documentUtils';

interface VaultAnalyticsChartProps {
  documents: LockerDocument[];
  textNotes: TextNote[];
  totalStorageBytes: number;
  maxStorageBytes?: number; // default 15GB
  onSelectCategory?: (category: string) => void;
}

interface CategoryData {
  category: string;
  count: number;
  sizeBytes: number;
  color: string;
  glowColor: string;
}

const CATEGORY_COLORS: Record<string, { fill: string; fillEnd: string; glow: string }> = {
  Aadhaar: { fill: '#f97316', fillEnd: '#fb923c', glow: 'rgba(249, 115, 22, 0.4)' },
  PAN: { fill: '#3b82f6', fillEnd: '#60a5fa', glow: 'rgba(59, 130, 246, 0.4)' },
  Passport: { fill: '#6366f1', fillEnd: '#818cf8', glow: 'rgba(99, 102, 241, 0.4)' },
  'Driving Licence': { fill: '#06b6d4', fillEnd: '#22d3ee', glow: 'rgba(6, 182, 212, 0.4)' },
  Insurance: { fill: '#a855f7', fillEnd: '#c084fc', glow: 'rgba(168, 85, 247, 0.4)' },
  Education: { fill: '#f59e0b', fillEnd: '#fbbf24', glow: 'rgba(245, 158, 11, 0.4)' },
  Bank: { fill: '#10b981', fillEnd: '#34d399', glow: 'rgba(16, 185, 129, 0.4)' },
  Property: { fill: '#14b8a6', fillEnd: '#2dd4bf', glow: 'rgba(20, 184, 166, 0.4)' },
  Vehicle: { fill: '#f43f5e', fillEnd: '#fb7185', glow: 'rgba(244, 63, 94, 0.4)' },
  'Voter ID': { fill: '#0ea5e9', fillEnd: '#38bdf8', glow: 'rgba(14, 165, 233, 0.4)' },
  'Birth Certificate': { fill: '#38bdf8', fillEnd: '#7dd3fc', glow: 'rgba(56, 189, 248, 0.4)' },
  'Marriage Certificate': { fill: '#ec4899', fillEnd: '#f472b6', glow: 'rgba(236, 72, 153, 0.4)' },
  'Ration Card': { fill: '#84cc16', fillEnd: '#a3e635', glow: 'rgba(132, 204, 22, 0.4)' },
  Other: { fill: '#64748b', fillEnd: '#94a3b8', glow: 'rgba(100, 116, 139, 0.4)' }
};

export const VaultAnalyticsChart: React.FC<VaultAnalyticsChartProps> = ({
  documents,
  textNotes,
  totalStorageBytes,
  maxStorageBytes = 15 * 1024 * 1024 * 1024, // 15 GB
  onSelectCategory
}) => {
  const [activeTab, setActiveTab] = useState<'both' | 'distribution' | 'storage'>('both');
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  const barChartRef = useRef<SVGSVGElement | null>(null);
  const ringChartRef = useRef<SVGSVGElement | null>(null);

  // Group documents by category
  const categoryData: CategoryData[] = useMemo(() => {
    const map = new Map<string, { count: number; sizeBytes: number }>();

    documents.forEach((doc) => {
      const cat = doc.category || 'Other';
      const existing = map.get(cat) || { count: 0, sizeBytes: 0 };
      existing.count += 1;
      existing.sizeBytes += doc.fileSize || 50000;
      map.set(cat, existing);
    });

    // Also include text notes as an identifiable item in analytics if present
    if (textNotes.length > 0) {
      const notesSize = textNotes.reduce((acc, n) => acc + (n.content?.length || 0) * 2, 0) + (textNotes.length * 1024);
      map.set('Text Notes', { count: textNotes.length, sizeBytes: notesSize });
    }

    const result: CategoryData[] = [];
    map.forEach((val, key) => {
      const colorMeta = CATEGORY_COLORS[key] || {
        fill: '#8b5cf6',
        fillEnd: '#a78bfa',
        glow: 'rgba(139, 92, 246, 0.4)'
      };
      result.push({
        category: key,
        count: val.count,
        sizeBytes: val.sizeBytes,
        color: colorMeta.fill,
        glowColor: colorMeta.glow
      });
    });

    // Sort descending by count
    return result.sort((a, b) => b.count - a.count);
  }, [documents, textNotes]);

  // Compute ring chart slices: Top categories + Other
  const ringSlices = useMemo(() => {
    const totalUsed = Math.max(totalStorageBytes, 1024 * 1024); // at least 1MB display
    const slices: { label: string; value: number; color: string; percent: number }[] = [];

    // Take top 4 categories by size, group rest in Other Docs
    const sortedBySize = [...categoryData].sort((a, b) => b.sizeBytes - a.sizeBytes);
    const topCategories = sortedBySize.slice(0, 4);
    const otherCategories = sortedBySize.slice(4);

    topCategories.forEach((cat) => {
      const p = (cat.sizeBytes / totalUsed) * 100;
      slices.push({
        label: cat.category,
        value: cat.sizeBytes,
        color: cat.color,
        percent: p
      });
    });

    if (otherCategories.length > 0) {
      const otherSize = otherCategories.reduce((acc, c) => acc + c.sizeBytes, 0);
      slices.push({
        label: 'Other Docs',
        value: otherSize,
        color: '#64748b',
        percent: (otherSize / totalUsed) * 100
      });
    }

    return slices;
  }, [categoryData, totalStorageBytes]);

  // ==========================================
  // D3 Bar Chart Render (Category Distribution)
  // ==========================================
  useEffect(() => {
    if (!barChartRef.current || categoryData.length === 0) return;

    const svg = d3.select(barChartRef.current);
    svg.selectAll('*').remove();

    const width = 360;
    const barHeight = 26;
    const gap = 9;
    const margin = { top: 8, right: 62, bottom: 8, left: 105 };
    const chartHeight = categoryData.length * (barHeight + gap) + margin.top + margin.bottom;

    svg.attr('viewBox', `0 0 ${width} ${chartHeight}`);

    // Definitions for gradients & shadow
    const defs = svg.append('defs');
    categoryData.forEach((d) => {
      const colorMeta = CATEGORY_COLORS[d.category] || { fill: d.color, fillEnd: d.color, glow: d.glowColor };
      const grad = defs
        .append('linearGradient')
        .attr('id', `bar-grad-${d.category.replace(/[^a-zA-Z0-9]/g, '-')}`)
        .attr('x1', '0%')
        .attr('y1', '0%')
        .attr('x2', '100%')
        .attr('y2', '0%');
      grad.append('stop').attr('offset', '0%').attr('stop-color', colorMeta.fill);
      grad.append('stop').attr('offset', '100%').attr('stop-color', colorMeta.fillEnd);
    });

    const maxCount = d3.max(categoryData, (d) => d.count) || 1;
    const xScale = d3
      .scaleLinear()
      .domain([0, maxCount])
      .range([0, width - margin.left - margin.right]);

    const g = svg.append('g').attr('transform', `translate(${margin.left}, ${margin.top})`);

    // Render bars
    categoryData.forEach((d, i) => {
      const y = i * (barHeight + gap);
      const barWidth = Math.max(xScale(d.count), 12);
      const isHovered = hoveredCategory === d.category;

      // Group for each row
      const row = g
        .append('g')
        .attr('class', 'bar-row')
        .style('cursor', 'pointer')
        .on('mouseenter', () => setHoveredCategory(d.category))
        .on('mouseleave', () => setHoveredCategory(null))
        .on('click', () => onSelectCategory && onSelectCategory(d.category));

      // Category Label (Left)
      row
        .append('text')
        .attr('x', -8)
        .attr('y', y + barHeight / 2 + 4)
        .attr('text-anchor', 'end')
        .attr('fill', isHovered ? '#3b82f6' : 'currentColor')
        .attr('class', 'text-[11px] font-semibold select-none transition-colors duration-150')
        .style('font-family', 'Inter, system-ui, sans-serif')
        .text(d.category.length > 13 ? `${d.category.slice(0, 12)}…` : d.category);

      // Background Track
      row
        .append('rect')
        .attr('x', 0)
        .attr('y', y + 3)
        .attr('width', width - margin.left - margin.right)
        .attr('height', barHeight - 6)
        .attr('rx', (barHeight - 6) / 2)
        .attr('fill', 'rgba(148, 163, 184, 0.12)')
        .attr('stroke', 'rgba(255, 255, 255, 0.05)');

      // Filled Gradient Bar
      row
        .append('rect')
        .attr('x', 0)
        .attr('y', y + 3)
        .attr('width', 0)
        .attr('height', barHeight - 6)
        .attr('rx', (barHeight - 6) / 2)
        .attr('fill', `url(#bar-grad-${d.category.replace(/[^a-zA-Z0-9]/g, '-')})`)
        .style('filter', isHovered ? `drop-shadow(0 0 6px ${d.glowColor})` : 'none')
        .transition()
        .duration(600)
        .delay(i * 40)
        .ease(d3.easeCubicOut)
        .attr('width', barWidth);

      // Value Label (Right)
      row
        .append('text')
        .attr('x', barWidth + 8)
        .attr('y', y + barHeight / 2 + 4)
        .attr('fill', 'currentColor')
        .attr('class', 'text-[11px] font-mono font-bold select-none opacity-80')
        .style('font-family', 'JetBrains Mono, monospace')
        .text(`${d.count} ${d.count === 1 ? 'doc' : 'docs'}`)
        .style('opacity', 0)
        .transition()
        .duration(500)
        .delay(i * 40 + 200)
        .style('opacity', 1);
    });
  }, [categoryData, hoveredCategory, onSelectCategory]);

  // ==========================================
  // D3 Ring Chart Render (Storage Usage)
  // ==========================================
  useEffect(() => {
    if (!ringChartRef.current || ringSlices.length === 0) return;

    const svg = d3.select(ringChartRef.current);
    svg.selectAll('*').remove();

    const size = 180;
    const radius = size / 2;
    const innerRadius = radius - 26;
    const outerRadius = radius - 8;

    svg.attr('viewBox', `0 0 ${size} ${size}`);

    const g = svg.append('g').attr('transform', `translate(${radius}, ${radius})`);

    // Subtle background track ring
    const bgArc = d3
      .arc<any>()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius)
      .startAngle(0)
      .endAngle(2 * Math.PI);

    g.append('path')
      .attr('d', bgArc as any)
      .attr('fill', 'rgba(148, 163, 184, 0.12)');

    // D3 Pie Generator
    const pie = d3
      .pie<any>()
      .value((d) => d.value)
      .sort(null)
      .padAngle(0.04);

    const arc = d3
      .arc<any>()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius)
      .cornerRadius(5);

    const slices = g
      .selectAll('.slice')
      .data(pie(ringSlices))
      .enter()
      .append('g')
      .attr('class', 'slice')
      .style('cursor', 'pointer')
      .on('mouseenter', (_, d) => setHoveredCategory(d.data.label))
      .on('mouseleave', () => setHoveredCategory(null));

    slices
      .append('path')
      .attr('d', arc as any)
      .attr('fill', (d) => d.data.color)
      .style('opacity', 0.9)
      .style('transition', 'all 0.2s ease')
      .each(function (d) {
        // Smooth entrance animation
        const current = { startAngle: 0, endAngle: 0 };
        const interpolate = d3.interpolate(current, d);
        d3.select(this)
          .transition()
          .duration(700)
          .ease(d3.easeCubicOut)
          .attrTween('d', () => (t) => arc(interpolate(t) as any) as any);
      });

    // Center Display
    const centerGroup = g.append('g').attr('text-anchor', 'middle');

    centerGroup
      .append('text')
      .attr('y', -3)
      .attr('class', 'text-xs font-bold font-mono fill-slate-900 dark:fill-white')
      .style('font-family', 'JetBrains Mono, monospace')
      .text(formatFileSize(totalStorageBytes));

    centerGroup
      .append('text')
      .attr('y', 13)
      .attr('class', 'text-[10px] font-semibold tracking-wider uppercase fill-slate-400')
      .style('font-family', 'Inter, system-ui, sans-serif')
      .text('Vault Used');
  }, [ringSlices, totalStorageBytes]);

  const storagePercentage = useMemo(() => {
    return Math.min(Math.max((totalStorageBytes / maxStorageBytes) * 100, 0.05), 100).toFixed(1);
  }, [totalStorageBytes, maxStorageBytes]);

  return (
    <div className="p-4 rounded-3xl glass-card space-y-3.5 relative overflow-hidden select-none">
      {/* Top Ambient Glow */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header with Segmented Tab Control */}
      <div className="flex items-center justify-between pb-1 border-b border-slate-200/60 dark:border-white/5 relative z-10">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center shadow-xs">
            <BarChart3 className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
              <span>Vault Analytics</span>
              <span className="glass-pill text-[9px] px-1.5 py-0.2 font-semibold text-blue-600 dark:text-blue-400">
                D3 Live
              </span>
            </h4>
            <p className="text-[10px] text-slate-500 dark:text-slate-400">
              Distribution & encrypted storage footprint
            </p>
          </div>
        </div>

        {/* View Switcher Chips */}
        <div className="flex items-center gap-1 p-0.5 rounded-xl bg-slate-100/80 dark:bg-white/5 border border-slate-200/50 dark:border-white/5 text-[10px]">
          <button
            onClick={() => setActiveTab('both')}
            className={`px-2 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
              activeTab === 'both'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setActiveTab('distribution')}
            className={`px-2 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
              activeTab === 'distribution'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Categories
          </button>
          <button
            onClick={() => setActiveTab('storage')}
            className={`px-2 py-1 rounded-lg font-semibold transition-all cursor-pointer ${
              activeTab === 'storage'
                ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Storage
          </button>
        </div>
      </div>

      {documents.length === 0 && textNotes.length === 0 ? (
        /* Empty State */
        <div className="p-6 text-center space-y-2 rounded-2xl bg-slate-50/50 dark:bg-white/5 border border-slate-200/50 dark:border-white/5">
          <Layers className="w-8 h-8 text-blue-500 mx-auto opacity-70" />
          <h5 className="text-xs font-bold text-slate-800 dark:text-slate-200">
            No Documents in Vault Yet
          </h5>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
            Scan Aadhaar, PAN, or upload policies to see live category distribution and storage analytics.
          </p>
        </div>
      ) : (
        /* Charts Container */
        <div className="space-y-4">
          {/* 1. Ring Chart (Storage Ring) */}
          {(activeTab === 'both' || activeTab === 'storage') && (
            <div className="p-3 rounded-2xl bg-slate-50/50 dark:bg-white/5 border border-slate-200/50 dark:border-white/5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-[11px]">
                  <PieChart className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Storage Utilization Ring</span>
                </span>
                <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400">
                  {storagePercentage}% of 15 GB
                </span>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-around gap-3 pt-1">
                {/* D3 SVG Donut */}
                <div className="w-36 h-36 shrink-0 relative flex items-center justify-center">
                  <svg ref={ringChartRef} className="w-full h-full" />
                </div>

                {/* Ring Slices Legend */}
                <div className="flex-1 w-full space-y-1.5 text-xs">
                  {ringSlices.map((slice) => {
                    const isHovered = hoveredCategory === slice.label;
                    return (
                      <div
                        key={slice.label}
                        onMouseEnter={() => setHoveredCategory(slice.label)}
                        onMouseLeave={() => setHoveredCategory(null)}
                        className={`flex items-center justify-between p-1.5 rounded-xl transition-all ${
                          isHovered
                            ? 'bg-white/80 dark:bg-white/10 shadow-xs'
                            : 'hover:bg-white/40 dark:hover:bg-white/5'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className="w-2.5 h-2.5 rounded-full shrink-0 shadow-xs"
                            style={{ backgroundColor: slice.color }}
                          />
                          <span className="text-[11px] font-semibold text-slate-700 dark:text-slate-300 truncate">
                            {slice.label}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] font-mono shrink-0">
                          <span className="text-slate-500 dark:text-slate-400">
                            {formatFileSize(slice.value)}
                          </span>
                          <span className="font-bold text-slate-800 dark:text-slate-200 w-8 text-right">
                            {slice.percent.toFixed(0)}%
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* 2. D3 Bar Chart (Category Distribution) */}
          {(activeTab === 'both' || activeTab === 'distribution') && (
            <div className="p-3 rounded-2xl bg-slate-50/50 dark:bg-white/5 border border-slate-200/50 dark:border-white/5 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 text-[11px]">
                  <HardDrive className="w-3.5 h-3.5 text-blue-500" />
                  <span>Document Distribution by Category</span>
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
                  {documents.length} docs total
                </span>
              </div>

              {/* D3 SVG Bar Chart */}
              <div className="w-full overflow-hidden text-slate-700 dark:text-slate-300">
                <svg ref={barChartRef} className="w-full h-auto" />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Footer Insight Pill */}
      <div className="flex items-center justify-between pt-1 border-t border-slate-200/60 dark:border-white/5 text-[10px] text-slate-500 dark:text-slate-400">
        <span className="flex items-center gap-1">
          <ShieldCheck className="w-3 h-3 text-emerald-500" />
          <span>Local AES-256 Storage Safe</span>
        </span>
        <span className="font-mono">{documents.length} files · {textNotes.length} notes</span>
      </div>
    </div>
  );
};
