import React, { useState, useEffect } from 'react';
import {
  Bell,
  Sparkles,
  Camera,
  FilePlus,
  FileText,
  AlertTriangle,
  ChevronRight,
  Shield,
  CreditCard,
  Globe,
  Car,
  Landmark,
  HeartPulse,
  GraduationCap,
  Building,
  Folder,
  ArrowRight,
  Eye,
  Clock,
  Lock,
  Vote,
  FileCheck,
  Search,
  HardDrive,
  Users,
  X,
  Stethoscope,
  ScrollText
} from 'lucide-react';
import { DocumentCategory, FamilyMember, LockerDocument, TextNote, UserProfile } from '../types';
import { getExpiryStatus, CATEGORY_CONFIG, formatFileSize } from '../utils/documentUtils';
import { aiRouter, AIStatusInfo } from '../services/aiRouter';
import { VaultAnalyticsChart } from './VaultAnalyticsChart';

interface HomeScreenProps {
  user: UserProfile;
  documents: LockerDocument[];
  familyMembers: FamilyMember[];
  textNotes: TextNote[];
  unreadNotifsCount: number;
  onOpenNotifications: () => void;
  onNavigateToTab: (tab: 'home' | 'documents' | 'ai' | 'profile') => void;
  onNavigateToSubView: (view: 'family' | 'text-locker') => void;
  onSelectCategory: (category: DocumentCategory) => void;
  onQuickAction: (action: 'camera' | 'upload' | 'text' | 'ai-scan') => void;
  onViewDocument: (doc: LockerDocument) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  user,
  documents,
  familyMembers,
  textNotes,
  unreadNotifsCount,
  onOpenNotifications,
  onNavigateToTab,
  onNavigateToSubView,
  onSelectCategory,
  onQuickAction,
  onViewDocument
}) => {
  const [aiStatus, setAiStatus] = useState<AIStatusInfo | null>(null);
  const [dashboardSearch, setDashboardSearch] = useState('');

  useEffect(() => {
    const unsub = aiRouter.subscribe((status) => {
      setAiStatus(status);
    });
    return unsub;
  }, []);

  // Category counts
  const categoryCounts = documents.reduce((acc, doc) => {
    acc[doc.category] = (acc[doc.category] || 0) + 1;
    return acc;
  }, {} as Record<DocumentCategory, number>);

  // Expiring soon documents (within 30 days)
  const expiringDocs = documents.filter((doc) => {
    const { status } = getExpiryStatus(doc.expiryDate);
    return status === 'EXPIRING_SOON' || status === 'EXPIRED';
  });

  // Recently added documents (last 3)
  const recentDocs = [...documents]
    .sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
    .slice(0, 3);

  // Storage calculation
  const totalDocBytes = documents.reduce((acc, d) => acc + (d.fileSize || 0), 0);
  const totalNoteBytes = textNotes.reduce((acc, n) => acc + (n.content?.length || 0) * 2, 0);
  const totalStorageBytes = totalDocBytes + totalNoteBytes;
  const storageLimitBytes = 15 * 1024 * 1024 * 1024; // 15 GB
  const storagePercent = Math.max(1, Math.min(100, Math.round((totalStorageBytes / storageLimitBytes) * 100)));

  // Categories list with custom 3D gradient icons
  const CATEGORIES: {
    name: DocumentCategory;
    icon: React.ReactNode;
  }[] = [
    { name: 'Aadhaar', icon: <Shield className="w-5 h-5 text-orange-500" /> },
    { name: 'PAN', icon: <CreditCard className="w-5 h-5 text-blue-500" /> },
    { name: 'Passport', icon: <Globe className="w-5 h-5 text-indigo-500" /> },
    { name: 'Driving Licence', icon: <Car className="w-5 h-5 text-cyan-500" /> },
    { name: 'Voter ID', icon: <Vote className="w-5 h-5 text-teal-500" /> },
    { name: 'Bank', icon: <Landmark className="w-5 h-5 text-emerald-500" /> },
    { name: 'Insurance', icon: <HeartPulse className="w-5 h-5 text-purple-500" /> },
    { name: 'Education', icon: <GraduationCap className="w-5 h-5 text-amber-500" /> },
    { name: 'Property', icon: <Building className="w-5 h-5 text-teal-500" /> },
    { name: 'Vehicle', icon: <Car className="w-5 h-5 text-rose-500" /> },
    { name: 'Ration Card', icon: <ScrollText className="w-5 h-5 text-lime-500" /> },
    { name: 'Other', icon: <Folder className="w-5 h-5 text-slate-500" /> }
  ];

  const greetingName = user.displayName?.trim() ? user.displayName.split(' ')[0] : 'Family';

  // Search filtered items on dashboard
  const matchingSearchDocs = dashboardSearch.trim()
    ? documents.filter((d) => {
        const q = dashboardSearch.toLowerCase();
        return (
          d.name.toLowerCase().includes(q) ||
          d.category.toLowerCase().includes(q) ||
          d.familyMemberName?.toLowerCase().includes(q) ||
          d.maskedNumber?.toLowerCase().includes(q)
        );
      }).slice(0, 5)
    : [];

  return (
    <div className="flex-1 pb-24 px-4 pt-2 select-none space-y-4 animate-fadeIn">
      {/* Top Glass Header & Profile Bar */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateToTab('profile')}
            className="relative cursor-pointer group active:scale-95 transition-transform"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white font-bold text-sm flex items-center justify-center ring-2 ring-white/60 dark:ring-white/20 shadow-md">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName}
                  className="w-full h-full rounded-2xl object-cover"
                />
              ) : (
                greetingName.charAt(0).toUpperCase()
              )}
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-white dark:border-[#0f1118]" />
          </button>

          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white leading-tight flex items-center gap-1.5">
              <span>Hello, {greetingName}</span>
              <span className="text-sm">👋</span>
            </h2>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              Encrypted Family Vault · All Local
            </p>
          </div>
        </div>

        <button
          onClick={onOpenNotifications}
          aria-label="Notifications"
          className="relative p-2.5 rounded-2xl glass-pill text-slate-700 dark:text-slate-300 hover:bg-white/90 dark:hover:bg-white/10 transition-all active:scale-95 cursor-pointer shadow-xs"
        >
          <Bell className="w-5 h-5" />
          {unreadNotifsCount > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center animate-pulse">
              {unreadNotifsCount}
            </span>
          )}
        </button>
      </div>

      {/* Premium Glass Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
        <input
          type="text"
          value={dashboardSearch}
          onChange={(e) => setDashboardSearch(e.target.value)}
          placeholder="Search Aadhaar, PAN, policies, or family members..."
          className="w-full h-11 pl-10 pr-9 rounded-2xl glass-surface text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/60 shadow-xs transition-all"
        />
        {dashboardSearch && (
          <button
            onClick={() => setDashboardSearch('')}
            className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Instant Search Results Dropdown when typing */}
      {dashboardSearch.trim() && (
        <div className="p-3 rounded-2xl glass-surface space-y-2 border border-blue-500/30">
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 px-1">
            <span>Search Results ({matchingSearchDocs.length})</span>
            <button
              onClick={() => onNavigateToTab('documents')}
              className="text-blue-600 dark:text-blue-400 font-semibold hover:underline"
            >
              Open Vault Search
            </button>
          </div>
          {matchingSearchDocs.length === 0 ? (
            <p className="text-xs text-slate-400 text-center py-2">
              No documents matched "{dashboardSearch}"
            </p>
          ) : (
            matchingSearchDocs.map((doc) => (
              <div
                key={doc.id}
                onClick={() => onViewDocument(doc)}
                className="p-2 rounded-xl bg-white/60 dark:bg-white/5 hover:bg-blue-500/10 flex items-center justify-between cursor-pointer transition-colors"
              >
                <div className="min-w-0">
                  <p className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                    {doc.name}
                  </p>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400">
                    {doc.category} · {doc.familyMemberName} · {doc.maskedNumber}
                  </p>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
              </div>
            ))
          )}
        </div>
      )}

      {/* Prominent Smart Document Assistant Glass Card */}
      <div
        onClick={() => onNavigateToTab('ai')}
        className="relative overflow-hidden rounded-3xl p-5 bg-gradient-to-r from-purple-700/90 via-indigo-700/90 to-blue-700/90 text-white shadow-xl shadow-indigo-500/20 cursor-pointer active:scale-[0.99] transition-all group border border-white/20"
      >
        <div className="absolute -right-6 -bottom-8 w-36 h-36 rounded-full bg-white/10 blur-xl pointer-events-none group-hover:scale-125 transition-transform" />
        <div className="absolute right-4 top-4 opacity-15 pointer-events-none">
          <Sparkles className="w-20 h-20" />
        </div>

        <div className="relative z-10 flex items-start justify-between">
          <div className="space-y-1 max-w-[80%]">
            <div className="flex items-center gap-1.5 flex-wrap mb-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 backdrop-blur-md text-[11px] font-semibold text-white">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Smart Document Assistant</span>
              </div>
              {aiStatus && (
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/35 backdrop-blur-md text-[10px] font-medium text-white/95">
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      aiStatus.badgeColor === 'emerald'
                        ? 'bg-emerald-400'
                        : aiStatus.badgeColor === 'amber'
                        ? 'bg-amber-400 animate-pulse'
                        : 'bg-blue-400'
                    }`}
                  />
                  <span>{aiStatus.badgeText}</span>
                </div>
              )}
            </div>
            <h3 className="text-lg font-bold tracking-tight">✨ Ask AI Vault</h3>
            <p className="text-xs text-white/90 leading-snug">
              Instant offline answers across your family documents & validity dates
            </p>
          </div>

          <div className="w-9 h-9 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white shrink-0 group-hover:translate-x-1 transition-transform">
            <ArrowRight className="w-4 h-4" />
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-2 mt-4 pt-3 border-t border-white/15 overflow-x-auto no-scrollbar text-[11px]">
          <span className="shrink-0 px-2.5 py-1 rounded-xl bg-white/15 text-white/95 backdrop-blur-xs">
            "Which docs expire soon?"
          </span>
          <span className="shrink-0 px-2.5 py-1 rounded-xl bg-white/15 text-white/95 backdrop-blur-xs">
            "Show Aadhaar cards"
          </span>
          <span className="shrink-0 px-2.5 py-1 rounded-xl bg-white/15 text-white/95 backdrop-blur-xs">
            "Insurance policy status"
          </span>
        </div>
      </div>

      {/* Quick Actions Grid with 3D Glass Surfaces */}
      <section className="space-y-2">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 px-1">
          Quick Actions
        </h3>

        <div className="grid grid-cols-4 gap-2.5">
          {/* 1. 📷 Camera Scan */}
          <button
            onClick={() => onQuickAction('camera')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl glass-card text-center cursor-pointer group active:scale-95"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-500 text-white flex items-center justify-center mb-1.5 shadow-md shadow-cyan-500/20 group-hover:scale-108 transition-transform">
              <Camera className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200">
              Camera
            </span>
          </button>

          {/* 2. 📄 Add Doc */}
          <button
            onClick={() => onQuickAction('upload')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl glass-card text-center cursor-pointer group active:scale-95"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center mb-1.5 shadow-md shadow-blue-500/20 group-hover:scale-108 transition-transform">
              <FilePlus className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200">
              Upload
            </span>
          </button>

          {/* 3. 📝 Add Text Note */}
          <button
            onClick={() => onQuickAction('text')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl glass-card text-center cursor-pointer group active:scale-95"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 text-white flex items-center justify-center mb-1.5 shadow-md shadow-emerald-500/20 group-hover:scale-108 transition-transform">
              <FileText className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-slate-800 dark:text-slate-200">
              Add Note
            </span>
          </button>

          {/* 4. ✨ AI OCR Scan */}
          <button
            onClick={() => onQuickAction('ai-scan')}
            className="flex flex-col items-center justify-center p-3 rounded-2xl glass-card text-center cursor-pointer group active:scale-95"
          >
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-pink-500 text-white flex items-center justify-center mb-1.5 shadow-md shadow-purple-500/20 group-hover:scale-108 transition-transform">
              <Sparkles className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-semibold text-purple-600 dark:text-purple-400">
              AI Scan
            </span>
          </button>
        </div>
      </section>

      {/* Family Members Carousel Section */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-purple-500" />
            <span>Family Profiles ({familyMembers.length})</span>
          </h3>
          <button
            onClick={() => onNavigateToSubView('family')}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline cursor-pointer"
          >
            <span>Manage</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1">
          {familyMembers.length === 0 ? (
            <div
              onClick={() => onNavigateToSubView('family')}
              className="w-full p-4 rounded-3xl glass-card flex items-center justify-between cursor-pointer active:scale-[0.99]"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-purple-500/15 text-purple-600 dark:text-purple-400 flex items-center justify-center text-sm font-bold">
                  +
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                    Add Family Profiles
                  </h4>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Organize documents per person (Spouse, Children, Parents)
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </div>
          ) : (
            <>
              {familyMembers.map((member) => {
                const count = documents.filter(
                  (d) => d.familyMemberId === member.id || d.familyMemberName === member.name
                ).length;
                return (
                  <div
                    key={member.id}
                    onClick={() => onNavigateToSubView('family')}
                    className="shrink-0 p-3 rounded-2xl glass-card flex items-center gap-3 cursor-pointer min-w-[150px] active:scale-95 transition-all"
                  >
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center text-white text-xs font-bold shadow-xs shrink-0"
                      style={{ backgroundColor: member.color || '#4f46e5' }}
                    >
                      {member.name.charAt(0).toUpperCase()}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {member.name}
                      </p>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400">
                        {member.relationship} · {count} {count === 1 ? 'doc' : 'docs'}
                      </p>
                    </div>
                  </div>
                );
              })}
              <button
                onClick={() => onNavigateToSubView('family')}
                className="shrink-0 px-4 py-3 rounded-2xl glass-pill text-xs font-semibold text-purple-600 dark:text-purple-400 hover:bg-white/80 dark:hover:bg-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>+ Add</span>
              </button>
            </>
          )}
        </div>
      </section>

      {/* My Documents Category Folders with 3D Depth */}
      <section className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Document Categories
          </h3>
          <button
            onClick={() => onNavigateToTab('documents')}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline cursor-pointer"
          >
            <span>All ({documents.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {CATEGORIES.map((cat) => {
            const count = categoryCounts[cat.name] || 0;
            const meta = CATEGORY_CONFIG[cat.name] || CATEGORY_CONFIG.Other;

            return (
              <button
                key={cat.name}
                onClick={() => onSelectCategory(cat.name)}
                className={`flex items-center justify-between p-3.5 rounded-2xl glass-card text-left cursor-pointer active:scale-[0.98] transition-all group ${meta.glassBorder}`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-2xl ${meta.iconBg} flex items-center justify-center shrink-0 group-hover:scale-108 transition-transform shadow-xs`}
                  >
                    {cat.icon}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {cat.name}
                    </h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                      {count} {count === 1 ? 'document' : 'documents'}
                    </p>
                  </div>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-400 group-hover:translate-x-0.5 transition-transform shrink-0" />
              </button>
            );
          })}
        </div>
      </section>

      {/* Expiring Soon Section */}
      <section className="space-y-2 pt-1">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Expiring Soon (Within 30 Days)
            </h3>
          </div>
          {expiringDocs.length > 0 && (
            <span className="text-[11px] font-semibold text-amber-600 dark:text-amber-400">
              {expiringDocs.length} pending
            </span>
          )}
        </div>

        {expiringDocs.length === 0 ? (
          <div className="p-4 rounded-3xl glass-card flex items-center gap-3.5">
            <div className="w-9 h-9 rounded-2xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <FileCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                All Documents Up to Date
              </h4>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                No family documents are expiring in the next 30 days.
              </p>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            {expiringDocs.map((doc) => {
              const { label, badgeColor } = getExpiryStatus(doc.expiryDate);
              return (
                <div
                  key={doc.id}
                  className="p-3.5 rounded-2xl glass-card border-amber-500/30 hover:border-amber-500/60 transition-all flex items-center justify-between shadow-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
                      <AlertTriangle className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                        {doc.name}
                      </h4>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                        <span>{doc.familyMemberName}</span>
                        <span>·</span>
                        <span className={`font-semibold px-1.5 py-0.2 rounded-md ${badgeColor}`}>
                          {label}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onViewDocument(doc)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl glass-pill hover:bg-white/80 dark:hover:bg-white/10 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors shrink-0 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* D3.js Vault Analytics & Storage Visualization */}
      <VaultAnalyticsChart
        documents={documents}
        textNotes={textNotes}
        totalStorageBytes={totalStorageBytes}
        onSelectCategory={(cat) => {
          if (cat !== 'Text Notes') {
            onSelectCategory(cat as DocumentCategory);
          } else {
            onNavigateToSubView('text-locker');
          }
        }}
      />

      {/* Secure Text Locker Glass Card */}
      <div
        onClick={() => onNavigateToSubView('text-locker')}
        className="p-4 rounded-3xl glass-card bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-transparent border-emerald-500/30 hover:border-emerald-500/60 flex items-center justify-between cursor-pointer active:scale-[0.99] transition-all group"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-xs">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900 dark:text-white">
              Secure Text Locker
            </h4>
            <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
              {textNotes.length} encrypted notes & emergency records
            </p>
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400 group-hover:translate-x-0.5 transition-transform" />
      </div>
    </div>
  );
};
