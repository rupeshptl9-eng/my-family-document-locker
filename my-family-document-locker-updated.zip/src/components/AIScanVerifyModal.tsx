import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  CheckCircle2,
  X,
  Sparkles,
  User,
  Calendar,
  Building,
  MapPin,
  AlertTriangle,
  Cpu,
  Cloud,
  Loader2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DocumentCategory, FamilyMember, Gender, LockerDocument } from '../types';
import { maskDocumentNumber } from '../utils/documentUtils';

interface AIScanVerifyModalProps {
  isOpen: boolean;
  extractedData: any;
  fileInfo: {
    name: string;
    size: number;
    type: 'pdf' | 'jpg' | 'jpeg' | 'png' | 'webp';
    url: string;
  };
  familyMembers: FamilyMember[];
  onClose: () => void;
  onSaveDocument: (doc: LockerDocument) => Promise<void>;
}

const CATEGORIES: DocumentCategory[] = [
  'Aadhaar',
  'PAN',
  'Passport',
  'Driving Licence',
  'Voter ID',
  'Ration Card',
  'Birth Certificate',
  'Marriage Certificate',
  'Education',
  'Insurance',
  'Bank',
  'Property',
  'Vehicle',
  'Other'
];

export const AIScanVerifyModal: React.FC<AIScanVerifyModalProps> = ({
  isOpen,
  extractedData,
  fileInfo,
  familyMembers,
  onClose,
  onSaveDocument
}) => {
  // 1. ALL HOOKS CALLED UNCONDITIONALLY FIRST (Strict React Rules of Hooks compliance)
  const [docName, setDocName] = useState<string>('');
  const [category, setCategory] = useState<DocumentCategory>('Other');
  const [documentNumber, setDocumentNumber] = useState<string>('');
  const [holderName, setHolderName] = useState<string>('');
  const [dob, setDob] = useState<string>('');
  const [gender, setGender] = useState<Gender>('Unspecified');
  const [address, setAddress] = useState<string>('');
  const [issueDate, setIssueDate] = useState<string>('');
  const [expiryDate, setExpiryDate] = useState<string>('');
  const [issuingAuthority, setIssuingAuthority] = useState<string>('');
  const [familyMemberId, setFamilyMemberId] = useState<string>('self');
  const [notes, setNotes] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  // Re-synchronize and reset state when opening modal or when extractedData changes
  useEffect(() => {
    if (isOpen && extractedData) {
      const cat = (extractedData.docType as DocumentCategory) || 'Other';
      setCategory(cat);
      setDocName(extractedData.docName || `${cat} - Verified`);
      setDocumentNumber(extractedData.documentNumber || '');
      setHolderName(extractedData.holderName || '');
      setDob(extractedData.dob || '');
      setGender(extractedData.gender || 'Unspecified');
      setAddress(extractedData.address || '');
      setIssueDate(extractedData.issueDate || '');
      setExpiryDate(extractedData.expiryDate || '');
      setIssuingAuthority(extractedData.issuingAuthority || '');
      setNotes(extractedData.notes || '');
      setIsSaving(false);
      setSaveError(null);
      setSaveSuccess(false);

      // Associate with family member if name matches
      const matched = familyMembers.find((m) =>
        (extractedData.holderName || '')
          .toLowerCase()
          .includes(m.name.toLowerCase())
      );
      setFamilyMemberId(matched ? matched.id : familyMembers[0]?.id || 'self');
    }
  }, [isOpen, extractedData, familyMembers]);

  // 2. CONDITIONAL RETURN MOVED AFTER ALL HOOKS
  if (!isOpen) return null;

  const isAadhaar = category === 'Aadhaar' || Boolean(extractedData?.isAadhaar);
  const confidenceScore = typeof extractedData?.confidenceScore === 'number'
    ? Math.round(extractedData.confidenceScore)
    : 85;

  const lowConfidenceFields: string[] = Array.isArray(extractedData?.lowConfidenceFields)
    ? extractedData.lowConfidenceFields
    : [];

  const engine = extractedData?.engine || 'ocr';

  // Confidence styling
  const isHighConfidence = confidenceScore >= 90;
  const isMediumConfidence = confidenceScore >= 70 && confidenceScore < 90;
  const isLowConfidence = confidenceScore < 70;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSaving || saveSuccess) return;

    setIsSaving(true);
    setSaveError(null);

    try {
      const selectedMember =
        familyMembers.find((m) => m.id === familyMemberId) ||
        familyMembers[0] || {
          id: 'self',
          name: holderName || 'Self'
        };

      const masked = maskDocumentNumber(documentNumber, category);

      const newDoc: LockerDocument = {
        id: `doc_${Date.now()}`,
        name: docName.trim() || `${category} Document`,
        category,
        familyMemberId: selectedMember.id,
        familyMemberName: selectedMember.name,
        holderName: holderName ? holderName.trim() : undefined,
        documentNumber: documentNumber.trim(),
        maskedNumber: masked,
        dob: dob || undefined,
        gender: gender !== 'Unspecified' ? gender : undefined,
        address: address.trim() || undefined,
        issueDate: issueDate || undefined,
        expiryDate: expiryDate || undefined,
        issuingAuthority: issuingAuthority.trim() || undefined,
        fileType: fileInfo.type,
        fileUrl: fileInfo.url,
        fileName: fileInfo.name,
        fileSize: fileInfo.size,
        uploadDate: new Date().toISOString().slice(0, 10),
        notes: notes.trim(),
        tags: [category.toLowerCase(), 'verified-scan'],
        isAadhaar,
        verifiedByUser: true
      };

      // Await saving to encrypted IndexedDB and Firestore
      await onSaveDocument(newDoc);

      setSaveSuccess(true);

      try {
        confetti({
          particleCount: 70,
          spread: 60,
          origin: { y: 0.6 }
        });
      } catch {
        // Ignored
      }

      // Close modal only after successful save
      setTimeout(() => {
        setIsSaving(false);
        setSaveSuccess(false);
        onClose();
      }, 700);
    } catch (err: any) {
      console.error('Error in onSaveDocument:', err);
      setSaveError(err.message || 'Failed to save document. Please try again.');
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn select-none">
      <div className="w-full max-w-lg max-h-[92vh] bg-white dark:bg-[#1a1b22] rounded-3xl p-6 shadow-2xl border border-slate-200 dark:border-white/10 flex flex-col space-y-3.5">
        {/* Header */}
        <div className="flex items-start justify-between pb-3 border-b border-slate-100 dark:border-white/10">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white leading-tight">
                Verify Extracted Information
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Review and confirm details before saving to your encrypted locker
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* AI Engine & Confidence Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-2xl bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 text-xs">
          {/* Engine indicator */}
          <div className="flex items-center gap-1.5 font-medium">
            {engine === 'cloud' ? (
              <span className="inline-flex items-center gap-1.5 text-blue-600 dark:text-blue-400 font-semibold">
                <Cloud className="w-3.5 h-3.5" />
                Processed using Cloud AI
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-semibold">
                <Cpu className="w-3.5 h-3.5" />
                Processed on device
              </span>
            )}
          </div>

          {/* Confidence Badge */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-slate-500">Overall:</span>
            <span
              className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                isHighConfidence
                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                  : isMediumConfidence
                  ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                  : 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
              }`}
            >
              {confidenceScore}% {isHighConfidence ? 'High confidence' : isMediumConfidence ? 'Medium confidence' : 'Low confidence'}
            </span>
          </div>
        </div>

        {/* Aadhaar / ID Privacy Compliance Notice */}
        <div className="p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 flex items-start gap-2 text-xs">
          <ShieldCheck className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-bold text-[11px] uppercase tracking-wide">
              {isAadhaar ? 'Aadhaar Privacy Notice' : 'Offline Privacy Guarantee'}
            </p>
            <p className="text-[11px] text-amber-800 dark:text-amber-300/90 leading-relaxed">
              Visual extraction only from visible document content. No government or external database was queried.
            </p>
          </div>
        </div>

        {/* Verification Form */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto space-y-3 pr-1 text-xs">
          {/* Document Title */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Document Title *
            </label>
            <input
              type="text"
              required
              value={docName}
              onChange={(e) => setDocName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Category & Family Member */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Category *
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as DocumentCategory)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Family Member
              </label>
              <select
                value={familyMemberId}
                onChange={(e) => setFamilyMemberId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {familyMembers.length === 0 ? (
                  <option value="self">Self (Vault Owner)</option>
                ) : (
                  familyMembers.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name} ({m.relationship})
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>

          {/* Document Number & Holder Name */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Document Number *
                </label>
                {lowConfidenceFields.includes('documentNumber') && (
                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-0.5">
                    <AlertTriangle className="w-3 h-3" /> Please verify
                  </span>
                )}
              </div>
              <input
                type="text"
                required
                value={documentNumber}
                onChange={(e) => setDocumentNumber(e.target.value)}
                placeholder="Enter or verify ID number"
                className={`w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border text-xs text-slate-900 dark:text-white font-mono focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  lowConfidenceFields.includes('documentNumber')
                    ? 'border-amber-400 dark:border-amber-600'
                    : 'border-slate-200 dark:border-white/10'
                }`}
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Masked preview: <strong>{maskDocumentNumber(documentNumber, category)}</strong>
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Holder Full Name
                </label>
                {lowConfidenceFields.includes('holderName') && (
                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-0.5">
                    <AlertTriangle className="w-3 h-3" /> Please verify
                  </span>
                )}
              </div>
              <input
                type="text"
                value={holderName}
                onChange={(e) => setHolderName(e.target.value)}
                placeholder="Name on card"
                className={`w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  lowConfidenceFields.includes('holderName')
                    ? 'border-amber-400 dark:border-amber-600'
                    : 'border-slate-200 dark:border-white/10'
                }`}
              />
            </div>
          </div>

          {/* Date of Birth & Gender */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300">
                  Date of Birth
                </label>
                {lowConfidenceFields.includes('dob') && (
                  <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold">
                    Verify
                  </span>
                )}
              </div>
              <input
                type="date"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                className={`w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  lowConfidenceFields.includes('dob')
                    ? 'border-amber-400 dark:border-amber-600'
                    : 'border-slate-200 dark:border-white/10'
                }`}
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Gender
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as Gender)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Unspecified">Unspecified</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          {/* Address */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Address (if visible)
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Address printed on document"
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Issue Date & Expiry Date */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Issue Date
              </label>
              <input
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Expiry Date
              </label>
              <input
                type="date"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>

          {/* Issuing Authority */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Issuing Authority
            </label>
            <input
              type="text"
              value={issuingAuthority}
              onChange={(e) => setIssuingAuthority(e.target.value)}
              placeholder="e.g. Government of India, RTO, Insurance Provider"
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Notes & Key Details
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Additional information, policy terms, vehicle number..."
              className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/5 border border-slate-200 dark:border-white/10 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
          </div>

          {/* Error Banner */}
          {saveError && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/50 flex items-start gap-2 text-xs text-red-700 dark:text-red-300">
              <AlertTriangle className="w-4 h-4 shrink-0 text-red-500 mt-0.5" />
              <div className="flex-1 leading-relaxed">{saveError}</div>
            </div>
          )}

          {/* Success Banner */}
          {saveSuccess && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/50 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-300">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
              <span className="font-medium">Document securely encrypted and saved to your locker!</span>
            </div>
          )}

          <p className="text-[11px] text-center text-slate-500 dark:text-slate-400 font-medium pt-1">
            Please verify all extracted fields above before saving into your encrypted vault.
          </p>

          {/* Actions */}
          <div className="flex items-center gap-2 pt-1 border-t border-slate-100 dark:border-white/10">
            <button
              type="button"
              disabled={isSaving}
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving || saveSuccess}
              className={`flex-1 py-2.5 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-[0.99] ${
                saveSuccess
                  ? 'bg-emerald-600 hover:bg-emerald-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              } disabled:opacity-75 disabled:cursor-not-allowed`}
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                  <span>Encrypting & Saving...</span>
                </>
              ) : saveSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>Saved to Locker!</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Verify & Save</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
