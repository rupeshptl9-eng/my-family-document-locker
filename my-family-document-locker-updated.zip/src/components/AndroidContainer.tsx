import React, { useState, useEffect } from 'react';
import {
  Wifi,
  Smartphone,
  Maximize2,
  Moon,
  Sun,
  ShieldCheck,
  Signal
} from 'lucide-react';

interface AndroidContainerProps {
  children: React.ReactNode;
  theme: 'light' | 'dark';
  onToggleTheme: () => void;
}

export const AndroidContainer: React.FC<AndroidContainerProps> = ({
  children,
  theme,
  onToggleTheme
}) => {
  const [isPhoneFrame, setIsPhoneFrame] = useState(true);
  const [currentTime, setCurrentTime] = useState('');

  // Update status bar clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-300 flex flex-col items-center justify-center relative overflow-x-hidden ${
        theme === 'dark'
          ? 'bg-[#0b0d14] text-[#e2e8f0]'
          : 'bg-[#edf2f7] text-slate-900'
      }`}
    >
      {/* Ambient background light gradients for glassmorphism reflections */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className={`absolute -top-32 -left-32 w-96 h-96 rounded-full blur-[110px] opacity-40 transition-opacity duration-700 ${
            theme === 'dark' ? 'bg-indigo-600/30' : 'bg-blue-400/30'
          }`}
        />
        <div
          className={`absolute top-1/3 -right-32 w-96 h-96 rounded-full blur-[120px] opacity-35 transition-opacity duration-700 ${
            theme === 'dark' ? 'bg-cyan-500/25' : 'bg-cyan-300/35'
          }`}
        />
        <div
          className={`absolute -bottom-32 left-1/4 w-96 h-96 rounded-full blur-[130px] opacity-30 transition-opacity duration-700 ${
            theme === 'dark' ? 'bg-purple-600/25' : 'bg-purple-300/30'
          }`}
        />
      </div>

      {/* Desktop Controls Bar */}
      <header className="hidden md:flex items-center justify-between w-full max-w-4xl px-4 py-2 z-10 text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-2 font-medium">
          <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-xs">
            <ShieldCheck className="w-3.5 h-3.5" />
          </div>
          <span className="font-semibold text-slate-800 dark:text-slate-200">
            My Family Document Locker
          </span>
          <span className="text-slate-400 dark:text-slate-600">·</span>
          <span className="text-[11px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-600 dark:text-blue-400 font-medium">
            Glass Edition
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Frame Toggle */}
          <button
            onClick={() => setIsPhoneFrame(!isPhoneFrame)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-xl glass-pill hover:bg-white/90 dark:hover:bg-white/10 transition-all cursor-pointer font-medium"
            title="Toggle between phone device mockup and full screen"
          >
            {isPhoneFrame ? (
              <>
                <Maximize2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>Full View</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                <span>Phone Frame</span>
              </>
            )}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-1.5 rounded-xl glass-pill hover:bg-white/90 dark:hover:bg-white/10 transition-all cursor-pointer"
            title="Toggle Light / Dark mode"
          >
            {theme === 'dark' ? (
              <Sun className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Moon className="w-3.5 h-3.5 text-slate-700" />
            )}
          </button>
        </div>
      </header>

      {/* Main Container: Android Phone Frame or Edge-to-Edge with Glassmorphism */}
      <div
        className={`w-full transition-all duration-300 relative z-10 flex flex-col overflow-hidden ${
          isPhoneFrame
            ? 'md:max-w-[430px] md:h-[915px] md:my-2 md:rounded-[46px] md:shadow-2xl md:ring-1 md:ring-white/20 md:border-[7px] md:border-slate-800/90 dark:md:border-slate-800'
            : 'max-w-2xl min-h-screen md:rounded-none'
        } ${
          theme === 'dark'
            ? 'bg-[#0f1118]/90 backdrop-blur-2xl'
            : 'bg-[#f8fafc]/90 backdrop-blur-2xl'
        }`}
        style={{
          boxShadow: isPhoneFrame
            ? theme === 'dark'
              ? '0 30px 80px -15px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(255, 255, 255, 0.1) inset'
              : '0 25px 70px -15px rgba(15, 23, 42, 0.18), 0 0 0 1px rgba(255, 255, 255, 0.8) inset'
            : 'none'
        }}
      >
        {/* Android Native Status Bar */}
        <div
          className={`w-full px-6 pt-3 pb-1 flex items-center justify-between z-30 select-none text-[13px] font-semibold tracking-tight transition-colors ${
            theme === 'dark'
              ? 'text-slate-200 bg-transparent'
              : 'text-slate-800 bg-transparent'
          }`}
        >
          {/* Time display */}
          <span className="font-mono text-xs font-semibold pl-1">
            {currentTime || '10:24'}
          </span>

          {/* Android Punch Hole Camera */}
          <div className="w-3.5 h-3.5 rounded-full bg-black/90 dark:bg-black/90 border border-slate-700/60 shadow-inner flex items-center justify-center">
            <div className="w-1 h-1 rounded-full bg-blue-900/60" />
          </div>

          {/* System Icons: 5G, Wi-Fi, Battery */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-[10px] font-bold tracking-tight">5G</span>
            <Signal className="w-3 h-3" />
            <Wifi className="w-3.5 h-3.5" />
            {/* Battery Indicator */}
            <div className="flex items-center gap-0.5 ml-0.5">
              <span className="text-[10px] font-mono">98%</span>
              <div className="w-4 h-2.5 border border-current rounded-xs p-[1px] flex items-center">
                <div className="w-full h-full bg-current rounded-2xs" />
              </div>
            </div>
          </div>
        </div>

        {/* Inner App Content Screen */}
        <div className="flex-1 flex flex-col relative overflow-y-auto no-scrollbar">
          {children}
        </div>

        {/* Android Bottom Gesture Navigation Pill */}
        <div className="w-full py-2 flex items-center justify-center select-none z-30 bg-transparent">
          <div className="w-32 h-1 rounded-full bg-slate-400/40 dark:bg-slate-600/50 transition-all hover:bg-slate-500" />
        </div>
      </div>
    </div>
  );
};
