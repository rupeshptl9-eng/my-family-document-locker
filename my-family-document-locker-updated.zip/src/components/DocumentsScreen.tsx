import React, { useState } from 'react';
import {
  Search,
  X,
  Filter,
  Eye,
  EyeOff,
  Download,
  Trash2,
  Edit2,
  FileText,
  Plus,
  Shield,
  Star,
  Share2,
  Clock,
  AlertCircle,
  FileUp,
  LayoutGrid,
  List,
  ArrowUpDown,
  CreditCard,
  Globe,
  Car,
  Vote,
  Landmark,
  HeartPulse,
  GraduationCap,
  Building,
  Folder,
  ScrollText
} from 'lucide-react';
import { DocumentCategory, ExpiryStatus, FamilyMember, LockerDocument } from '../types';
import { getExpiryStatus, CATEGORY_CONFIG, formatDate } from '../utils/documentUtils';

interface DocumentsScreenProps {
  documents: LockerDocument[];
  familyMembers: FamilyMember[];
  selectedCategoryFilter?: DocumentCategory | 'All';
  onSelectCategoryFilter: (category: DocumentCategory | 'All') => void;
  onViewDocument: (doc: LockerDocument) => void;
  onEditDocument: (doc: LockerDocument) => void;
  onDeleteDocument: (docId: string) => void;
  onDownloadDocument: (doc: LockerDocument) => void;
  onToggleFavorite: (docId: string) => void;
  onReplaceDocument: (doc: LockerDocument) => void;
  onAddNewDocument: () => void;
}

export const DocumentsScreen: React.FC<DocumentsScreenProps> = ({
  documents,
  familyMembers,
  selectedCategoryFilter = 'All',
  onSelectCategoryFilter,
  onViewDocument,
  onEditDocument,
  onDeleteDocument,
  onDownloadDocument,
  onToggleFavorite,
  onReplaceDocument,
  onAddNewDocument
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamilyFilter, setSelectedFamilyFilter] = useState<string>('All');
  const [selectedExpiryFilter, setSelectedExpiryFilter] = useState<'All' | ExpiryStatus>('All');
  const [activeVaultTab, setActiveVaultTab] = useState<'all' | 'favorites' | 'expiring' | 'recent'>('all');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'name-asc' | 'expiry'>('date-desc');
  const [revealedDocIds, setRevealedDocIds] = useState<Record<string, boolean>>({});
  const [docToDelete, setDocToDelete] = useState<LockerDocument | null>(null);

  // Toggle reveal of masked document number
  const toggleReveal = (docId: string) => {
    setRevealedDocIds((prev) => ({
      ...prev,
      [docId]: !prev[docId]
    }));
  };

  const CATEGORIES: ('All' | DocumentCategory)[] = [
    'All',
    'Aadhaar',
    'PAN',
    'Passport',
    'Driving Licence',
    'Voter ID',
    'Ration Card',
    'Birth Certificate',
    'Marriage Certificate',
    'Education',
    'Insurance',
    'Bank',
    'Property',
    'Vehicle',
    'Other'
  ];

  // Filter documents
  const filteredDocs = documents.filter((doc) => {
    // Vault Section Tab
    if (activeVaultTab === 'favorites' && !doc.isFavorite) return false;
    if (activeVaultTab === 'expiring') {
      const { status } = getExpiryStatus(doc.expiryDate);
      if (status !== 'EXPIRING_SOON' && status !== 'EXPIRED') return false;
    }

    // Search Query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = doc.name.toLowerCase().includes(q);
      const matchCat = doc.category.toLowerCase().includes(q);
      const matchNumber = doc.documentNumber.toLowerCase().includes(q);
      const matchMasked = doc.maskedNumber.toLowerCase().includes(q);
      const matchFamily = doc.familyMemberName.toLowerCase().includes(q);
      const matchNotes = (doc.notes || '').toLowerCase().includes(q);
      const matchTags = (doc.tags || []).some((t) => t.toLowerCase().includes(q));

      if (
        !matchName &&
        !matchCat &&
        !matchNumber &&
        !matchMasked &&
        !matchFamily &&
        !matchNotes &&
        !matchTags
      ) {
        return false;
      }
    }

    // Category Filter
    if (selectedCategoryFilter !== 'All' && doc.category !== selectedCategoryFilter) {
      return false;
    }

    // Family Member Filter
    if (selectedFamilyFilter !== 'All' && doc.familyMemberId !== selectedFamilyFilter) {
      return false;
    }

    // Expiry Status Filter
    if (selectedExpiryFilter !== 'All') {
      const { status } = getExpiryStatus(doc.expiryDate);
      if (status !== selectedExpiryFilter) return false;
    }

    return true;
  });

  // Sort documents
  const sortedDocs = [...filteredDocs].sort((a, b) => {
    if (activeVaultTab === 'recent' || sortBy === 'date-desc') {
      return new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime();
    }
    if (sortBy === 'date-asc') {
      return new Date(a.uploadDate).getTime() - new Date(b.uploadDate).getTime();
    }
    if (sortBy === 'name-asc') {
      return a.name.localeCompare(b.name);
    }
    if (sortBy === 'expiry') {
      if (!a.expiryDate) return 1;
      if (!b.expiryDate) return -1;
      return new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime();
    }
    return 0;
  });

  const handleShare = async (doc: LockerDocument) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: doc.name,
          text: `${doc.name} (${doc.category}) - ${doc.maskedNumber}`
        });
      } catch {
        // Ignored
      }
    } else {
      navigator.clipboard.writeText(`${doc.name} (${doc.category}) - ${doc.maskedNumber}`);
      alert('Document info copied to clipboard');
    }
  };

  return (
    <div className="flex-1 pb-24 px-4 pt-3 select-none space-y-3.5 animate-fadeIn">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <span>Document Vault</span>
            <span className="text-xs px-2 py-0.5 rounded-full bg-blue-500/15 text-blue-600 dark:text-blue-400 font-semibold font-mono">
              {documents.length}
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Encrypted with AES-256-GCM on-device
          </p>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Grid / List Switcher */}
          <div className="flex items-center p-0.5 rounded-xl glass-pill">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-1.5 rounded-lg transition-all cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
              title="List View"
            >
              <List className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            onClick={onAddNewDocument}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white text-xs font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all active:scale-95 shadow-md shadow-blue-500/25 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>
      </div>

      {/* Vault Sections Filter Tabs */}
      <div className="flex items-center gap-1 p-1 glass-surface rounded-2xl text-xs overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveVaultTab('all')}
          className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer ${
            activeVaultTab === 'all'
              ? 'bg-white dark:bg-white/10 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          All ({documents.length})
        </button>
        <button
          onClick={() => setActiveVaultTab('favorites')}
          className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1 transition-all cursor-pointer ${
            activeVaultTab === 'favorites'
              ? 'bg-white dark:bg-white/10 text-amber-500 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <Star className="w-3.5 h-3.5 fill-amber-400" />
          <span>Favorites</span>
        </button>
        <button
          onClick={() => setActiveVaultTab('expiring')}
          className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1 transition-all cursor-pointer ${
            activeVaultTab === 'expiring'
              ? 'bg-white dark:bg-white/10 text-rose-500 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Expiring</span>
        </button>
        <button
          onClick={() => setActiveVaultTab('recent')}
          className={`px-3 py-1.5 rounded-xl font-semibold transition-all cursor-pointer ${
            activeVaultTab === 'recent'
              ? 'bg-white dark:bg-white/10 text-blue-600 dark:text-blue-400 shadow-xs'
              : 'text-slate-500 hover:text-slate-900 dark:text-slate-400'
          }`}
        >
          Recent
        </button>
      </div>

      {/* Search & Sort Controls */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search documents by title, number, or family..."
            className="w-full h-10 pl-10 pr-9 rounded-2xl glass-surface text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50 shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Sort Dropdown */}
        <div className="relative shrink-0">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="h-10 px-2.5 rounded-2xl glass-pill text-[11px] font-semibold text-slate-700 dark:text-slate-300 focus:outline-none cursor-pointer"
          >
            <option value="date-desc">Newest First</option>
            <option value="date-asc">Oldest First</option>
            <option value="name-asc">Name (A-Z)</option>
            <option value="expiry">Expiry Date</option>
          </select>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategoryFilter === cat;
          return (
            <button
              key={cat}
              onClick={() => onSelectCategoryFilter(cat)}
              className={`shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                isSelected
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                  : 'glass-pill text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Family Member & Expiry Dropdowns */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar text-xs pb-0.5">
        <span className="text-[11px] font-medium text-slate-400 flex items-center gap-1 shrink-0">
          <Filter className="w-3 h-3" />
        </span>

        <select
          value={selectedFamilyFilter}
          onChange={(e) => setSelectedFamilyFilter(e.target.value)}
          className="px-2.5 py-1 rounded-xl glass-pill text-slate-700 dark:text-slate-300 text-xs focus:outline-none shrink-0 cursor-pointer"
        >
          <option value="All">All Family Members</option>
          {familyMembers.map((m) => (
            <option key={m.id} value={m.id}>
              {m.name} ({m.relationship})
            </option>
          ))}
        </select>

        <select
          value={selectedExpiryFilter}
          onChange={(e) => setSelectedExpiryFilter(e.target.value as any)}
          className="px-2.5 py-1 rounded-xl glass-pill text-slate-700 dark:text-slate-300 text-xs focus:outline-none shrink-0 cursor-pointer"
        >
          <option value="All">All Expiry Statuses</option>
          <option value="VALID">🟢 Valid</option>
          <option value="EXPIRING_SOON">🟡 Expiring Soon (30d)</option>
          <option value="EXPIRED">🔴 Expired</option>
        </select>
      </div>

      {/* Document Cards */}
      {sortedDocs.length === 0 ? (
        documents.length > 0 ? (
          /* Filter Mismatch State */
          <div className="p-8 rounded-3xl glass-card text-center space-y-3 mt-4">
            <div className="w-14 h-14 rounded-2xl bg-amber-500/10 text-amber-500 mx-auto flex items-center justify-center">
              <Filter className="w-7 h-7" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                No matching documents
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                You have {documents.length} document{documents.length > 1 ? 's' : ''} in your vault, but none match the current filters.
              </p>
            </div>
            <button
              onClick={() => {
                onSelectCategoryFilter('All');
                setSelectedFamilyFilter('All');
                setSelectedExpiryFilter('All');
                setActiveVaultTab('all');
                setSearchQuery('');
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold shadow-xs hover:bg-blue-700 transition-all cursor-pointer"
            >
              <span>Reset All Filters</span>
            </button>
          </div>
        ) : (
          /* Vault Empty State */
          <div className="p-8 rounded-3xl glass-card text-center space-y-3 mt-4">
            <div className="w-14 h-14 rounded-2xl bg-blue-500/10 text-blue-500 mx-auto flex items-center justify-center">
              <FileText className="w-7 h-7" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                No documents found
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-xs mx-auto">
                {searchQuery
                  ? `No documents matching "${searchQuery}". Try clearing search or filters.`
                  : "Add your family's Aadhaar, PAN, Passport, or Insurance policies."}
              </p>
            </div>
            <button
              onClick={onAddNewDocument}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-xs font-semibold shadow-xs hover:scale-105 active:scale-95 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add First Document</span>
            </button>
          </div>
        )
      ) : viewMode === 'grid' ? (
        /* GRID VIEW */
        <div className="grid grid-cols-2 gap-2.5">
          {sortedDocs.map((doc) => {
            const { label, badgeColor } = getExpiryStatus(doc.expiryDate);
            const isRevealed = Boolean(revealedDocIds[doc.id]);
            const displayNumber = isRevealed ? doc.documentNumber : doc.maskedNumber;
            const meta = CATEGORY_CONFIG[doc.category] || CATEGORY_CONFIG.Other;
            const isPdf = doc.fileType === 'pdf' || (doc.fileName && doc.fileName.toLowerCase().endsWith('.pdf'));

            return (
              <div
                key={doc.id}
                className={`p-3 rounded-2xl glass-card flex flex-col justify-between space-y-2 relative group overflow-hidden ${meta.glassBorder}`}
              >
                {/* Card Top: Thumbnail / Category Badge */}
                <div className="space-y-2">
                  <div
                    onClick={() => onViewDocument(doc)}
                    className="w-full h-24 rounded-xl overflow-hidden bg-slate-100 dark:bg-white/5 relative cursor-pointer"
                  >
                    {isPdf ? (
                      <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-rose-500/15 via-red-500/10 to-amber-500/5 p-2">
                        <FileText className="w-8 h-8 text-rose-500 mb-1 group-hover:scale-110 transition-transform" />
                        <span className="text-[9px] font-bold text-rose-600 dark:text-rose-400 font-mono tracking-wider">PDF DOCUMENT</span>
                      </div>
                    ) : (
                      <>
                        <img
                          src={doc.fileUrl}
                          alt={doc.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          onError={(e) => {
                            e.currentTarget.style.display = 'none';
                            const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                            if (fallback) fallback.style.display = 'flex';
                          }}
                        />
                        <div style={{ display: 'none' }} className="w-full h-full flex flex-col items-center justify-center bg-slate-100 dark:bg-white/5">
                          <FileText className="w-8 h-8 text-slate-400" />
                        </div>
                      </>
                    )}
                    <div className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded-md bg-black/60 backdrop-blur-xs text-[9px] font-bold text-white uppercase font-mono">
                      {doc.fileType}
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(doc.id);
                      }}
                      className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/40 backdrop-blur-xs text-white hover:text-amber-400 cursor-pointer"
                    >
                      <Star className={`w-3.5 h-3.5 ${doc.isFavorite ? 'text-amber-400 fill-amber-400' : ''}`} />
                    </button>
                  </div>

                  <div>
                    <h4
                      onClick={() => onViewDocument(doc)}
                      className="text-xs font-bold text-slate-900 dark:text-white truncate cursor-pointer hover:text-blue-500"
                      title={doc.name}
                    >
                      {doc.name}
                    </h4>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                      {doc.category} · {doc.familyMemberName}
                    </p>
                  </div>
                </div>

                {/* ID Number & Reveal */}
                <div className="space-y-1.5 pt-1 border-t border-slate-100 dark:border-white/5">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200 truncate">
                      {displayNumber}
                    </span>
                    <button
                      onClick={() => toggleReveal(doc.id)}
                      className="p-0.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 cursor-pointer"
                    >
                      {isRevealed ? <EyeOff className="w-3 h-3 text-blue-500" /> : <Eye className="w-3 h-3" />}
                    </button>
                  </div>

                  {/* Expiry Pill */}
                  <div className="flex items-center justify-between">
                    <span className={`text-[9px] font-semibold px-1.5 py-0.2 rounded-md truncate ${badgeColor}`}>
                      {label}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono">
                      {formatDate(doc.uploadDate).slice(0, 6)}
                    </span>
                  </div>

                  {/* Card Quick Action Bar */}
                  <div className="flex items-center justify-between pt-1">
                    <button
                      onClick={() => onViewDocument(doc)}
                      className="flex-1 py-1 rounded-lg bg-blue-500/10 hover:bg-blue-500/20 text-blue-600 dark:text-blue-400 text-[10px] font-semibold flex items-center justify-center gap-1 transition-colors cursor-pointer mr-1"
                    >
                      <Eye className="w-3 h-3" />
                      <span>View</span>
                    </button>
                    <button
                      onClick={() => onEditDocument(doc)}
                      className="p-1 rounded-lg glass-pill hover:bg-white/80 dark:hover:bg-white/10 text-slate-500 text-[10px] cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => setDocToDelete(doc)}
                      className="p-1 rounded-lg glass-pill hover:text-rose-500 text-slate-400 text-[10px] cursor-pointer ml-1"
                      title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* LIST VIEW */
        <div className="space-y-2.5">
          {sortedDocs.map((doc) => {
            const { label, badgeColor } = getExpiryStatus(doc.expiryDate);
            const isRevealed = Boolean(revealedDocIds[doc.id]);
            const displayNumber = isRevealed ? doc.documentNumber : doc.maskedNumber;
            const meta = CATEGORY_CONFIG[doc.category] || CATEGORY_CONFIG.Other;

            return (
              <div
                key={doc.id}
                className={`p-3 rounded-2xl glass-card flex items-center justify-between gap-3 ${meta.glassBorder}`}
              >
                {(() => {
                  const isPdf = doc.fileType === 'pdf' || (doc.fileName && doc.fileName.toLowerCase().endsWith('.pdf'));
                  return (
                    <div
                      onClick={() => onViewDocument(doc)}
                      className="w-12 h-12 rounded-xl overflow-hidden bg-slate-100 dark:bg-white/5 relative shrink-0 cursor-pointer"
                    >
                      {isPdf ? (
                        <div className="w-full h-full flex items-center justify-center bg-rose-500/15 text-rose-500">
                          <FileText className="w-6 h-6" />
                        </div>
                      ) : (
                        <>
                          <img
                            src={doc.fileUrl}
                            alt={doc.name}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              const fallback = e.currentTarget.nextElementSibling as HTMLElement;
                              if (fallback) fallback.style.display = 'flex';
                            }}
                          />
                          <div style={{ display: 'none' }} className="w-full h-full flex items-center justify-center bg-slate-100 dark:bg-white/5 text-slate-400">
                            <FileText className="w-6 h-6" />
                          </div>
                        </>
                      )}
                      <div className="absolute bottom-0 right-0 px-1 py-0.2 rounded-tl-sm bg-black/70 text-[8px] font-bold text-white uppercase font-mono">
                        {doc.fileType}
                      </div>
                    </div>
                  );
                })()}

                <div className="flex-1 min-w-0" onClick={() => onViewDocument(doc)}>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate cursor-pointer hover:text-blue-500">
                      {doc.name}
                    </h4>
                    {doc.isFavorite && (
                      <Star className="w-3 h-3 text-amber-500 fill-amber-500 shrink-0" />
                    )}
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                    {doc.category} · {doc.familyMemberName} · {displayNumber}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`text-[9px] font-semibold px-1.5 py-0.2 rounded-md ${badgeColor}`}>
                      {label}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono">
                      {doc.uploadDate}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => onViewDocument(doc)}
                    className="p-2 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 hover:bg-blue-500/20 transition-colors cursor-pointer"
                    title="View"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onEditDocument(doc)}
                    className="p-2 rounded-xl glass-pill text-slate-500 hover:text-slate-900 dark:hover:text-white transition-colors cursor-pointer"
                    title="Edit"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setDocToDelete(doc)}
                    className="p-2 rounded-xl glass-pill text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {docToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-xs glass-modal rounded-3xl p-5 shadow-2xl space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-rose-100 dark:bg-rose-950/70 text-rose-600 mx-auto flex items-center justify-center">
              <AlertCircle className="w-5 h-5" />
            </div>

            <div className="text-center">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Delete Document Permanently?
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Are you sure you want to delete <strong>{docToDelete.name}</strong>? This will remove the encrypted file from your vault.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={() => setDocToDelete(null)}
                className="flex-1 py-2 rounded-xl glass-pill text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteDocument(docToDelete.id);
                  setDocToDelete(null);
                }}
                className="flex-1 py-2 rounded-xl bg-rose-600 text-xs font-semibold text-white hover:bg-rose-700 transition-colors cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
