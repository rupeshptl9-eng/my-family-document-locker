import React from 'react';
import { Home, FolderClosed, Users, Sparkles, Settings, Plus } from 'lucide-react';

export type NavTab = 'home' | 'documents' | 'family' | 'ai' | 'profile';

interface BottomNavigationProps {
  currentTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  onOpenAddSheet: () => void;
}

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  currentTab,
  onTabChange,
  onOpenAddSheet
}) => {
  return (
    <nav
      aria-label="Bottom Navigation"
      className="w-full glass-surface border-t border-white/60 dark:border-white/10 px-2 pt-1.5 pb-2.5 flex items-center justify-around z-20 select-none transition-colors"
    >
      {/* 1. Home */}
      <button
        onClick={() => onTabChange('home')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-2xl transition-all duration-200 ${
            currentTab === 'home'
              ? 'bg-gradient-to-r from-blue-600/15 to-indigo-600/15 text-blue-600 dark:text-blue-400 font-semibold shadow-xs'
              : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <Home className={`w-5 h-5 transition-transform ${currentTab === 'home' ? 'scale-110' : ''}`} />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'home'
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-400 dark:text-slate-500 font-medium'
          }`}
        >
          Home
        </span>
      </button>

      {/* 2. Documents */}
      <button
        onClick={() => onTabChange('documents')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-2xl transition-all duration-200 ${
            currentTab === 'documents'
              ? 'bg-gradient-to-r from-blue-600/15 to-indigo-600/15 text-blue-600 dark:text-blue-400 font-semibold shadow-xs'
              : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <FolderClosed className={`w-5 h-5 transition-transform ${currentTab === 'documents' ? 'scale-110' : ''}`} />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'documents'
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-400 dark:text-slate-500 font-medium'
          }`}
        >
          Folders
        </span>
      </button>

      {/* Center Elevated Floating Add Button with Glassmorphism Ring */}
      <div className="flex flex-col items-center justify-center -mt-7 px-1">
        <button
          onClick={onOpenAddSheet}
          aria-label="Add Document"
          className="relative w-13 h-13 rounded-2xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 text-white shadow-xl shadow-indigo-500/35 flex items-center justify-center cursor-pointer transition-all duration-200 hover:scale-108 active:scale-90 ring-4 ring-white/80 dark:ring-[#0f1118] group"
          title="Add Document or Note"
        >
          <div className="absolute inset-0 rounded-2xl bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />
          <Plus className="w-6 h-6 stroke-[2.5] group-hover:rotate-90 transition-transform duration-200" />
        </button>
        <span className="text-[10px] mt-0.5 font-bold text-slate-700 dark:text-slate-300">
          Add
        </span>
      </div>

      {/* 3. Family */}
      <button
        onClick={() => onTabChange('family')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-2xl transition-all duration-200 ${
            currentTab === 'family'
              ? 'bg-gradient-to-r from-purple-600/15 to-pink-600/15 text-purple-600 dark:text-purple-400 font-semibold shadow-xs'
              : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <Users className={`w-5 h-5 transition-transform ${currentTab === 'family' ? 'scale-110' : ''}`} />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'family'
              ? 'text-purple-600 dark:text-purple-400 font-bold'
              : 'text-slate-400 dark:text-slate-500 font-medium'
          }`}
        >
          Family
        </span>
      </button>

      {/* 4. AI Assistant */}
      <button
        onClick={() => onTabChange('ai')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-2xl transition-all duration-200 ${
            currentTab === 'ai'
              ? 'bg-gradient-to-r from-violet-600/20 to-cyan-500/20 text-indigo-600 dark:text-indigo-400 font-semibold shadow-xs'
              : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <Sparkles className={`w-5 h-5 transition-transform ${currentTab === 'ai' ? 'scale-110' : ''}`} />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'ai'
              ? 'text-indigo-600 dark:text-indigo-400 font-bold'
              : 'text-slate-400 dark:text-slate-500 font-medium'
          }`}
        >
          AI Vault
        </span>
      </button>

      {/* 5. Settings / Profile */}
      <button
        onClick={() => onTabChange('profile')}
        className="flex flex-col items-center justify-center flex-1 py-1 cursor-pointer transition-transform active:scale-95 group"
      >
        <div
          className={`px-3 py-1 rounded-2xl transition-all duration-200 ${
            currentTab === 'profile'
              ? 'bg-gradient-to-r from-blue-600/15 to-indigo-600/15 text-blue-600 dark:text-blue-400 font-semibold shadow-xs'
              : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
          }`}
        >
          <Settings className={`w-5 h-5 transition-transform ${currentTab === 'profile' ? 'scale-110' : ''}`} />
        </div>
        <span
          className={`text-[10px] mt-0.5 tracking-tight ${
            currentTab === 'profile'
              ? 'text-blue-600 dark:text-blue-400 font-bold'
              : 'text-slate-400 dark:text-slate-500 font-medium'
          }`}
        >
          Settings
        </span>
      </button>
    </nav>
  );
};
