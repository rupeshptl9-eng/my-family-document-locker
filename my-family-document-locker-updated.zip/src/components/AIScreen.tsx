import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Send,
  ShieldCheck,
  Bot,
  Cpu,
  Cloud,
  FileText
} from 'lucide-react';
import { FamilyMember, LockerDocument, TextNote } from '../types';
import { aiRouter, AIStatusInfo } from '../services/aiRouter';

interface AIScreenProps {
  documents: LockerDocument[];
  familyMembers: FamilyMember[];
  textNotes: TextNote[];
  onViewDocumentById?: (docId: string) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  engine?: 'local' | 'rules' | 'cloud';
  matchedDocs?: LockerDocument[];
}

export const AIScreen: React.FC<AIScreenProps> = ({
  documents,
  familyMembers,
  textNotes,
  onViewDocumentById
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Hello! I am your Family Document Locker Assistant. ✨\n\nI can help you offline:\n• "Which documents expire this month?"\n• "Show Aadhaar documents"\n• "Show Kavya documents"\n• "Which insurance documents are expiring?"\n• "Show passport documents"\n\nHow can I help you today?`,
      timestamp: 'Just now',
      engine: 'local'
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [aiStatus, setAiStatus] = useState<AIStatusInfo | null>(null);

  useEffect(() => {
    const unsub = aiRouter.subscribe((status) => {
      setAiStatus(status);
    });
    return unsub;
  }, []);

  const firstMember = familyMembers[0]?.name || 'Kavya';
  const secondMember = familyMembers[1]?.name || 'Bhavik';

  const SUGGESTED_PROMPTS = [
    `Show ${firstMember} documents`,
    'Which documents expire this month?',
    'Show Aadhaar documents',
    `Which documents belong to ${secondMember}?`,
    'Which insurance documents are expiring?',
    'Show passport documents',
    'Summarize my vault'
  ];

  const handleSendMessage = async (queryText?: string) => {
    const q = (queryText || inputQuery).trim();
    if (!q || isLoading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text: q,
      timestamp: 'Just now'
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const result = await aiRouter.askQuestion(
        q,
        documents,
        familyMembers,
        textNotes
      );

      const aiMsg: ChatMessage = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: result.reply,
        timestamp: 'Just now',
        engine: result.engine,
        matchedDocs: result.matchedDocuments
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      console.warn('AI Assistant query error:', err);
      const errorMsg: ChatMessage = {
        id: `ai_${Date.now()}`,
        sender: 'ai',
        text: `Looking locally at your vault (${documents.length} docs, ${textNotes.length} notes), your encrypted documents are safe on this device.`,
        timestamp: 'Just now',
        engine: 'rules'
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col justify-between pb-20 px-4 pt-3 select-none animate-fadeIn">
      {/* Header */}
      <div className="pb-3 border-b border-slate-200/80 dark:border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white flex items-center justify-center shadow-md shadow-purple-500/25">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white leading-tight flex items-center gap-2">
                <span>Family Document Assistant</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Offline-first private document intelligence
              </p>
            </div>
          </div>

          {/* Status Badge */}
          {aiStatus && (
            <span
              className={`text-[11px] font-semibold px-2.5 py-1 rounded-full border flex items-center gap-1.5 ${
                aiStatus.badgeColor === 'emerald'
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                  : aiStatus.badgeColor === 'blue'
                  ? 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                  : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${aiStatus.badgeColor === 'emerald' ? 'bg-emerald-500' : 'bg-blue-500'}`} />
              <span>{aiStatus.badgeText}</span>
            </span>
          )}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto no-scrollbar py-4 space-y-3.5 pr-0.5">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex items-start gap-2.5 ${
              msg.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {msg.sender === 'ai' && (
              <div className="w-7 h-7 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed space-y-2 ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-br-xs shadow-md shadow-blue-500/20'
                  : 'glass-card text-slate-800 dark:text-slate-200 rounded-bl-xs shadow-xs'
              }`}
            >
              <p className="whitespace-pre-line select-text font-normal">{msg.text}</p>

              {/* Engine badge on AI reply */}
              {msg.sender === 'ai' && msg.engine && (
                <div className="pt-1 border-t border-slate-200/60 dark:border-white/5 flex items-center gap-1 text-[10px] text-slate-400">
                  {msg.engine === 'cloud' ? (
                    <span className="flex items-center gap-1 text-blue-500 font-medium">
                      <Cloud className="w-3 h-3" /> Processed using Cloud AI
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
                      <Cpu className="w-3 h-3" /> Processed on device
                    </span>
                  )}
                </div>
              )}

              {/* Matched Document Links */}
              {msg.matchedDocs && msg.matchedDocs.length > 0 && onViewDocumentById && (
                <div className="pt-1 space-y-1">
                  {msg.matchedDocs.map((doc) => (
                    <button
                      key={doc.id}
                      type="button"
                      onClick={() => onViewDocumentById(doc.id)}
                      className="w-full text-left p-2 rounded-xl bg-slate-100/80 dark:bg-white/10 hover:bg-slate-200/80 dark:hover:bg-white/15 flex items-center justify-between text-[11px] font-semibold text-blue-600 dark:text-blue-400 transition-colors"
                    >
                      <span className="flex items-center gap-1 truncate">
                        <FileText className="w-3.5 h-3.5" />
                        {doc.name}
                      </span>
                      <span className="text-[10px] text-slate-400">View</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-xl bg-purple-600 text-white flex items-center justify-center shrink-0 animate-pulse">
              <Bot className="w-4 h-4" />
            </div>
            <div className="glass-card rounded-2xl px-4 py-2.5 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-purple-500 animate-ping" />
              <span>Analyzing locker documents offline...</span>
            </div>
          </div>
        )}
      </div>

      {/* Suggested Prompt Chips */}
      <div className="py-2 overflow-x-auto no-scrollbar flex items-center gap-1.5 shrink-0">
        {SUGGESTED_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            disabled={isLoading}
            onClick={() => handleSendMessage(prompt)}
            className="shrink-0 text-[11px] px-3 py-1.5 rounded-xl glass-card text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:border-purple-400/50 transition-all cursor-pointer"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div className="pt-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="relative flex items-center"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Ask about documents, expiry, or notes..."
            className="w-full h-12 pl-4 pr-12 rounded-2xl glass-card text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-500/50 shadow-xs"
          />
          <button
            type="submit"
            disabled={!inputQuery.trim() || isLoading}
            className="absolute right-2 p-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:shadow-md disabled:opacity-40 text-white transition-all cursor-pointer shadow-xs active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <p className="text-center text-[10px] text-slate-400 dark:text-slate-500 pt-2 flex items-center justify-center gap-1">
          <ShieldCheck className="w-3 h-3 text-emerald-500" />
          <span>Private & encrypted. No government or external databases queried.</span>
        </p>
      </div>
    </div>
  );
};
