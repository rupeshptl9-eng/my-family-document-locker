/**
 * Encrypted IndexedDB Vault Storage
 * Stores all sensitive documents, notes, and family records encrypted with AES-256-GCM.
 * Zero plaintext storage in localStorage.
 */

import {
  encryptWithVaultKey,
  decryptWithVaultKey,
  vaultKeyManager,
  deriveVaultKeyFromPin,
  computePinVerifier,
  generateRandomSalt,
  bufferToHex,
  hexToBuffer
} from './vaultKeyManager';

const DB_NAME = 'FamilyDocumentLockerVaultDB_v2';
const DB_VERSION = 2;

const STORES = {
  RECORDS: 'encrypted_records',
  SYNC_QUEUE: 'sync_queue',
  SECURITY: 'vault_security'
};

export interface VaultSecurityConfig {
  saltHex: string;
  verifierHex: string;
  pinLength: number;
  biometricEnabled: boolean;
  autoLockMinutes: number;
  createdAt: string;
  biometricEnvelope?: {
    iv: string;
    ciphertext: string;
  };
}

export interface SyncQueueItem {
  id: string;
  action: 'create' | 'update' | 'delete';
  entityType: 'document' | 'family' | 'note';
  payload: any;
  timestamp: number;
  retryCount: number;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB is not supported on this platform'));
      return;
    }

    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORES.RECORDS)) {
        db.createObjectStore(STORES.RECORDS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORES.SYNC_QUEUE)) {
        db.createObjectStore(STORES.SYNC_QUEUE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORES.SECURITY)) {
        db.createObjectStore(STORES.SECURITY, { keyPath: 'key' });
      }
    };

    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error || new Error('Failed to open IndexedDB'));
  });
}

export const encryptedIndexedDBService = {
  /**
   * Save or update vault security configuration (salt + verifier)
   */
  async saveVaultSecurityConfig(config: VaultSecurityConfig): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.SECURITY, 'readwrite');
      const store = tx.objectStore(STORES.SECURITY);
      const req = store.put({ key: 'vault_security', ...config });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  /**
   * Get vault security configuration
   */
  async getVaultSecurityConfig(): Promise<VaultSecurityConfig | null> {
    try {
      const db = await openDB();
      return new Promise((resolve, reject) => {
        const tx = db.transaction(STORES.SECURITY, 'readonly');
        const store = tx.objectStore(STORES.SECURITY);
        const req = store.get('vault_security');
        req.onsuccess = () => {
          if (!req.result) {
            resolve(null);
            return;
          }
          const { key, ...rest } = req.result;
          resolve(rest as VaultSecurityConfig);
        };
        req.onerror = () => reject(req.error);
      });
    } catch {
      return null;
    }
  },

  /**
   * Check if a vault credential/PIN is configured
   */
  async hasVaultPinConfigured(): Promise<boolean> {
    const config = await this.getVaultSecurityConfig();
    return Boolean(config && config.verifierHex && config.saltHex);
  },

  /**
   * Setup a new vault PIN
   */
  async setupVaultPin(pin: string, autoLockMinutes: number = 5): Promise<void> {
    if (!/^\d{4,6}$/.test(pin)) {
      throw new Error('PIN must be 4 to 6 numeric digits');
    }

    const salt = generateRandomSalt();
    const verifierHex = await computePinVerifier(pin, salt);
    const key = await deriveVaultKeyFromPin(pin, salt);

    const config: VaultSecurityConfig = {
      saltHex: bufferToHex(salt),
      verifierHex,
      pinLength: pin.length,
      biometricEnabled: false,
      autoLockMinutes,
      createdAt: new Date().toISOString()
    };

    await this.saveVaultSecurityConfig(config);
    vaultKeyManager.setVaultKey(key, salt);
    // Also save biometric envelope for quick biometric unlocks
    await this.saveBiometricEnvelope(pin, config);
  },

  /**
   * Save biometric envelope encrypting PIN with a device-bound key
   */
  async saveBiometricEnvelope(pin: string, existingConfig?: VaultSecurityConfig): Promise<void> {
    try {
      const config = existingConfig || await this.getVaultSecurityConfig();
      if (!config) return;

      const enc = new TextEncoder();
      const deviceMaterial = await crypto.subtle.importKey(
        'raw',
        enc.encode(`mfd_biometric_device_${config.saltHex}`),
        'PBKDF2',
        false,
        ['deriveKey']
      );

      const deviceKey = await crypto.subtle.deriveKey(
        {
          name: 'PBKDF2',
          salt: hexToBuffer(config.saltHex) as BufferSource,
          iterations: 50000,
          hash: 'SHA-256'
        },
        deviceMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
      );

      const iv = crypto.getRandomValues(new Uint8Array(12));
      const ciphertext = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv },
        deviceKey,
        enc.encode(pin)
      );

      config.biometricEnvelope = {
        iv: bufferToHex(iv),
        ciphertext: bufferToHex(ciphertext)
      };

      await this.saveVaultSecurityConfig(config);
    } catch (err) {
      console.warn('Could not save biometric envelope:', err);
    }
  },

  /**
   * Unlock vault with biometric envelope
   */
  async unlockWithBiometricKey(): Promise<boolean> {
    try {
      const config = await this.getVaultSecurityConfig();
      if (!config || !config.biometricEnvelope) {
        return false;
      }

      const enc = new TextEncoder();
      const deviceMaterial = await crypto.subtle.importKey(
        'raw',
        enc.encode(`mfd_biometric_device_${config.saltHex}`),
        'PBKDF2',
        false,
        ['deriveKey']
      );

      const deviceKey = await crypto.subtle.deriveKey(
        {
          name: 'PBKDF2',
          salt: hexToBuffer(config.saltHex) as BufferSource,
          iterations: 50000,
          hash: 'SHA-256'
        },
        deviceMaterial,
        { name: 'AES-GCM', length: 256 },
        false,
        ['encrypt', 'decrypt']
      );

      const iv = hexToBuffer(config.biometricEnvelope.iv);
      const ciphertext = hexToBuffer(config.biometricEnvelope.ciphertext);

      const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv as BufferSource },
        deviceKey,
        ciphertext as BufferSource
      );

      const dec = new TextDecoder();
      const pin = dec.decode(decrypted);

      const salt = hexToBuffer(config.saltHex);
      const key = await deriveVaultKeyFromPin(pin, salt);
      vaultKeyManager.setVaultKey(key, salt);
      return true;
    } catch (err) {
      console.warn('Unlock with biometric key failed:', err);
      return false;
    }
  },

  /**
   * Unlock vault with entered PIN
   */
  async unlockWithPin(pin: string): Promise<boolean> {
    const config = await this.getVaultSecurityConfig();
    if (!config) {
      return true;
    }

    const salt = hexToBuffer(config.saltHex);
    const verifierHex = await computePinVerifier(pin, salt);

    if (verifierHex === config.verifierHex) {
      const key = await deriveVaultKeyFromPin(pin, salt);
      vaultKeyManager.setVaultKey(key, salt);
      // Refresh biometric envelope with active PIN
      if (config.biometricEnabled) {
        await this.saveBiometricEnvelope(pin, config);
      }
      return true;
    }

    return false;
  },

  /**
   * Put encrypted record in IndexedDB
   */
  async putEncryptedItem<T>(id: string, type: 'document' | 'family' | 'note' | 'notification', data: T): Promise<void> {
    if (!vaultKeyManager.isUnlocked()) {
      await vaultKeyManager.ensureUnlocked();
    }

    const encryptedData = await encryptWithVaultKey(data);
    const db = await openDB();

    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.RECORDS, 'readwrite');
      const store = tx.objectStore(STORES.RECORDS);
      const record = {
        id,
        type,
        encryptedData,
        updatedAt: new Date().toISOString()
      };
      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  /**
   * Get and decrypt record from IndexedDB
   */
  async getDecryptedItem<T>(id: string): Promise<T | null> {
    if (!vaultKeyManager.isUnlocked()) {
      await vaultKeyManager.ensureUnlocked();
    }

    const db = await openDB();
    const encryptedRecord = await new Promise<{ encryptedData: string } | null>((resolve, reject) => {
      const tx = db.transaction(STORES.RECORDS, 'readonly');
      const store = tx.objectStore(STORES.RECORDS);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });

    if (!encryptedRecord) return null;
    return await decryptWithVaultKey<T>(encryptedRecord.encryptedData);
  },

  /**
   * Get and decrypt all items of a specific type
   */
  async getDecryptedItemsByType<T>(type: 'document' | 'family' | 'note' | 'notification'): Promise<T[]> {
    if (!vaultKeyManager.isUnlocked()) {
      await vaultKeyManager.ensureUnlocked();
    }

    const db = await openDB();
    const records = await new Promise<Array<{ id: string; type: string; encryptedData: string }>>((resolve, reject) => {
      const tx = db.transaction(STORES.RECORDS, 'readonly');
      const store = tx.objectStore(STORES.RECORDS);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });

    const matching = records.filter((r) => r.type === type);
    const results: T[] = [];

    for (const record of matching) {
      try {
        const decrypted = await decryptWithVaultKey<T>(record.encryptedData);
        results.push(decrypted);
      } catch (err) {
        console.warn(`Could not decrypt record ${record.id}:`, err);
      }
    }

    return results;
  },

  /**
   * Delete item from IndexedDB
   */
  async deleteItem(id: string): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.RECORDS, 'readwrite');
      const store = tx.objectStore(STORES.RECORDS);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  /**
   * Queue an operation for offline sync
   */
  async enqueueSyncItem(item: Omit<SyncQueueItem, 'timestamp' | 'retryCount'>): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.SYNC_QUEUE, 'readwrite');
      const store = tx.objectStore(STORES.SYNC_QUEUE);
      const queueItem: SyncQueueItem = {
        ...item,
        timestamp: Date.now(),
        retryCount: 0
      };
      const req = store.put(queueItem);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  /**
   * Get all queued offline sync items
   */
  async getSyncQueue(): Promise<SyncQueueItem[]> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.SYNC_QUEUE, 'readonly');
      const store = tx.objectStore(STORES.SYNC_QUEUE);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  },

  /**
   * Remove item from sync queue
   */
  async removeSyncQueueItem(id: string): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.SYNC_QUEUE, 'readwrite');
      const store = tx.objectStore(STORES.SYNC_QUEUE);
      const req = store.delete(id);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  },

  /**
   * Wipe all vault records (for reset or account deletion)
   */
  async clearAllVaultData(): Promise<void> {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction([STORES.RECORDS, STORES.SYNC_QUEUE, STORES.SECURITY], 'readwrite');
      tx.objectStore(STORES.RECORDS).clear();
      tx.objectStore(STORES.SYNC_QUEUE).clear();
      tx.objectStore(STORES.SECURITY).clear();
      tx.oncomplete = () => {
        vaultKeyManager.lockVault();
        resolve();
      };
      tx.onerror = () => reject(tx.error);
    });
  }
};
