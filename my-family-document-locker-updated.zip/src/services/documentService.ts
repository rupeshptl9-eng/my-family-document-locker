/**
 * Document Service
 * Hybrid Encrypted Storage Architecture:
 * - Local IndexedDB: AES-256-GCM encrypted document vault
 * - Cloud Firestore: Client-side encrypted sensitive fields (documentNumber, address, notes) + non-sensitive search metadata
 * - Firebase Storage: Authenticated user-isolated document binaries
 * - Offline Sync Queue & Cloud Sync Status indicators
 */

import {
  collection,
  doc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  orderBy
} from 'firebase/firestore';
import { db, isFirebaseConfigured, handleFirestoreError, OperationType } from '../config/firebase';
import { LockerDocument, SyncStatus } from '../types';
import { encryptedIndexedDBService } from './encryptedIndexedDBService';
import { encryptWithVaultKey, decryptWithVaultKey, vaultKeyManager } from './vaultKeyManager';
import { storageService } from './storageService';

export const documentService = {
  /**
   * Fetch documents: loads from encrypted IndexedDB, then syncs with Firestore if online & unlocked
   */
  async getDocuments(userId: string): Promise<LockerDocument[]> {
    // 1. Ensure vault key is ready
    if (!vaultKeyManager.isUnlocked()) {
      await vaultKeyManager.ensureUnlocked();
    }

    let localDocs: LockerDocument[] = [];
    try {
      localDocs = await encryptedIndexedDBService.getDecryptedItemsByType<LockerDocument>('document');
      // For any document where fileUrl was saved as a local blob record, restore dataUrl
      for (let i = 0; i < localDocs.length; i++) {
        const d = localDocs[i];
        if (!d.fileUrl || d.fileUrl.startsWith('blob:') || d.fileUrl.startsWith('local://')) {
          try {
            const blobRecord = await encryptedIndexedDBService.getDecryptedItem<any>(`blob_${d.id}`);
            if (blobRecord?.dataUrl) {
              d.fileUrl = blobRecord.dataUrl;
            }
          } catch {
            // Ignore if blob not found
          }
        }
      }
    } catch (err) {
      console.warn('Could not read from encrypted IndexedDB:', err);
    }

    // 2. If online and Firebase configured, fetch and sync cloud metadata
    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/documents`;
      try {
        const docsRef = collection(db, path);
        const q = query(docsRef, orderBy('uploadDate', 'desc'));
        const snap = await getDocs(q);

        const cloudDocsMap = new Map<string, LockerDocument>();
        for (const d of snap.docs) {
          const data = d.data();
          let decryptedSensitive: any = {};

          if (data.encryptedPayload && vaultKeyManager.isUnlocked()) {
            try {
              decryptedSensitive = await decryptWithVaultKey<any>(data.encryptedPayload);
            } catch {
              // Key mismatch or corrupted payload
            }
          }

          let restoredUrl = data.fileUrl || '';
          // If Firestore fileUrl was stripped to protect 1MB limit or is empty, try local blob cache
          if (!restoredUrl || restoredUrl.startsWith('blob:') || restoredUrl.startsWith('local://')) {
            try {
              const blobRecord = await encryptedIndexedDBService.getDecryptedItem<any>(`blob_${d.id}`);
              if (blobRecord?.dataUrl) {
                restoredUrl = blobRecord.dataUrl;
              }
            } catch {
              // Ignored
            }
          }

          const mergedDoc: LockerDocument = {
            id: d.id,
            userId,
            name: data.name,
            category: data.category,
            familyMemberId: data.familyMemberId || 'self',
            familyMemberName: data.familyMemberName || 'Self',
            holderName: decryptedSensitive.holderName || data.holderName || '',
            documentNumber: decryptedSensitive.documentNumber || data.maskedNumber,
            maskedNumber: data.maskedNumber,
            dob: decryptedSensitive.dob || data.dob,
            gender: data.gender,
            address: decryptedSensitive.address || data.address,
            issueDate: data.issueDate,
            expiryDate: data.expiryDate,
            issuingAuthority: data.issuingAuthority,
            fileType: data.fileType || 'jpg',
            fileUrl: restoredUrl,
            storagePath: data.storagePath,
            thumbnailPath: data.thumbnailPath,
            fileName: data.fileName || `${data.name}.jpg`,
            fileSize: data.fileSize || 0,
            uploadDate: data.uploadDate || new Date().toISOString().slice(0, 10),
            notes: decryptedSensitive.notes || data.notes || '',
            tags: data.tags || [],
            isAadhaar: data.isAadhaar,
            isFavorite: data.isFavorite,
            verifiedByUser: data.verifiedByUser,
            syncStatus: 'cloud-synced'
          };

          cloudDocsMap.set(d.id, mergedDoc);

          // Update local encrypted cache
          await encryptedIndexedDBService.putEncryptedItem(d.id, 'document', mergedDoc).catch(() => {});
        }

        // Merge localDocs with cloudDocsMap (local changes take priority for items not yet synced)
        const combinedMap = new Map<string, LockerDocument>(cloudDocsMap);
        for (const loc of localDocs) {
          if (!combinedMap.has(loc.id) || loc.syncStatus === 'device-only') {
            combinedMap.set(loc.id, loc);
          }
        }

        return Array.from(combinedMap.values());
      } catch (err: any) {
        if (err?.code === 'permission-denied') {
          handleFirestoreError(err, OperationType.LIST, path);
        }
        console.warn('Firestore getDocs failed, returning local vault:', err);
      }
    }

    return localDocs;
  },

  /**
   * Save or create document
   * Handles binary persistence in Firebase Storage / local encrypted blob store,
   * encrypts sensitive fields before sending to Firestore,
   * and guarantees encrypted persistence in IndexedDB.
   */
  async saveDocument(userId: string, document: LockerDocument): Promise<LockerDocument> {
    let syncStatus: SyncStatus = 'device-only';
    let syncError: string | undefined;

    // Ensure vault is unlocked
    if (!vaultKeyManager.isUnlocked()) {
      await vaultKeyManager.ensureUnlocked();
    }

    let finalFileUrl = document.fileUrl || '';
    let finalStoragePath = document.storagePath || '';
    let finalThumbnailPath = document.thumbnailPath || '';

    // If fileUrl is a data URL or blob URL, store/upload original binary safely
    if (finalFileUrl && (finalFileUrl.startsWith('data:') || finalFileUrl.startsWith('blob:'))) {
      try {
        const mime = document.fileType === 'pdf' ? 'application/pdf' : 'image/jpeg';
        const uploadResult = await storageService.uploadDocumentFile(
          userId || 'local-user',
          document.id,
          finalFileUrl,
          document.fileName || `${document.name}.${document.fileType}`,
          mime
        );
        finalFileUrl = uploadResult.fileUrl;
        finalStoragePath = uploadResult.storagePath;
        finalThumbnailPath = uploadResult.thumbnailPath || '';
        if (uploadResult.syncStatus === 'cloud-synced') {
          syncStatus = 'cloud-synced';
        }
      } catch (uploadErr) {
        console.warn('Storage upload error, fallback to local storage:', uploadErr);
      }
    }

    const docToSave: LockerDocument = {
      ...document,
      fileUrl: finalFileUrl,
      storagePath: finalStoragePath,
      thumbnailPath: finalThumbnailPath,
      syncStatus
    };

    // 1. Mandatory Local IndexedDB Save - Must succeed or throw
    try {
      await encryptedIndexedDBService.putEncryptedItem(document.id, 'document', docToSave);
    } catch (idbErr: any) {
      console.error('Failed to save document to encrypted IndexedDB:', idbErr);
      throw new Error(`Failed to save document locally: ${idbErr.message || idbErr}`);
    }

    // 2. Sync to Firestore if authenticated & online
    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/documents/${document.id}`;
      try {
        let encryptedPayload = '';
        if (vaultKeyManager.isUnlocked()) {
          encryptedPayload = await encryptWithVaultKey({
            documentNumber: document.documentNumber,
            address: document.address || '',
            notes: document.notes || '',
            dob: document.dob || '',
            holderName: document.holderName || ''
          });
        }

        // Firestore payload - protect against exceeding 1MB limit by not storing multi-MB dataUrls
        const safeFileUrl = finalFileUrl && finalFileUrl.startsWith('data:') && finalFileUrl.length > 200000
          ? '' // URL is available locally in IndexedDB blob store; keep Firestore light
          : finalFileUrl;

        const firestorePayload = {
          id: document.id,
          userId,
          name: document.name,
          category: document.category,
          familyMemberId: document.familyMemberId,
          familyMemberName: document.familyMemberName,
          maskedNumber: document.maskedNumber,
          fileType: document.fileType,
          fileUrl: safeFileUrl,
          storagePath: finalStoragePath,
          thumbnailPath: finalThumbnailPath,
          fileName: document.fileName,
          fileSize: document.fileSize,
          uploadDate: document.uploadDate,
          issueDate: document.issueDate || '',
          expiryDate: document.expiryDate || '',
          issuingAuthority: document.issuingAuthority || '',
          notes: document.notes || '',
          tags: document.tags || [],
          isAadhaar: Boolean(document.isAadhaar),
          isFavorite: Boolean(document.isFavorite),
          verifiedByUser: Boolean(document.verifiedByUser),
          encryptedPayload
        };

        const docRef = doc(db, `users/${userId}/documents`, document.id);
        await setDoc(docRef, firestorePayload, { merge: true });

        syncStatus = 'cloud-synced';
        syncError = undefined;
      } catch (err: any) {
        syncStatus = 'device-only';
        syncError = 'Document stored on device. Cloud sync will retry automatically.';
        console.warn('Firestore setDoc notice:', err);

        // Queue for background retry
        await encryptedIndexedDBService.enqueueSyncItem({
          id: `sync_doc_${document.id}`,
          action: 'update',
          entityType: 'document',
          payload: docToSave
        }).catch(() => {});
      }
    } else {
      // Offline: Enqueue for sync
      syncStatus = 'device-only';
      if (userId && userId !== 'unauthenticated') {
        await encryptedIndexedDBService.enqueueSyncItem({
          id: `sync_doc_${document.id}`,
          action: 'update',
          entityType: 'document',
          payload: docToSave
        }).catch(() => {});
      }
    }

    const updatedDocument: LockerDocument = {
      ...docToSave,
      syncStatus,
      syncError
    };

    // Update local cache with finalized syncStatus
    try {
      await encryptedIndexedDBService.putEncryptedItem(document.id, 'document', updatedDocument);
    } catch {
      // Ignored
    }

    return updatedDocument;
  },

  /**
   * Delete document permanently from Firestore, Storage, and IndexedDB
   */
  async deleteDocument(userId: string, document: LockerDocument): Promise<void> {
    // 1. Delete from Firestore
    if (isFirebaseConfigured && db && userId && userId !== 'unauthenticated' && navigator.onLine) {
      const path = `users/${userId}/documents/${document.id}`;
      try {
        const docRef = doc(db, `users/${userId}/documents`, document.id);
        await deleteDoc(docRef);
      } catch (err: any) {
        console.warn('Firestore deleteDoc error:', err);
      }
    }

    // 2. Delete from Firebase Storage (original + thumbnail)
    await storageService.deleteDocumentFile(
      document.storagePath,
      document.id,
      document.thumbnailPath
    );

    // 3. Delete from local encrypted IndexedDB
    try {
      await encryptedIndexedDBService.deleteItem(document.id);
      await encryptedIndexedDBService.removeSyncQueueItem(`sync_doc_${document.id}`);
    } catch {
      // Ignored
    }
  },

  /**
   * Retry sync for all pending offline items
   */
  async processOfflineSyncQueue(userId: string): Promise<number> {
    if (!isFirebaseConfigured || !db || !userId || !navigator.onLine) {
      return 0;
    }

    const queue = await encryptedIndexedDBService.getSyncQueue();
    let syncedCount = 0;

    for (const item of queue) {
      try {
        if (item.entityType === 'document' && item.payload) {
          await this.saveDocument(userId, item.payload);
          await encryptedIndexedDBService.removeSyncQueueItem(item.id);
          syncedCount++;
        }
      } catch (err) {
        console.warn(`Sync retry failed for ${item.id}:`, err);
      }
    }

    return syncedCount;
  }
};
