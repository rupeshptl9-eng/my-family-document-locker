/**
 * Hybrid AI Router
 * Orchestrates:
 * 1. Native Android Gemini Nano / AICore (Prompt API) when available
 * 2. On-device ML Kit / Web Tesseract OCR & Deterministic Rules (100% Offline)
 * 3. Server-side Gemini Cloud API (optional opt-in fallback when online)
 *
 * Privacy Guarantees:
 * - Default AI_MODE = 'auto' (Local First)
 * - Document Cloud Processing is OFF by default
 * - Zero raw GEMINI_API_KEY exposure on client
 * - Sensitive documents stay local whenever possible
 * - Fast non-blocking warmup with status notifications
 */

import { localAiPlugin, LocalAIStatus } from './localAiPlugin';
import { documentClassifier, ExtractedDocumentFields } from './documentClassifier';
import { preprocessImageForOCR } from '../utils/imagePreprocessing';
import { localAiContext, LocalQueryResult } from './localAiContext';
import { aiService } from './aiService';
import { AIExtractionResult, FamilyMember, LockerDocument, TextNote } from '../types';

export type AIMode = 'auto' | 'offline' | 'cloud';

export interface AISettings {
  aiMode: AIMode;
  cloudAiEnabled: boolean;
  documentCloudProcessing: boolean;
}

export type AIWarmupState = 'idle' | 'preparing' | 'ready';

export interface AIStatusInfo {
  status: LocalAIStatus;
  hasNano: boolean;
  hasOcr: boolean;
  isWarmedUp: boolean;
  warmupState: AIWarmupState;
  aiMode: AIMode;
  cloudAvailable: boolean;
  badgeText: string;
  badgeColor: 'emerald' | 'amber' | 'blue' | 'slate' | 'rose';
}

const STORAGE_KEYS = {
  SETTINGS: 'mfd_ai_settings_v1',
  READINESS_CACHE: 'mfd_ai_ready_cache'
};

function loadSettings(): AISettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch {}
  return {
    aiMode: 'auto',
    cloudAiEnabled: false,
    documentCloudProcessing: false
  };
}

let currentWarmupState: AIWarmupState = 'idle';
const listeners = new Set<(status: AIStatusInfo) => void>();

function notifyListeners() {
  aiRouter.getStatus().then((status) => {
    listeners.forEach((l) => l(status));
  });
}

export const aiRouter = {
  /**
   * Subscribe to AI subsystem status changes
   */
  subscribe(listener: (status: AIStatusInfo) => void): () => void {
    listeners.add(listener);
    this.getStatus().then(listener);
    return () => listeners.delete(listener);
  },

  /**
   * Get current AI Settings
   */
  getSettings(): AISettings {
    return loadSettings();
  },

  /**
   * Update AI Settings
   */
  updateSettings(updates: Partial<AISettings>): AISettings {
    const current = loadSettings();
    const updated: AISettings = { ...current, ...updates };
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(updated));
    notifyListeners();
    return updated;
  },

  /**
   * Warm up local AI pipeline asynchronously without blocking UI
   */
  async warmup(): Promise<void> {
    const isCachedReady = typeof sessionStorage !== 'undefined' && sessionStorage.getItem(STORAGE_KEYS.READINESS_CACHE) === 'true';
    if (isCachedReady) {
      currentWarmupState = 'ready';
      notifyListeners();
      return;
    }

    try {
      const avail = await localAiPlugin.checkLocalAIAvailability();
      if (avail.hasNano || avail.hasOcr) {
        currentWarmupState = 'preparing';
        notifyListeners();

        await localAiPlugin.warmupLocalAI();

        currentWarmupState = 'ready';
        try {
          sessionStorage.setItem(STORAGE_KEYS.READINESS_CACHE, 'true');
        } catch {}
        notifyListeners();
      }
    } catch (err) {
      console.warn('AI warmup notice:', err);
      currentWarmupState = 'ready';
      notifyListeners();
    }
  },

  /**
   * Get comprehensive status of AI subsystem
   */
  async getStatus(): Promise<AIStatusInfo> {
    const settings = this.getSettings();
    const localInfo = await localAiPlugin.checkLocalAIAvailability();
    const statusState = await localAiPlugin.getLocalAIStatus();

    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : true;
    const cloudAvailable = isOnline && settings.cloudAiEnabled;

    let badgeText = 'Offline AI Ready';
    let badgeColor: 'emerald' | 'amber' | 'blue' | 'slate' | 'rose' = 'emerald';

    if (currentWarmupState === 'preparing' || localInfo.status === 'BUSY') {
      badgeText = 'Preparing Offline AI...';
      badgeColor = 'amber';
    } else if (localInfo.status === 'DOWNLOADING') {
      badgeText = 'Downloading Offline AI...';
      badgeColor = 'amber';
    } else if (localInfo.hasNano) {
      badgeText = 'Gemini Nano Ready';
      badgeColor = 'emerald';
    } else if (statusState.isWarmedUp || localInfo.hasOcr || currentWarmupState === 'ready') {
      badgeText = 'Offline AI Ready';
      badgeColor = 'emerald';
    } else if (cloudAvailable) {
      badgeText = 'Cloud AI Available';
      badgeColor = 'blue';
    } else {
      badgeText = 'Local AI Ready';
      badgeColor = 'slate';
    }

    return {
      status: localInfo.status,
      hasNano: localInfo.hasNano,
      hasOcr: localInfo.hasOcr,
      isWarmedUp: statusState.isWarmedUp || currentWarmupState === 'ready',
      warmupState: currentWarmupState,
      aiMode: settings.aiMode,
      cloudAvailable,
      badgeText,
      badgeColor
    };
  },

  /**
   * Scan and extract document fields using the Hybrid AI Router
   * Pipeline:
   * Camera/File -> Image preprocessing -> Local OCR -> Gemini Nano if available -> Local Rules -> User verification
   */
  async scanDocument(
    fileOrBlob: File | Blob,
    options?: { forceEngine?: 'local' | 'cloud' }
  ): Promise<ExtractedDocumentFields> {
    const settings = this.getSettings();
    const filename = (fileOrBlob as File).name || 'document';
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : false;

    // 1. Image Preprocessing (downscale, optimize contrast, non-destructive)
    const preprocessed = await preprocessImageForOCR(fileOrBlob);

    // For PDF files, extract embedded text streams directly from buffer
    const isPdf = (fileOrBlob.type && fileOrBlob.type.includes('pdf')) ||
      filename.toLowerCase().endsWith('.pdf');

    let pdfExtractedText = '';
    if (isPdf && typeof fileOrBlob.arrayBuffer === 'function') {
      try {
        const buffer = await fileOrBlob.arrayBuffer();
        pdfExtractedText = documentClassifier.extractTextFromPdfBuffer(buffer);
      } catch (err) {
        console.warn('PDF stream extraction notice:', err);
      }
    }

    try {
      const shouldAttemptLocal =
        options?.forceEngine === 'local' ||
        settings.aiMode === 'offline' ||
        settings.aiMode === 'auto' ||
        !settings.documentCloudProcessing ||
        !isOnline;

      if (shouldAttemptLocal) {
        try {
          // If PDF already has readable embedded text, classify directly without OCR
          if (pdfExtractedText && pdfExtractedText.trim().length > 15) {
            const extracted = documentClassifier.extractFields(
              pdfExtractedText,
              filename,
              92
            );
            extracted.engine = 'local';
            extracted.processingNotice = 'Processed on device';
            return extracted;
          }

          // Step A: Local OCR (Native ML Kit on Android, Web OCR in browser)
          const localOcrResult = await localAiPlugin.runLocalDocumentAI({
            imageBase64: preprocessed.base64Data
          });

          const rawText = localOcrResult?.rawText || pdfExtractedText;

          if (rawText && rawText.trim().length > 0) {
            const ocrConfidence = localOcrResult?.confidence || 85;

            // Step B: Check Gemini Nano / Prompt API on device
            const aiAvail = await localAiPlugin.checkLocalAIAvailability();
            if (aiAvail.hasNano) {
              try {
                const prompt = documentClassifier.buildGeminiNanoPrompt(rawText);
                const nanoRes = await localAiPlugin.runLocalAI(prompt);

                if (nanoRes && nanoRes.response) {
                  let parsedJson: any = null;
                  try {
                    let cleaned = nanoRes.response.trim();
                    if (cleaned.startsWith('```json')) {
                      cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
                    } else if (cleaned.startsWith('```')) {
                      cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
                    }
                    parsedJson = JSON.parse(cleaned);
                  } catch {}

                  if (parsedJson && typeof parsedJson === 'object') {
                    const validated = documentClassifier.validateAiResult(
                      parsedJson,
                      'Other',
                      ocrConfidence
                    );
                    validated.engine = 'local';
                    validated.processingNotice = 'Processed on device';
                    return validated;
                  }
                }
              } catch (nanoErr) {
                console.warn('Gemini Nano on-device extraction failed, falling back to local rules:', nanoErr);
              }
            }

            // Step C: Deterministic Local Field Extractor & Classifier
            const extracted = documentClassifier.extractFields(
              rawText,
              filename,
              ocrConfidence
            );
            extracted.engine = localOcrResult?.engine === 'local' ? 'local' : 'ocr';
            extracted.processingNotice = 'Processed on device';

            // If confidence is acceptable or device is offline, return local result
            if (extracted.overallConfidence >= 60 || !isOnline || !settings.documentCloudProcessing) {
              return extracted;
            }
          }
        } catch (localErr) {
          console.warn('Local OCR attempt error, checking fallback options:', localErr);
        }
      }

      // 2. Cloud Fallback (ONLY if explicitly enabled by user, online, and document cloud processing permitted)
      if (
        isOnline &&
        settings.cloudAiEnabled &&
        settings.documentCloudProcessing &&
        settings.aiMode !== 'offline'
      ) {
        try {
          const cloudResult: AIExtractionResult = await aiService.scanDocument(
            preprocessed.base64Data,
            preprocessed.mimeType,
            filename
          );

          const validated = documentClassifier.validateAiResult(cloudResult, cloudResult.docType, 90);
          validated.engine = 'cloud';
          validated.processingNotice = 'Processed using Cloud AI';
          return validated;
        } catch (cloudErr) {
          console.warn('Cloud AI fallback failed, using safe offline extraction:', cloudErr);
        }
      }

      // 3. Fallback: Deterministic Extraction based on filename and basic cues
      const fallback = documentClassifier.extractFields(pdfExtractedText || '', filename, 55);
      fallback.engine = 'rules';
      fallback.processingNotice = 'Processed on device';
      return fallback;
    } finally {
      preprocessed.cleanUp();
    }
  },

  /**
   * Ask Assistant a question (Offline RAG first, optional Cloud Gemini fallback)
   */
  async askQuestion(
    question: string,
    documents: LockerDocument[],
    familyMembers: FamilyMember[],
    textNotes: TextNote[]
  ): Promise<{
    reply: string;
    engine: 'rules' | 'local' | 'cloud';
    matchedDocuments?: LockerDocument[];
    matchedMembers?: FamilyMember[];
  }> {
    const settings = this.getSettings();
    const isOnline = typeof navigator !== 'undefined' ? navigator.onLine : false;

    // 1. Check Offline Query Engine (Local RAG)
    const offlineResult: LocalQueryResult | null = localAiContext.answerQueryOffline(
      question,
      documents,
      familyMembers,
      textNotes
    );

    if (offlineResult) {
      return {
        reply: offlineResult.reply,
        engine: offlineResult.engine,
        matchedDocuments: offlineResult.matchedDocuments,
        matchedMembers: offlineResult.matchedMembers
      };
    }

    // 2. If offline or cloud disabled, provide informative local fallback
    if (!isOnline || !settings.cloudAiEnabled || settings.aiMode === 'offline') {
      const summary = `Offline Assistant: Found ${documents.length} document(s) in your vault. Try asking queries like:
• "Show Aadhaar documents"
• "Which documents expire this month?"
• "Show documents for [Family Member Name]"
• "Which insurance documents are expiring?"
• "Show passport documents"`;

      return {
        reply: summary,
        engine: 'rules'
      };
    }

    // 3. Cloud AI Assistant (Sanitized minimal metadata only; never sensitive blobs or numbers)
    try {
      const sanitizedDocs = documents.map((d) => ({
        id: d.id,
        name: d.name,
        category: d.category,
        familyMemberName: d.familyMemberName || 'Self',
        expiryDate: d.expiryDate || 'N/A'
      }));

      const cloudReply = await aiService.askQuestion(
        question,
        sanitizedDocs as any,
        familyMembers,
        textNotes
      );

      return {
        reply: cloudReply,
        engine: 'cloud'
      };
    } catch (err: any) {
      return {
        reply: 'Could not connect to Cloud AI. You can still query your vault offline using names or categories.',
        engine: 'rules'
      };
    }
  },

  /**
   * Analyze and categorize text note offline
   */
  async analyzeText(
    text: string,
    title: string = ''
  ): Promise<{
    category: string;
    tags: string[];
    suggestedTitle: string;
    engine: 'rules' | 'local' | 'cloud';
  }> {
    const combined = `${title} ${text}`.toLowerCase();
    const tags: string[] = [];
    let category = 'Important notes';

    if (combined.includes('bank') || combined.includes('account') || combined.includes('ifsc') || combined.includes('card')) {
      category = 'Bank information';
      tags.push('finance', 'banking');
    } else if (combined.includes('password') || combined.includes('pin') || combined.includes('login') || combined.includes('credentials')) {
      category = 'Personal notes';
      tags.push('security', 'credentials');
    } else if (combined.includes('health') || combined.includes('doctor') || combined.includes('medicine') || combined.includes('insurance') || combined.includes('policy')) {
      category = 'Insurance details';
      tags.push('insurance', 'health');
    } else if (combined.includes('emergency') || combined.includes('ambulance') || combined.includes('police') || combined.includes('contact')) {
      category = 'Emergency information';
      tags.push('emergency', 'contacts');
    } else if (combined.includes('address') || combined.includes('plot') || combined.includes('flat') || combined.includes('house')) {
      category = 'Addresses';
      tags.push('address', 'home');
    } else if (combined.includes('ref') || combined.includes('ack') || combined.includes('application') || combined.includes('number')) {
      category = 'Reference numbers';
      tags.push('reference', 'records');
    }

    return {
      category,
      tags: tags.length > 0 ? tags : ['note'],
      suggestedTitle: title || 'Secure Note',
      engine: 'rules'
    };
  }
};
