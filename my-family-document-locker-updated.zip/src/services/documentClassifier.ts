/**
 * Deterministic Local Document Classifier and Field Extractor
 * - High-speed regex, layout, and keyword matching
 * - Strict schema validation and confidence scoring (OCR + Pattern + AI)
 * - Fallback protection against malformed OCR/AI outputs
 * - Purely client-side execution; never queries external or government servers
 * - Adheres strictly to Indian document formats and privacy constraints
 */

import { DocumentCategory, Gender } from '../types';

export interface ExtractedDocumentFields {
  docType: DocumentCategory;
  docName: string;
  holderName: string | null;
  documentNumber: string | null;
  dob: string | null;
  gender: Gender;
  address: string | null;
  issueDate: string | null;
  expiryDate: string | null;
  issuingAuthority: string | null;
  ocrConfidence: number;
  aiConfidence: number;
  patternConfidence: number;
  overallConfidence: number;
  confidenceScore: number; // for backward compatibility
  confidenceTier: 'high' | 'medium' | 'low';
  lowConfidenceFields: string[];
  engine: 'local' | 'ocr' | 'rules' | 'cloud';
  processingNotice: string;
  complianceNotice: string;
  isAadhaar: boolean;
}

// Regex Patterns for Indian Documents
const PATTERNS = {
  // Aadhaar: 12 numeric digits, often formatted as 4-4-4
  AADHAAR: /\b[2-9]{1}[0-9]{3}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b/,
  AADHAAR_GLOBAL: /\b[2-9]{1}[0-9]{3}[\s-]?[0-9]{4}[\s-]?[0-9]{4}\b/g,
  // PAN: 5 uppercase letters, 4 digits, 1 letter (e.g. ABCDE1234F)
  PAN: /\b[A-Z]{5}[0-9]{4}[A-Z]{1}\b/,
  PAN_GLOBAL: /\b[A-Z]{5}[0-9]{4}[A-Z]{1}\b/g,
  // Passport: 1 letter followed by 7 digits, or 8 alphanumeric
  PASSPORT: /\b[A-PR-WYa-pr-wy][1-9]\d\s?\d{4}[1-9]\b/,
  // Driving Licence: 2-char state code, 2-char RTO, year/digits
  DL: /\b[A-Z]{2}[-\s]?[0-9]{2}[-\s]?[0-9]{11}\b/,
  // Voter ID: 3 letters + 7 digits (e.g. WDX1234567)
  VOTER_ID: /\b[A-Z]{3}[0-9]{7}\b/,
  // Vehicle Registration: e.g. MH12AB1234, DL01C1234
  VEHICLE_RC: /\b[A-Z]{2}[-\s]?[0-9]{1,2}[-\s]?[A-Z]{1,3}[-\s]?[0-9]{4}\b/,
  // Standard Dates: DD/MM/YYYY or DD-MM-YYYY or YYYY-MM-DD
  DATE_DMY: /\b(0[1-9]|[12][0-9]|3[01])[\/\-\.](0[1-9]|1[012])[\/\-\.](19\d\d|20\d\d)\b/,
  DATE_DMY_GLOBAL: /\b(0[1-9]|[12][0-9]|3[01])[\/\-\.](0[1-9]|1[012])[\/\-\.](19\d\d|20\d\d)\b/g,
  DATE_YMD: /\b(19\d\d|20\d\d)[\/\-\.](0[1-9]|1[012])[\/\-\.](0[1-9]|[12][0-9]|3[01])\b/,
  DATE_YMD_GLOBAL: /\b(19\d\d|20\d\d)[\/\-\.](0[1-9]|1[012])[\/\-\.](0[1-9]|[12][0-9]|3[01])\b/g,
  // Year of Birth: e.g. "Year of Birth : 1988" or "YOB : 1990"
  YOB: /\b(?:YOB|Year\s+of\s+Birth)[\s:]*([12][90]\d{2})\b/i,
  // Mobile Phone Numbers: 10 digits starting with 6, 7, 8, or 9
  MOBILE_GLOBAL: /\b[6-9][0-9]{9}\b/g,
  // IFSC Code
  IFSC: /\b[A-Z]{4}0[A-Z0-9]{6}\b/
};

/**
 * Safe RegExp matcher that guarantees global matching without throwing
 * 'String.prototype.matchAll called with a non-global RegExp argument'
 * Even if a pattern without the 'g' flag is passed, it automatically creates a global copy.
 */
export function safeMatchAll(text: string, pattern: RegExp): RegExpMatchArray[] {
  if (!text || typeof text !== 'string') return [];
  try {
    const flags = pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`;
    const globalRegex = new RegExp(pattern.source, flags);
    return Array.from(text.matchAll(globalRegex));
  } catch (err) {
    console.warn('safeMatchAll fallback:', err);
    return [];
  }
}

// Keyword Dictionaries
const KEYWORDS: Record<DocumentCategory, string[]> = {
  Aadhaar: ['aadhaar', 'uidai', 'unique identification', 'mera aadhaar', 'government of india', 'enrolment no', 'vid'],
  PAN: ['income tax department', 'permanent account number', 'govt of india', 'pan card', 'signature'],
  Passport: ['passport', 'republic of india', 'indian passport', 'given name', 'surname', 'type p'],
  'Driving Licence': ['driving licence', 'union of india', 'transport department', 'dl no', 'driver licence', 'motor vehicle'],
  'Voter ID': ['election commission of india', 'elector photo identity', 'epic', 'voter identity', 'assembly constituency'],
  'Ration Card': ['ration card', 'food, civil supplies', 'consumer affairs', 'fair price shop', 'bpl', 'apl', 'nfsa'],
  'Birth Certificate': ['birth certificate', 'form no. 5', 'registration of births', 'date of birth', 'place of birth'],
  'Marriage Certificate': ['marriage certificate', 'solemnization of marriage', 'husband', 'wife', 'memorandum of marriage'],
  Education: ['board of secondary', 'university', 'degree', 'diploma', 'marksheet', 'statement of marks', 'roll no', 'matriculation', 'bachelor', 'master'],
  Insurance: ['insurance', 'policy number', 'sum assured', 'premium', 'valid till', 'lic of india', 'health insurance', 'mediclaim'],
  Bank: ['bank', 'account number', 'ifsc', 'branch', 'passbook', 'statement', 'savings bank', 'customer id', 'cheque'],
  Property: ['sale deed', 'registry', 'property card', 'khata', 'mutation', 'sub-registrar', 'plot', 'survey number', 'conveyance'],
  Vehicle: ['registration certificate', 'rc', 'chassis no', 'engine no', 'vehicle class', 'fuel type', 'rto registration', 'vahan'],
  Other: []
};

/**
 * Standardize extracted date string to YYYY-MM-DD
 */
export function normalizeDate(rawDateStr: string | null): string | null {
  if (!rawDateStr) return null;
  const clean = rawDateStr.replace(/[^\d\/\-\.]/g, '');

  // Match DD/MM/YYYY
  const dmy = clean.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
  if (dmy) {
    const day = dmy[1].padStart(2, '0');
    const month = dmy[2].padStart(2, '0');
    const year = dmy[3];
    return `${year}-${month}-${day}`;
  }

  // Match YYYY/MM/DD
  const ymd = clean.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);
  if (ymd) {
    const year = ymd[1];
    const month = ymd[2].padStart(2, '0');
    const day = ymd[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  return null;
}

export const documentClassifier = {
  /**
   * Deterministically classify document category using OCR text, keywords, and filename
   */
  classifyCategory(text: string, filename: string): { category: DocumentCategory; confidence: number } {
    const lowerText = text.toLowerCase();
    const lowerFilename = filename.toLowerCase();

    // Check high-confidence regex patterns first
    if (PATTERNS.PAN.test(text) && (lowerText.includes('income tax') || lowerText.includes('permanent account') || lowerText.includes('pan'))) {
      return { category: 'PAN', confidence: 98 };
    }
    if (PATTERNS.AADHAAR.test(text) && (lowerText.includes('aadhaar') || lowerText.includes('uidai') || lowerText.includes('unique identification'))) {
      return { category: 'Aadhaar', confidence: 98 };
    }
    if (PATTERNS.VOTER_ID.test(text) && (lowerText.includes('election') || lowerText.includes('elector'))) {
      return { category: 'Voter ID', confidence: 95 };
    }
    if (PATTERNS.PASSPORT.test(text) && lowerText.includes('passport')) {
      return { category: 'Passport', confidence: 95 };
    }
    if (PATTERNS.DL.test(text) && (lowerText.includes('driving') || lowerText.includes('licence'))) {
      return { category: 'Driving Licence', confidence: 95 };
    }
    if (PATTERNS.VEHICLE_RC.test(text) && (lowerText.includes('registration') || lowerText.includes('vehicle') || lowerText.includes('chassis'))) {
      return { category: 'Vehicle', confidence: 92 };
    }

    // Keyword score ranking
    let bestCategory: DocumentCategory = 'Other';
    let highestScore = 0;

    for (const [cat, words] of Object.entries(KEYWORDS)) {
      if (cat === 'Other') continue;
      let score = 0;
      for (const word of words) {
        if (lowerText.includes(word)) score += 2;
        if (lowerFilename.includes(word.replace(/\s+/g, ''))) score += 3;
      }
      if (score > highestScore) {
        highestScore = score;
        bestCategory = cat as DocumentCategory;
      }
    }

    const confidence = highestScore >= 6 ? 90 : highestScore >= 3 ? 75 : 60;
    return { category: bestCategory, confidence };
  },

  /**
   * Builds the short deterministic prompt required for Gemini Nano / AICore
   * temperature = 0.1, candidateCount = 1, small maxOutputTokens
   */
  buildGeminiNanoPrompt(ocrText: string): string {
    return `You are a document field extractor.

Extract ONLY fields visible in the provided document.

Never invent information.

Return JSON only.

Fields:
docType
docName
holderName
documentNumber
dob
gender
address
issueDate
expiryDate
issuingAuthority
confidenceScore

Unknown fields must be null.

DOCUMENT TEXT:
${ocrText}`;
  },

  /**
   * Safe client-side text extractor for PDF documents
   * Reads plain text operators and uncompressed string tokens from PDF stream
   */
  extractTextFromPdfBuffer(buffer: ArrayBuffer): string {
    if (!buffer || buffer.byteLength === 0) return '';
    try {
      const decoder = new TextDecoder('latin1', { fatal: false });
      const rawString = decoder.decode(buffer);

      const textChunks: string[] = [];

      // Extract PDF literal text operators: (Sample Text) Tj, ' or "
      const tjRegex = /\(([^)\\]*(?:\\.[^)\\]*)*)\)\s*(?:Tj|'|")/g;
      let match: RegExpExecArray | null;
      while ((match = tjRegex.exec(rawString)) !== null) {
        const cleaned = match[1].replace(/\\([()\\])/g, '$1').trim();
        if (cleaned.length > 0) {
          textChunks.push(cleaned);
        }
      }

      // Extract array TJ operators: [(Sample) 20 (Text)] TJ
      const arrayTjRegex = /\[([^\]]+)\]\s*TJ/g;
      while ((match = arrayTjRegex.exec(rawString)) !== null) {
        const inner = match[1];
        const innerRegex = /\(([^)\\]*(?:\\.[^)\\]*)*)\)/g;
        let innerMatch: RegExpExecArray | null;
        const lineParts: string[] = [];
        while ((innerMatch = innerRegex.exec(inner)) !== null) {
          const cleaned = innerMatch[1].replace(/\\([()\\])/g, '$1').trim();
          if (cleaned.length > 0) {
            lineParts.push(cleaned);
          }
        }
        if (lineParts.length > 0) {
          textChunks.push(lineParts.join(' '));
        }
      }

      if (textChunks.length > 0) {
        return textChunks.join('\n');
      }

      // Fallback: look for alphanumeric tokens, dates, or card identifiers in the stream
      const tokens = rawString.match(/\b(?:[A-Z]{5}[0-9]{4}[A-Z]|[2-9][0-9]{3}[\s-][0-9]{4}[\s-][0-9]{4}|[0-9]{1,2}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{4}|UIDAI|Income\s+Tax|Government\s+of\s+India|DOB|Permanent\s+Account|Passport|Driving\s+Licence|[A-Z][a-z]{2,20}\s+[A-Z][a-z]{2,20})\b/gi);
      if (tokens && tokens.length > 0) {
        return tokens.join('\n');
      }

      return '';
    } catch (err) {
      console.warn('PDF stream extraction notice:', err);
      return '';
    }
  },

  /**
   * Deterministic local field extraction from OCR text
   */
  extractFields(text: string, filename: string, ocrConfidence: number = 85): ExtractedDocumentFields {
    const { category: detectedCategory, confidence: classificationConfidence } = this.classifyCategory(text, filename);
    let category = detectedCategory;
    const lines = text.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);

    let docNumber: string | null = null;
    let holderName: string | null = null;
    let dob: string | null = null;
    let gender: Gender = 'Unspecified';
    let address: string | null = null;
    let issueDate: string | null = null;
    let expiryDate: string | null = null;
    let issuingAuthority: string | null = null;

    const lowConfidenceFields: string[] = [];

    // 1. Extract Document Number
    if (category === 'Aadhaar') {
      const match = text.match(PATTERNS.AADHAAR);
      if (match) docNumber = match[0].replace(/\s+/g, ' ');
      issuingAuthority = 'Unique Identification Authority of India (UIDAI)';
    } else if (category === 'PAN') {
      const match = text.match(PATTERNS.PAN);
      if (match) docNumber = match[0].toUpperCase();
      issuingAuthority = 'Income Tax Department, Govt. of India';
    } else if (category === 'Passport') {
      const match = text.match(PATTERNS.PASSPORT);
      if (match) docNumber = match[0].toUpperCase();
      issuingAuthority = 'Ministry of External Affairs, India';
    } else if (category === 'Driving Licence') {
      const match = text.match(PATTERNS.DL);
      if (match) docNumber = match[0].toUpperCase();
      issuingAuthority = 'Regional Transport Office (RTO)';
    } else if (category === 'Voter ID') {
      const match = text.match(PATTERNS.VOTER_ID);
      if (match) docNumber = match[0].toUpperCase();
      issuingAuthority = 'Election Commission of India';
    } else if (category === 'Vehicle') {
      const match = text.match(PATTERNS.VEHICLE_RC);
      if (match) docNumber = match[0].toUpperCase();
      issuingAuthority = 'Transport Department';
    }

    // Check for high-confidence patterns if docNumber not yet identified
    if (!docNumber) {
      const panMatch = text.match(PATTERNS.PAN);
      const aadhaarMatch = text.match(PATTERNS.AADHAAR);
      const dlMatch = text.match(PATTERNS.DL);
      const passportMatch = text.match(PATTERNS.PASSPORT);
      const voterMatch = text.match(PATTERNS.VOTER_ID);
      const rcMatch = text.match(PATTERNS.VEHICLE_RC);

      if (panMatch) {
        docNumber = panMatch[0].toUpperCase();
        if (category === 'Other') {
          category = 'PAN';
          issuingAuthority = 'Income Tax Department, Govt. of India';
        }
      } else if (aadhaarMatch) {
        docNumber = aadhaarMatch[0].replace(/\s+/g, ' ');
        if (category === 'Other') {
          category = 'Aadhaar';
          issuingAuthority = 'Unique Identification Authority of India (UIDAI)';
        }
      } else if (dlMatch) {
        docNumber = dlMatch[0].toUpperCase();
        if (category === 'Other') category = 'Driving Licence';
      } else if (passportMatch) {
        docNumber = passportMatch[0].toUpperCase();
        if (category === 'Other') category = 'Passport';
      } else if (voterMatch) {
        docNumber = voterMatch[0].toUpperCase();
        if (category === 'Other') category = 'Voter ID';
      } else if (rcMatch) {
        docNumber = rcMatch[0].toUpperCase();
        if (category === 'Other') category = 'Vehicle';
      }
    }

    // 2. Extract Gender
    if (/\b(?:Female|FEMALE)\b/.test(text)) {
      gender = 'Female';
    } else if (/\b(?:Male|MALE)\b/.test(text)) {
      gender = 'Male';
    }

    // 3. Extract DOB
    const dobMatch = text.match(/(?:DOB|Date of Birth|Birth Date|D\.O\.B)[\s:]*([0-9]{1,2}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{4}|[0-9]{4}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{1,2})/i);
    if (dobMatch) {
      dob = normalizeDate(dobMatch[1]);
    } else {
      const yobMatch = text.match(PATTERNS.YOB);
      if (yobMatch) {
        dob = `${yobMatch[1]}-01-01`;
      }
    }

    // 4. Extract Issue / Expiry dates by contextual keywords first
    const issueMatch = text.match(/(?:Issue Date|Date of Issue|DOI|Issued on|Date of Registration)[\s:]*([0-9]{1,2}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{4}|[0-9]{4}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{1,2})/i);
    if (issueMatch) {
      issueDate = normalizeDate(issueMatch[1]);
    }

    const expiryMatch = text.match(/(?:Expiry Date|Date of Expiry|Valid Upto|Valid Till|Expires on|Expires|Validity)[\s:]*([0-9]{1,2}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{4}|[0-9]{4}[\/\-\.][0-9]{1,2}[\/\-\.][0-9]{1,2})/i);
    if (expiryMatch) {
      expiryDate = normalizeDate(expiryMatch[1]);
    }

    // 5. Extract dates safely using safeMatchAll (guarantees global flag and never throws)
    const dmyMatches = safeMatchAll(text, PATTERNS.DATE_DMY_GLOBAL).map((m) => m[0]);
    const ymdMatches = safeMatchAll(text, PATTERNS.DATE_YMD_GLOBAL).map((m) => m[0]);
    const dates = [...dmyMatches, ...ymdMatches];

    if (dates.length > 0) {
      if (!dob) {
        dob = normalizeDate(dates[0]);
      }
      if (!issueDate && dates.length > 1) {
        issueDate = normalizeDate(dates[1]);
      }
      if (!expiryDate && dates.length > 2) {
        expiryDate = normalizeDate(dates[2]);
      }
    }

    // 5. Extract Candidate Name
    for (let i = 0; i < Math.min(lines.length, 8); i++) {
      const line = lines[i];
      if (/government|india|republic|income|tax|department|union|licence|election|commission|card/i.test(line)) {
        continue;
      }
      if (/^[A-Za-z\s]{4,30}$/.test(line) && line.split(' ').length >= 2) {
        holderName = line.trim();
        break;
      }
    }

    // Track Low Confidence Fields
    if (!docNumber) lowConfidenceFields.push('documentNumber');
    if (!holderName) lowConfidenceFields.push('holderName');
    if (!dob && category !== 'Vehicle' && category !== 'Property') lowConfidenceFields.push('dob');

    // Section 8 Confidence System:
    // OCR confidence, Pattern confidence, Combined overallConfidence
    const patternConfidence = classificationConfidence;
    let overall = Math.round((ocrConfidence * 0.45) + (patternConfidence * 0.55));
    if (!docNumber) overall -= 20;
    if (!holderName) overall -= 10;
    overall = Math.max(30, Math.min(99, overall));

    const confidenceTier: 'high' | 'medium' | 'low' =
      overall >= 90 ? 'high' : overall >= 70 ? 'medium' : 'low';

    const docName = holderName ? `${category} - ${holderName}` : `${category} Document`;

    return {
      docType: category,
      docName,
      holderName,
      documentNumber: docNumber,
      dob,
      gender,
      address,
      issueDate,
      expiryDate,
      issuingAuthority,
      ocrConfidence,
      aiConfidence: 0,
      patternConfidence,
      overallConfidence: overall,
      confidenceScore: overall,
      confidenceTier,
      lowConfidenceFields,
      engine: 'rules',
      processingNotice: 'Processed on device',
      complianceNotice: 'Visual extraction only from visible document content. No government or external database was queried.',
      isAadhaar: category === 'Aadhaar'
    };
  },

  /**
   * Validate AI output strictly against document extraction schema
   * Replaces malformed values with safe fallbacks and never throws
   * Adheres to Section 7 & 8 requirements
   */
  validateAiResult(
    rawJson: any,
    fallbackCategory: DocumentCategory = 'Other',
    ocrConfidence: number = 85
  ): ExtractedDocumentFields {
    if (!rawJson || typeof rawJson !== 'object') {
      return {
        docType: fallbackCategory,
        docName: `${fallbackCategory} - Scanned`,
        holderName: null,
        documentNumber: null,
        dob: null,
        gender: 'Unspecified',
        address: null,
        issueDate: null,
        expiryDate: null,
        issuingAuthority: null,
        ocrConfidence,
        aiConfidence: 30,
        patternConfidence: 50,
        overallConfidence: 45,
        confidenceScore: 45,
        confidenceTier: 'low',
        lowConfidenceFields: ['documentNumber', 'holderName'],
        engine: 'rules',
        processingNotice: 'Processed on device',
        complianceNotice: 'Visual extraction only from visible document content. No government or external database was queried.',
        isAadhaar: fallbackCategory === 'Aadhaar'
      };
    }

    const validCategory = (rawJson.docType && typeof rawJson.docType === 'string')
      ? (rawJson.docType as DocumentCategory)
      : fallbackCategory;

    const lowConfidenceFields: string[] = [];
    if (!rawJson.documentNumber) lowConfidenceFields.push('documentNumber');
    if (!rawJson.holderName) lowConfidenceFields.push('holderName');
    if (!rawJson.dob && validCategory !== 'Vehicle' && validCategory !== 'Property') {
      lowConfidenceFields.push('dob');
    }

    const aiScore = typeof rawJson.confidenceScore === 'number'
      ? Math.max(10, Math.min(100, Math.round(rawJson.confidenceScore > 1 ? rawJson.confidenceScore : rawJson.confidenceScore * 100)))
      : 80;

    const patternScore = lowConfidenceFields.length === 0 ? 95 : lowConfidenceFields.length === 1 ? 80 : 60;
    const overall = Math.round((ocrConfidence * 0.3) + (patternScore * 0.4) + (aiScore * 0.3));
    const confidenceTier: 'high' | 'medium' | 'low' =
      overall >= 90 ? 'high' : overall >= 70 ? 'medium' : 'low';

    const isCloud = rawJson.engine === 'cloud';

    return {
      docType: validCategory,
      docName: String(rawJson.docName || `${validCategory} - Verified`).trim(),
      holderName: rawJson.holderName ? String(rawJson.holderName).trim() : null,
      documentNumber: rawJson.documentNumber ? String(rawJson.documentNumber).trim() : null,
      dob: normalizeDate(rawJson.dob ? String(rawJson.dob) : null),
      gender: ['Male', 'Female', 'Other'].includes(rawJson.gender) ? rawJson.gender : 'Unspecified',
      address: rawJson.address ? String(rawJson.address).trim() : null,
      issueDate: normalizeDate(rawJson.issueDate ? String(rawJson.issueDate) : null),
      expiryDate: normalizeDate(rawJson.expiryDate ? String(rawJson.expiryDate) : null),
      issuingAuthority: rawJson.issuingAuthority ? String(rawJson.issuingAuthority).trim() : null,
      ocrConfidence,
      aiConfidence: aiScore,
      patternConfidence: patternScore,
      overallConfidence: overall,
      confidenceScore: overall,
      confidenceTier,
      lowConfidenceFields,
      engine: isCloud ? 'cloud' : 'local',
      processingNotice: isCloud ? 'Processed using Cloud AI' : 'Processed on device',
      complianceNotice: 'Visual extraction only from visible document content. No government or external database was queried.',
      isAadhaar: validCategory === 'Aadhaar'
    };
  }
};
